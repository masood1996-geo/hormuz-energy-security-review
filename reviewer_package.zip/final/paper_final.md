# The Strait of Hormuz and Global Energy Security: Geopolitical Tensions, Maritime Trade, and the Risk of Supply Chain Disruption

**Authors:** [author names to be added before submission]

**Affiliations:** [institutions to be added]

**Corresponding author:** [name and email to be added]

**ORCID:** [to be added]

**Funding and conflicts of interest:** none declared. [to be confirmed by the authors]

## Abstract

The Strait of Hormuz carries roughly one-fifth of the world's petroleum liquids and one-fifth of its liquefied natural gas (LNG) trade, and it has no practical maritime alternative. This paper asks how geopolitical crises in the Persian Gulf affect energy market volatility and economic policy uncertainty. We use daily data on Brent crude, WTI crude, Henry Hub natural gas, the U.S. Economic Policy Uncertainty (EPU) index, and three options-implied volatility indices (VIX, OVX, GVZ) from January 2019 to August 2026, together with monthly international gas prices. Eleven Hormuz-related incidents are studied with crisis windows of 7, 14, 21, and 30 days and three control designs (broad baseline, pre-incident window, and the 2026 closure in isolation). Inference uses two-sided Welch t-tests with Bonferroni corrections, Newey-West standard errors, and quarter-clustered standard errors. We find that crude oil volatility rises after incidents relative to the immediate pre-incident window, with the 14-day effect significant under the Welch test (Brent p = 0.003; WTI p = 0.002) but only borderline under autocorrelation-robust corrections (Newey-West p = 0.051 and 0.058; clustered p = 0.079 and 0.062), and strongly significant at 21- and 30-day windows under all inference methods (p < 0.001). The 14-day oil effect survives leave-one-event-out checks and exclusion of the COVID and Russia-Ukraine periods, but not a placebo-date permutation standard (empirical p = 0.14-0.18) or a VIX-controlled regression, so short-horizon results should be read with caution; the 21- and 30-day results are the robust core. Implied crude-oil volatility (OVX) moves in the same direction in raw daily changes, but the effect is not robust to autocorrelation-robust adjustments and we treat it as descriptive; equity and gold volatility (VIX, GVZ) show no consistent response to sub-kinetic episodes. Henry Hub gas and the U.S. EPU index show no robust crisis premium. The 2026 closure was different: oil and LNG transit through the strait collapsed by 77.3% and 92.4% between 4Q2025 and 2Q2026, volatility jumped across markets, and gas prices split by region—Asian LNG prices were 52.6% and European gas 35.4% higher than a year earlier in spring 2026, while U.S. Henry Hub was 17.7% lower. The evidence indicates that markets price the threat of disruption mainly in crude oil, that sub-kinetic incidents do not move U.S. gas or broad policy uncertainty, and that only a realized closure shifts the shock into international gas markets; the evidence on broader policy uncertainty is suggestive rather than conclusive.

## 1. Introduction

Most of the world's energy trade moves through a small number of narrow maritime passages, and the Strait of Hormuz is the most consequential of them. The strait, a narrow waterway about 29 nautical miles wide at its narrowest point between the Musandam Peninsula of Oman and the Iranian coast [35], carried an average of 20.9 million barrels per day (mb/d) of crude oil, condensate, and petroleum products in 2023—more than 20% of world petroleum consumption and more than a quarter of seaborne crude trade [58, 59]. It is also the only export route for Qatari and Emirati LNG, so roughly 20% of global LNG trade passes through it [13, 35]. Most of this volume goes to Asia: China, India, Japan, and South Korea together take more than 80% of Hormuz crude [56, 35].

What makes the strait different from other chokepoints is that it cannot be bypassed. Ships that would normally use the Suez Canal or the Panama Canal can be rerouted around the Cape of Good Hope or Magellan Strait at a cost; there is no equivalent option for Hormuz [11, 34]. Overland pipelines—Saudi Arabia's East-West Petroline (design capacity 5.0 mb/d, reported upgraded to about 7.0 mb/d in March 2025 [35]), the UAE's Abu Dhabi Crude Oil Pipeline (1.5 mb/d), and Iran's Goreh-Jask pipeline (0.3–1.0 mb/d)—offer limited relief: the CRS estimates that the combined bypass pipelines may have roughly 2.6 mb/d of available capacity [34]. For LNG there is no overland bypass at all [35, 8]. A sustained closure of the strait therefore removes real supply from the world market rather than simply raising freight costs [10, 9].

The security environment around the strait deteriorated steadily between 2019 and 2026. Tanker attacks and seizures in 2019, the Iran-U.S. confrontation in early 2020, missile exchanges between Iran and Israel in 2024 and 2025, and finally the war of 2026 escalated the threat from harassment to physical interdiction [4, 9, 19, 29]. The war began in late February 2026; Iranian forces declared the strait closed on 4 March, and transit collapsed over the following weeks [34]. Oil and LNG transit fell by three-quarters or more within two quarters, an event without historical precedent [9, 57].

The academic literature has not settled how much these events matter for markets. Qualitative security studies routinely describe any Gulf confrontation as a threat to global stability [1, 2, 4], while quantitative studies disagree about whether a "Hormuz risk premium" exists at all [6, 27]. Two questions are open. First, do Hormuz incidents raise volatility across all energy commodities and policy uncertainty, or only in some markets? Second, do markets respond the same way to threats of disruption as to an actual disruption?

This paper answers both questions with an event-study analysis of daily market data from January 2019 through mid-August 2026 (the most recent observations available when the analysis was run). Eleven documented incidents are evaluated against three control designs, and the core price series are supplemented with options-implied volatility indices and monthly international gas prices. Physical flow data from the U.S. Energy Information Administration (EIA) are used to verify what actually happened to transit volumes during the 2026 war.

## 2. Theoretical Foundations and Systematic Literature Synthesis

The literature on maritime chokepoints and geopolitical supply chain risk spans resource economics, strategic studies, maritime logistics, and international law. A systematic screening of scholarly and institutional databases (OpenAlex and arXiv) on 23 August 2026 produced an evidence base of 59 studies: candidate sources were scored on a composite relevance index (0–100) covering term, title, and concept overlap, recency, and accessibility, and the 59 most relevant studies—scoring between 30.1 and 100.0—were retained, including peer-reviewed articles, reports from the EIA, the Congressional Research Service (CRS), and the International Energy Agency (IEA), and policy monographs. The full evidence matrix—citation structure, methods, relevance scores, and core findings for all 59 sources—is preserved in the run record (analysis/). Table 1 summarizes the resilience frameworks that recur in this literature.

### 2.1 The Non-Substitutable Chokepoint Paradigm

A common premise in the resource economics literature is that the risk posed by an infrastructure node depends on how easily it can be replaced [11, 27]. Verschuur et al. [27] show that container and bulk shipping networks can absorb disruptions through rerouting, but energy corridors with fixed origins and specialized vessels cannot. Shahi [2] and Meier [11] describe Hormuz as the most critical "non-substitutable chokepoint" in the global economy: its geography creates a bottleneck that cannot be bypassed. Wang et al. [55] provide a bibliometric map of the geopolitics–energy security literature in which chokepoint studies form a growing strand.

The CRS and IEA reach the same conclusion from operational flow data [34, 35]. The CRS notes that global spare crude production capacity has historically been 3.0–4.5 mb/d and that more than 75% of it sits inside the Persian Gulf—in other words, the world's main supply buffer would be trapped behind the very chokepoint it is meant to replace [34]. For LNG, Meza et al. [13] and Kolapo [40] show that Qatar's Ras Laffan complex depends entirely on Hormuz transit and cannot be served by pipeline.

### 2.2 Asymmetric Maritime Warfare and Deterrence Dynamics

The strategic literature examines how the strait's geography enables asymmetric anti-access/area-denial (A2/AD) tactics [25, 28]. Awan et al. [25] describe the Islamic Revolutionary Guard Corps Navy's (IRGCN) reliance on fast inshore attack craft, anti-ship cruise missiles, and naval mines to offset the conventional advantage of blue-water navies. Butt et al. [17] place this posture in the context of great-power competition, Mahdavi and Dehshiri [45] analyze the U.S.-China-Russia rivalry in the Persian Gulf, and Maaz et al. [43] extend the picture to the Indian Ocean. Kamalov [49] traces the effect of terrorism and oil geopolitics on world energy policy, Muhammad et al. [36] examine digital diplomacy and the petrodollar system in the Hormuz context, and Turkles [38] draws an analogy between Taiwan and other strategic chokepoints to argue that narrow passages create escalation risks in great-power competition.

Ramadhani et al. [3] analyze the multilateral diplomacy around maritime stability in the strait, and Ali et al. [14] assess the West Asia conflict's impact on maritime affairs. Pandoe et al. [28] document the shift toward hybrid conflict: unmanned surface vessels, loitering munitions, and electronic warfare (GPS and AIS spoofing) have changed the risk picture. The 2023–2025 Red Sea crisis showed what asymmetric actors can do to shipping; Bolat [22] models it and Kumar [23] analyzes it, and the result was large-scale rerouting around Africa [50]. In Hormuz, where rerouting is impossible, the same tactics translate directly into war-risk insurance spikes, refusals to transit, and lost supply [16, 21].

### 2.3 Supply Chain Resilience, Shock Propagation, and Economic Adaptation

A separate strand of the literature studies how chokepoint disruptions propagate through supply chains [6, 7, 8, 31, 33]. Li et al. [6] find that geopolitical risk persistently lowers shipping supply chain resilience through freight volatility and port congestion. Koray et al. [7] propose logistics strategies to mitigate such disruptions, Soman and Balasubramanian [32] catalog adaptations at major chokepoints, and Uthpala and Kavirathna [37] synthesize the resilience literature. Feng et al. [31] model supply chain disruption with real-world data, and Luo et al. [39] analyze global supply chain reallocation under recent multiple crises. Khatawkar [12] reviews the economic consequences of contemporary conflicts. Atsalaki et al. [8] apply fuzzy prescriptive analytics to Hormuz disruptions and show that an interdiction would hit energy, fertilizer, and food systems at once. Ayenalem and Endaylalu [41] trace maritime security problems from the Suez Canal to Bab al-Mandab, Kivalov [47] analyzes how maritime activities underpin energy security, Oyenuga [54] documents the COVID shock to maritime transport, and Vogele et al. [30] incorporate maritime and geopolitical risk into energy transition planning. Agastia and Perwita [51] and Prakoso et al. [26] examine Indonesia's maritime interests, the latter drawing lessons from the 2026 war.

Country-level studies show how unevenly the exposure is distributed. Hu et al. [15], Madani [53], and Gholizadeh et al. [52] analyze China's dependence on Hormuz and the partial hedges offered by the China-Pakistan Economic Corridor and Russian pipeline imports. Singh & Kumar [20], Kaushiva [21], and Singh et al. [44] document India's vulnerability, where an oil import shock widens the current account deficit and feeds inflation. Putri and Cahyadi [42] estimate the effects of the conflict on Indonesia's trade balance. In Europe, Dragoi [5] and Ilcus [48] argue that replacing Russian pipeline gas with seaborne LNG has raised European exposure to Persian Gulf instability, while Bachir [18] considers Algeria as an alternative supplier.

Table 1 summarizes the two resilience paradigms used in this literature, and Table 2 lists the structural exposure metrics that define Hormuz's role in the global energy system.

**Table 1. Resilience Frameworks in Maritime Energy Infrastructure (adapted from Kadhim [1])**

| Analytical Dimension | Engineering Resilience Paradigm | Social-Ecological Resilience Paradigm |
|---|---|---|
| Core Objective | Rate and efficiency of return to pre-crisis equilibrium | Capacity to absorb shock, reorganize, and adapt structurally |
| System Assumption | Disruptions are bounded; infrastructure and markets recover | Disruptions induce permanent regime shifts and route restructuring |
| Mitigation Focus | Physical hardening, military escorting, spare capacity buffers | Route diversification, fuel switching, demand management |

**Table 2. Structural Exposure Metrics of the Strait of Hormuz (adapted from Shahi [2] & EIA [56])**

| Metric Indicator | Structural Value | Strategic Implication |
|---|---|---|
| Global Petroleum liquids Share | ~21% of global consumption (~20.9 mb/d) | Largest concentrated point-of-failure in world commerce |
| Global Seaborne Crude Share | ~27% of maritime crude trade | Overwhelming concentration of Asian refinery feedstock |
| Global Seaborne LNG Share | ~20% of international trade (~10.5 bcf/d) | Non-substitutable cryogenic supply for Asian & European power |
| Overland Bypass Capacity Deficit | ~18.3 mb/d of ~20.9 mb/d transit unmitigated | CRS estimates ~2.6 mb/d available bypass capacity (about 12% of transit) |
| LNG Overland Bypass Capacity | Exactly 0.0% (Zero alternative routes) | 100% loss of Qatari/Emirati LNG exports during total closure |

## 3. Physical Geography, Navigational Law, and Downstream Physics

### 3.1 Hydrography, Bathymetry, and Navigational Constraints

The vulnerability of the strait is rooted in its geography [7, 9]. At its narrowest point the waterway is about 29 nautical miles (NM) wide, between the Musandam Peninsula and the Iranian coast [35] (some earlier references cite 21 NM depending on the reference points used), and the navigable channel for deep-draft ships is narrower still. Under the International Maritime Organization (IMO) Traffic Separation Scheme (TSS), commercial traffic is confined to two 2-NM-wide lanes—one inbound, one outbound—separated by a 2-NM buffer.

The TSS lanes lie entirely in Omani territorial waters, while the northern approaches run through Iranian waters around the contested islands of Greater Tunb, Lesser Tunb, and Abu Musa. Laden Very Large Crude Carriers (VLCCs) and Ultra Large Crude Carriers (ULCCs) draw 20.0 to 22.5 meters and are constrained by shallow banks (20–30 m depth contours) along the northern littoral, which rules out evasive maneuvering. Ships must hold fixed coordinates, which makes them vulnerable to bottom-laid magnetic and acoustic mines (for example the MDM-6 and EM-52 series) and to coastal strike systems.

### 3.2 International Maritime Legal Regimes

The legal rules governing passage through the strait have long been contested [16, 24]. Under the 1982 UN Convention on the Law of the Sea (UNCLOS), straits used for international navigation are subject to the **Regime of Transit Passage** (Part III, Articles 37–44), which gives ships and aircraft a non-suspendable right of continuous and expeditious passage and limits coastal state regulation to maritime safety, pollution, and fishing.

Iran signed but never ratified UNCLOS. Tehran argues that the strait is governed by customary law as codified in the 1958 Geneva Convention on the Territorial Sea and the Contiguous Zone, which provides only the weaker right of **Innocent Passage**. Iran's 1993 Marine Areas Act claims the right to require prior authorization for warships and for commercial vessels carrying hazardous cargo, and to suspend passage in its territorial waters during national security crises. The United States, Oman, and most of the maritime community regard transit passage as binding customary law, but Iran's position creates permanent legal ambiguity that can be used to justify interdictions and boardings [16, 21]. Under the law of naval warfare (the 1994 San Remo Manual), belligerents may interdict neutral shipping only under strict conditions; during the 2026 war these limits proved difficult to enforce, and commercial tankers were attacked despite them.

### 3.3 Refinery Chemistry and Crude Quality Incompatibility

One physical dimension that is often left out of geopolitical analysis is the **chemistry of refining slates** [34, 56]. Most crude transiting Hormuz is medium or heavy sour grade: Arab Light (33.4° API, 1.77% S), Arab Heavy (27.4° API, 2.80% S), Kuwait Export (30.5° API, 2.60% S), and Basrah Heavy (24.0° API, 4.10% S).

Complex conversion refineries in Asia—Reliance's Jamnagar complex in India, Sinopec's Zhenhai hub in China, SK Energy's Ulsan refinery in South Korea—have optimized catalytic cracking, coking, and hydrodesulfurization units for exactly these sour barrels. If a Hormuz disruption forces them onto light sweet Atlantic Basin grades (North Sea Brent at 38.3° API, 0.40% S; U.S. WTI at 40.8° API, 0.20% S), they face technical problems: atmospheric distillation and naphtha fractionation become hydraulically overloaded while coking and residue hydrocracking capacity goes unused. Estimates in engineering analyses put the required throughput cut at roughly **15–20%** for complex Asian refiners under full light-sweet substitution; these figures are illustrative and should be verified against refinery-level data.

## 4. Data and Econometric Methodology

### 4.1 Sample Construction and Variable Selection

The daily sample runs from **1 January 2019 to 18 August 2026** (n = 1,875 common trading days; the end date is the most recent observation available when the data were collected). Four core series come from the Federal Reserve Bank of St. Louis Economic Data (FRED) system:

1. **Brent Crude Oil (DCOILBRENTEU)**: international seaborne crude benchmark, USD/barrel.
2. **West Texas Intermediate Crude Oil (DCOILWTICO)**: U.S. benchmark, USD/barrel.
3. **Henry Hub Natural Gas (DHHNGSP)**: U.S. spot gas benchmark, USD/million BTU. Henry Hub tests whether Hormuz risk spills into the U.S. domestic gas market or stays regional.
4. **U.S. Economic Policy Uncertainty Index (USEPUINDXD)**: daily newspaper-based index (Baker, Bloom, and Davis), measuring broad policy uncertainty.

Three supplementary daily series test the mechanism behind the core results, and two monthly series test international gas markets:

5. **CBOE Volatility Index (VIXCLS)**: options-implied 30-day S&P 500 volatility; the standard equity risk gauge.
6. **CBOE Crude Oil ETF Volatility Index (OVXCLS)**: options-implied volatility of crude oil; a market-based, forward-looking measure of oil price risk.
7. **CBOE Gold ETF Volatility Index (GVZCLS)**: options-implied volatility of gold; a safe-haven control.
8. **Global price of LNG, Asia (PNGASJPUSDM)**: World Bank monthly Asian LNG import price, USD/mmBTU.
9. **Global price of Natural Gas, EU (PNGASEUUSDM)**: World Bank monthly European gas import price, USD/mmBTU.

Daily percentage returns are computed as in Eq. (1):

$$r(t) = [P(t) - P(t-1)] / P(t-1) × 100  (1)$$

Realized volatility is defined as the absolute return (Eq. (2)):

$$V(t) = |r(t)|  (2)$$

For the EPU index and the three implied-volatility indices, volatility is the absolute daily change in index points (Eq. (3)):

$$V_EPU(t) = |ΔEPU(t)|,  V_k(t) = |Δk(t)|,  k = VIX, OVX, or GVZ  (3)$$

Table 3 lists the datasets used in the study. The restricted 2019–2026 window of 1,875 trading days applies to every daily series; the monthly gas series run from January 2019 to July 2026 (91 monthly price observations; 90 monthly percentage changes after differencing).

**Table 3. Primary Empirical and Institutional Datasets Analyzed**

| Dataset Identifier | Primary Source | Total Records | Variables | Empirical Role |
|---|---|---|---|---|
| FRED_DCOILBRENTEU | FRED / EIA | 6,946 | 2 | Global seaborne crude price discovery and return volatility |
| FRED_DCOILWTICO | FRED / EIA | 6,946 | 2 | Domestic U.S. crude benchmark and arbitrage pricing |
| FRED_DHHNGSP | FRED / EIA | 6,946 | 2 | U.S. natural gas benchmark (regional market test) |
| FRED_USEPUINDXD | Baker, Bloom & Davis | 9,729 | 2 | Daily macroeconomic and geopolitical policy uncertainty |
| FRED_VIXCLS | CBOE via FRED | 9,256 | 2 | Equity risk appetite control (implied vol., daily) |
| FRED_OVXCLS | CBOE via FRED | 4,853 | 2 | Oil-implied volatility (market-based crisis gauge, daily) |
| FRED_GVZCLS | CBOE via FRED | 4,585 | 2 | Gold (safe-haven) implied volatility control, daily |
| FRED_PNGASJPUSDM | World Bank via FRED | 415 | 2 | Asian LNG import price (monthly) |
| FRED_PNGASEUUSDM | World Bank via FRED | 415 | 2 | European gas import price (monthly) |
| hormuz_event_volatility | Constructed | 6,604 | 6 | Event-window daily volatility series (7, 14, 21, 30 days; analysis restricted to 2019–2026) |
| eia_chokepoint_oil_flows_quarterly | U.S. EIA | 48 | 4 | Quarterly crude and liquids transit volumes across all eight major chokepoints (1Q2025–2Q2026) |
| eia_chokepoint_lng_flows_quarterly | U.S. EIA | 48 | 4 | Quarterly LNG transit volumes across all eight major chokepoints (1Q2025–2Q2026) |
| eia_hormuz_destinations_tidy | U.S. EIA | 54 | 3 | Destination breakdown of Hormuz crude flows (2020–1Q2025) |
| eia_hormuz_origins_tidy | U.S. EIA | 42 | 3 | Origin breakdown of Hormuz crude flows (2020–1Q2025) |

### 4.2 Documented Incident Matrix and Event-Window Construction

The study covers **eleven incidents** between 2019 and 2026 that involved maritime security in the Strait of Hormuz or threatened escalation across the Persian Gulf. Inclusion requires one of: documented state-level or proxy military action, commercial tanker interdiction, missile strikes on energy infrastructure, or an official closure declaration. Table 15 (Appendix B) lists the incidents with their individual rationales. Throughout the paper we use "sub-kinetic incidents" for episodes that threaten or harass shipping without interrupting physical transit (the 2019-2025 events), "hybrid conflict" for the asymmetric tactics described in Section 2.2, and "gray-zone conflict" for confrontations below the threshold of formal interstate war; the 2026 war and closure is the only episode of realized physical interdiction in the sample.

For incident date T_k (k = 1, ..., 11) we define a forward-looking crisis window of W = 7, 14, 21, or 30 calendar days (Eq. (4)):

$$Crisis_k(W) = [T_k, T_k + W]  (4)$$

Because the incident day itself is included, each "W-day" window spans W + 1 calendar dates; the same convention applies to the pre-incident control windows [T_k - 2W, T_k - W - 1]. Overlapping days from nearby incidents (for example the Soleimani strike on 2020-01-03 and the Iranian missile response on 2020-01-08) are merged by union so that no day is counted twice.

### 4.3 Counterfactual Control Designs and Econometric Inference

Three control designs are used:

1. **Design 1: Broad Contemporaneous Baseline.** Crisis days are compared with all other days in the 2019–2026 sample. This asks whether Hormuz flare-ups stand out from general market conditions over the whole period.
2. **Design 2: Pre-Incident Regime Control.** Crisis days [T_k, T_k + W] are compared with the immediately preceding window [T_k - 2W, T_k - W - 1], excluding days inside any other crisis window. This holds the prevailing regime fixed and removes secular trends.
3. **Design 3: 2026 Physical Closure Isolate.** Post-closure windows after 28 February 2026 are compared with the immediate pre-closure window, isolating the effect of a realized interdiction from the effect of threats.

Three inference methods are used throughout; all p-values are two-sided:

- **Welch t-test**, which allows unequal variances; p-values are reported raw and Bonferroni-adjusted (family of four core variables in Tables 4–7; family of three supplementary variables in Tables 8–9).
- **Newey-West HAC regression**, which estimates Eq. (5):

$$V(t) = α + β · D_crisis(t) + ε(t)  (5)$$

with HAC standard errors (Bartlett kernel, lag q = W × 5/7 trading days, rounded down) to handle serial correlation from overlapping windows. The lag rule was specified in advance as the window length in trading days; Section 5.7 reports sensitivity to alternative specifications.

- **Quarter-clustered standard errors** (31 calendar quarters in the sample), to absorb time-varying volatility regimes. Thirty-one clusters is modest for cluster-robust asymptotics, and because treatment occurs in only eleven episodes, the clustered and HAC results are best read together with the incident-level checks in Section 5.7.

Effect sizes are reported as Cohen's d (Eq. (6)):

$$d = (μ_crisis - μ_control) / s_pooled,  s_pooled = √[((n1 - 1)s1² + (n2 - 1)s2²) / (n1 + n2 - 2)]  (6)$$

For the monthly gas analysis (Section 5.6) we use a monthly-frequency event study: a crisis month is the month of an incident plus the two following months (union across incidents), and absolute monthly percentage changes in crisis months are tested against all other months with the same Welch inference. Year-on-year comparisons at the same season (e.g., March–May 2026 versus March–May 2025) control for gas-price seasonality around the 2026 closure.

## 5. Empirical Results

### 5.1 Design 1: The Broad Contemporaneous Baseline Null

Against the broad 2019–2026 baseline, neither Brent nor WTI shows a significant positive volatility premium at any window length (Table 4; volatility as defined in Eq. (2)). At 14 days, Brent crisis volatility averages 2.27% against 2.02% in calm periods (t = 1.055, p = 0.294), and WTI 2.25% against 2.28% (t = -0.089, p = 0.929).

Henry Hub volatility is actually **lower** in crisis windows than in calm periods at every window length (14-day: 3.25% vs 5.26%, t = -4.490, p < 0.001, Newey-West p = 0.003, clustered p = 0.005). This is a composition artifact, not a real negative effect: the 2022–2023 U.S. gas crisis, which produced the largest absolute returns in the sample, falls entirely outside the incident windows and inflates the calm mean. The lesson is that a long, unadjusted baseline is easily contaminated by unrelated macroeconomic episodes.

**Table 4. Econometric Results: Design 1 Broad Baseline (14-Day Windows)**

| Market Series & Sample | Crisis Mean | Calm Mean | Welch t | p (Raw) | p (Bonf) | p (NW-HAC) | p (Clustered) | Cohen's d |
|---|---|---|---|---|---|---|---|---|
| Brent Crude (Full Sample) | 2.268% | 2.024% | 1.055 | 0.294 | 1.000 | 0.499 | 0.600 | +0.095 |
| WTI Crude (Full Sample) | 2.248% | 2.277% | -0.089 | 0.929 | 1.000 | 0.957 | 0.965 | -0.005 |
| Henry Hub Gas (Full Sample) | 3.254% | 5.256% | -4.490 | <0.001 | <0.001 | 0.003 | 0.005 | -0.218 |
| U.S. EPU (Full Sample) | 60.05 | 66.56 | -1.031 | 0.305 | 1.000 | 0.483 | 0.496 | -0.095 |
| Brent Crude (Ex-2026) | 1.920% | 1.922% | -0.010 | 0.992 | 1.000 | 0.994 | 0.996 | -0.001 |
| WTI Crude (Ex-2026) | 1.806% | 2.238% | -1.474 | 0.141 | 0.566 | 0.293 | 0.411 | -0.070 |
| Henry Hub Gas (Ex-2026) | 3.204% | 5.039% | -4.086 | <0.001 | <0.001 | 0.006 | 0.010 | -0.226 |
| U.S. EPU (Ex-2026) | 53.14 | 64.22 | -1.849 | 0.067 | 0.268 | 0.169 | 0.170 | -0.170 |

*Note: EPU means are absolute daily index-point changes; all other means are absolute daily returns (%).*

### 5.2 Design 2: Pre-Incident Regime Control and the Oil Volatility Premium

Compared with the immediate pre-incident window, oil volatility rises after Hormuz incidents (Table 5; Figure 1). At 14 days, Brent volatility increases by 52.4% over pre-incident levels (2.27% vs 1.49%; Welch t = 2.978, p = 0.003, Bonferroni p = 0.013). WTI rises by 66.7% (2.25% vs 1.35%; t = 3.217, p = 0.002, Bonferroni p = 0.006). These 14-day effects are, however, only borderline under serial-correlation-robust inference: Newey-West p = 0.051 (Brent) and 0.058 (WTI), and quarter-clustered p = 0.079 and 0.062. At the standard 5% level the short-horizon premium is significant under the Welch test but not under the robust corrections, and we describe it as suggestive at 14 days.

The picture is much stronger at longer horizons (Table 6). At 21 days, Brent crisis volatility averaged 2.34% against 1.34% in the pre-incident window; at 30 days, 2.28% against 1.26% (WTI: 2.16% vs 1.34% at 21 days; 2.12% vs 1.36% at 30 days). The widening gap reflects a declining pre-incident baseline as windows lengthen rather than a rising crisis response; what strengthens is the statistical evidence, which becomes robust under every inference method (Brent 30-day t = 6.090, p < 0.001, Newey-West p = 0.001, clustered p = 0.001; WTI t = 4.570, p < 0.001).

Excluding 2026, Brent and WTI volatility remain significantly elevated at 14 days under the Welch test (Brent p = 0.032; WTI p = 0.027), though not after Bonferroni adjustment or under HAC/clustered inference; at 21 and 30 days the effects are strongly significant (p < 0.001 for Brent under every inference method, and p = 0.001 for WTI). By contrast, Henry Hub (t = -1.592, p = 0.114) and the EPU index (t = 1.721, p = 0.087) show no robust crisis elevation. In the markets we observe, Hormuz shocks appear to be oil-specific; the gas conclusion applies to U.S. domestic gas (Henry Hub) and is qualified by the international gas evidence in Section 5.6.

**Table 5. Econometric Results: Design 2 Pre-Incident Window Control (14-Day Windows)**

| Market Series & Sample | Crisis Mean | Pre-Inc Mean | Welch t | p (Raw) | p (Bonf) | p (NW-HAC) | p (Clustered) | Cohen's d |
|---|---|---|---|---|---|---|---|---|
| Brent Crude (Full Sample) | 2.268% | 1.488% | 2.978 | 0.003 | 0.013 | 0.051 | 0.079 | +0.423 |
| WTI Crude (Full Sample) | 2.248% | 1.349% | 3.217 | 0.002 | 0.006 | 0.058 | 0.062 | +0.451 |
| Henry Hub Gas (Full Sample) | 3.254% | 4.895% | -1.592 | 0.114 | 0.457 | 0.339 | 0.385 | -0.241 |
| U.S. EPU (Full Sample) | 60.05 | 47.42 | 1.721 | 0.087 | 0.348 | 0.168 | 0.077 | +0.245 |
| Brent Crude (Ex-2026) | 1.920% | 1.439% | 2.166 | 0.032 | 0.127 | 0.087 | 0.133 | +0.328 |
| WTI Crude (Ex-2026) | 1.806% | 1.281% | 2.238 | 0.027 | 0.107 | 0.095 | 0.087 | +0.334 |
| Henry Hub Gas (Ex-2026) | 3.204% | 2.957% | 0.521 | 0.603 | 1.000 | 0.674 | 0.618 | +0.079 |
| U.S. EPU (Ex-2026) | 53.14 | 44.67 | 1.225 | 0.222 | 0.890 | 0.321 | 0.136 | +0.184 |

*Note: Bonferroni-adjusted p-values are computed on the unrounded raw p-values (e.g., Brent raw p = 0.0033 gives 4 x 0.0033 = 0.0132; WTI raw p = 0.0016 gives 0.0064). EPU means are absolute daily index-point changes; all other means are absolute daily returns (%).*

![Figure 1: Mean absolute daily returns and changes in 14-day crisis vs pre-incident windows](figures/fig1_crisis_pre_volatility.png)

*Figure 1. Mean absolute daily return volatility (crude oil, natural gas) and absolute point changes (EPU index) during 14-day crisis windows compared against 14-day pre-incident baselines. Asterisks denote statistical significance at p < 0.05 under Welch t-tests. Panel (a) full sample 2019–2026; panel (b) ex-2026 sample.*

**Table 6. Multi-Horizon Window Sensitivity Analysis (Design 2 Welch t-stats and p-values)**

| Market Series | Sample Sub-Set | 7-Day Window t (p) | 21-Day Window t (p) | 30-Day Window t (p) |
|---|---|---|---|---|
| Brent Crude Oil | Full Sample (2019–2026) | 2.410 (0.018) | 4.950 (<0.001) | 6.090 (<0.001) |
| WTI Crude Oil | Full Sample (2019–2026) | 1.680 (0.097) | 3.940 (<0.001) | 4.570 (<0.001) |
| Henry Hub Natural Gas | Full Sample (2019–2026) | -0.610 (0.546) | -1.960 (0.053) | -1.640 (0.102) |
| U.S. EPU Index | Full Sample (2019–2026) | 0.990 (0.326) | 0.260 (0.799) | 0.550 (0.586) |
| Brent Crude Oil | Ex-2026 Subsample | 1.330 (0.188) | 4.420 (<0.001) | 5.540 (<0.001) |
| WTI Crude Oil | Ex-2026 Subsample | 0.870 (0.388) | 3.230 (0.001) | 3.360 (0.001) |
| Henry Hub Natural Gas | Ex-2026 Subsample | -0.660 (0.511) | 1.320 (0.187) | 0.570 (0.568) |
| U.S. EPU Index | Ex-2026 Subsample | 0.580 (0.565) | -0.120 (0.904) | 0.480 (0.634) |

### 5.3 Design 3: The 2026 Physical Closure Shock

The closure of the strait on 28 February 2026 is the dominant shock in the sample (Table 7). Unlike the earlier incidents, it combined military action with an actual, sustained loss of supply.

In the 14 days after the closure, Brent volatility averaged 4.25% against 1.86% before (t = 2.377, p = 0.025, d = +0.823). WTI reached 4.72% against 1.85% (t = 2.927, p = 0.007, Bonferroni p = 0.028, Newey-West p = 0.053, d = +0.973). At 30 days both benchmarks were still highly elevated (Brent mean 4.02%, t = 3.141, p = 0.003; WTI mean 3.67%, t = 3.438, p = 0.001).

EPU volatility also rose (68.08 to 110.38 points at 14 days), but the evidence is mixed: the Welch test is insignificant (t = 1.702, p = 0.104; Bonferroni p = 0.414) while the HAC and clustered tests are significant (p < 0.001 and 0.011), and at 30 days no test is significant (p = 0.462). The large HAC-clustered discrepancies reflect the small post-closure sample (20-40 trading days) and strong serial dependence; we read the EPU evidence as suggestive of a policy-uncertainty response rather than conclusive, and the caveat applies to the interpretation below.

**Table 7. Econometric Results: Design 3 — 2026 Physical Closure in Isolation**

| Asset Series | Horizon | Post-Closure | Pre-Closure | Welch t | p (Raw) | p (Bonf) | p (NW-HAC) | p (Clust) | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|
| Brent Crude | 7-Day | 4.913% | 1.547% | 2.848 | 0.016 | 0.062 | 0.026 | 0.156 | +1.289 |
| WTI Crude | 7-Day | 4.580% | 1.655% | 2.113 | 0.057 | 0.227 | 0.060 | 0.091 | +0.958 |
| Henry Hub Gas | 7-Day | 6.528% | 3.450% | 1.654 | 0.128 | 0.510 | 0.113 | 0.289 | +0.746 |
| U.S. EPU Index | 7-Day | 134.79 | 76.17 | 1.588 | 0.132 | 0.529 | 0.028 | <0.001 | +0.750 |
| Brent Crude | 14-Day | 4.252% | 1.856% | 2.377 | 0.025 | 0.098 | 0.088 | 0.086 | +0.823 |
| WTI Crude | 14-Day | 4.717% | 1.854% | 2.927 | 0.007 | 0.028 | 0.053 | 0.114 | +0.973 |
| Henry Hub Gas | 14-Day | 5.235% | 19.426% | -2.133 | 0.060 | 0.241 | 0.017 | <0.001 | -0.941 |
| U.S. EPU Index | 14-Day | 110.38 | 68.08 | 1.702 | 0.104 | 0.414 | <0.001 | 0.011 | +0.641 |
| Brent Crude | 21-Day | 4.267% | 2.119% | 2.737 | 0.009 | 0.037 | 0.026 | 0.086 | +0.789 |
| WTI Crude | 21-Day | 3.793% | 1.928% | 2.470 | 0.018 | 0.072 | 0.030 | 0.061 | +0.683 |
| Henry Hub Gas | 21-Day | 4.581% | 48.410% | -2.518 | 0.026 | 0.103 | <0.001 | <0.001 | -0.951 |
| U.S. EPU Index | 21-Day | 114.61 | 80.41 | 1.559 | 0.128 | 0.510 | 0.045 | <0.001 | +0.471 |
| Brent Crude | 30-Day | 4.021% | 2.092% | 3.141 | 0.003 | 0.011 | 0.051 | 0.071 | +0.742 |
| WTI Crude | 30-Day | 3.673% | 1.642% | 3.438 | 0.001 | 0.005 | 0.027 | 0.028 | +0.808 |
| Henry Hub Gas | 30-Day | 3.844% | 29.593% | -1.874 | 0.077 | 0.309 | 0.033 | <0.001 | -0.607 |
| U.S. EPU Index | 30-Day | 132.73 | 114.09 | 0.743 | 0.462 | 1.000 | 0.120 | 0.380 | +0.206 |

*Note: The negative Henry Hub differentials in this specification reflect extreme pre-closure U.S. gas volatility in early February 2026 (Section 5.6) and are not interpretable as crisis effects. The HAC and clustered p-values for the closure windows are based on 20-40 post-closure trading days and strong serial dependence; they should be interpreted with caution.*

### 5.4 Physical Flow Accounting: EIA Quarterly Evidence

The market results are consistent with what actually happened to physical flows, as documented by the EIA [57] (Figure 2). The compiled quarterly series cover all eight major chokepoints from 1Q2025 through 2Q2026, which lets us see the Hormuz collapse against the global reallocation. Crude and petroleum liquids transiting the strait averaged **21.6 mb/d in 4Q2025**, fell to **14.9 mb/d in 1Q2026**, and to **4.9 mb/d in 2Q2026**—a **77.3% contraction (16.7 mb/d)**. These figures come from the chokepoint flow dataset compiled for this study from EIA data (datasets/raw/eia_chokepoint_oil_flows_quarterly.csv); EIA has published slightly different figures in other releases (e.g., 20.7 mb/d for 4Q2025 and 14.6 mb/d for 1Q2026 in some vintages), and the precise data vintage should be verified against [57] before submission.

LNG fell even harder: from **10.5 bcf/d in 4Q2025** to **7.4 bcf/d in 1Q2026** and **0.8 bcf/d in 2Q2026**, a **92.4% contraction**. With Qatari and Emirati exports effectively off the market, roughly 18% of global LNG trade disappeared, and spot prices in Asia and Europe reacted accordingly (Section 5.6).

The multi-chokepoint panel also shows how the market adjusted. LNG transiting the Cape of Good Hope rose from 6.0 bcf/d in 4Q2025 to **9.7 bcf/d in 2Q2026 (+62%)**, and Malacca LNG transit fell from 10.1 to 5.5 bcf/d (-45%) as Persian Gulf cargoes stopped loading. Crude and products through Malacca fell from 24.9 to 16.6 mb/d (-33%). Rerouting and demand destruction absorbed part of the shock, but at large freight and insurance cost (Section 6.2).

![Figure 2: Quarterly petroleum liquids and LNG transit flows through the world's major chokepoints (2025–2026)](figures/fig2_hormuz_quarterly_flows.png)

*Figure 2. Quarterly throughput of crude oil and petroleum products (panel a, million barrels per day) and liquefied natural gas (panel b, billion cubic feet per day) across the eight major maritime chokepoints from 1Q2025 through 2Q2026. The shaded band denotes the active conflict period; the Strait of Hormuz is highlighted in red. Source: EIA chokepoint quarterly flow data compiled for this study.*

### 5.5 Supplementary Risk-Appetite Series: Oil-Specificity Under Market-Based Gauges

The same event-window framework applied to the three options-implied volatility indices shows that the oil result is not a proxy for general risk, with an important caveat (Table 8; volatility as in Eq. (3)). The implied-volatility series are strongly autocorrelated, and the daily-change tests on them do not survive Newey-West or clustered corrections; we therefore treat the implied-volatility evidence as descriptive. Under the pre-incident control, OVX (crude oil implied volatility) moves in the same direction as spot oil volatility: its absolute daily change averages 2.79 points versus 1.49 before at 14 days (Welch t = 3.69, p < 0.001, Bonferroni p = 0.001) and 2.34 versus 1.24 at 30 days (t = 5.14, p < 0.001), and the raw differential also holds in the ex-2026 sample (t = 3.59 and 4.60). These effects are, however, not robust to Newey-West or clustered adjustments (NW p = 0.375 and 0.947 at 14 and 30 days), which absorb the strong autocorrelation; the OVX premium is best read as a shift in the level of priced oil risk whose statistical significance cannot be established at daily frequency with these data.

Equity and gold volatility behave differently. The VIX shows no significant crisis differential in either sample at any window length (14-day full sample: t = 0.86, p = 0.391; 30-day: t = 0.76, p = 0.447). The gold GVZ is significant only in the ex-2026 14-day specification under Welch inference (t = 2.88, p = 0.004, Bonferroni p = 0.013) and not under Newey-West. Sub-kinetic Hormuz incidents thus show no consistent response in equity or safe-haven volatility, in contrast to the raw OVX pattern.

**Table 8. Supplementary Risk-Appetite Series: Design 2 Pre-Incident Control**

| Series | Sample | Window | Crisis Mean | Pre-Inc Mean | Welch t | p (Raw) | p (Bonf) | p (NW-HAC) | p (Clustered) | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|
| VIX | Full | 14-Day | 1.04 | 0.91 | 0.86 | 0.391 | 1.000 | 0.300 | 0.414 | +0.13 |
| OVX | Full | 14-Day | 2.79 | 1.49 | 3.69 | <0.001 | 0.001 | 0.375 | 0.476 | +0.52 |
| GVZ | Full | 14-Day | 0.77 | 0.66 | 0.81 | 0.418 | 1.000 | 0.702 | 0.718 | +0.12 |
| VIX | Full | 30-Day | 1.13 | 1.03 | 0.76 | 0.447 | 1.000 | 0.578 | 0.623 | +0.08 |
| OVX | Full | 30-Day | 2.34 | 1.24 | 5.14 | <0.001 | <0.001 | 0.947 | 0.954 | +0.51 |
| GVZ | Full | 30-Day | 0.84 | 0.65 | 1.94 | 0.053 | 0.160 | 0.423 | 0.481 | +0.20 |
| VIX | Ex-2026 | 14-Day | 0.91 | 0.84 | 0.54 | 0.590 | 1.000 | 0.030* | 0.099 | +0.08 |
| OVX | Ex-2026 | 14-Day | 2.41 | 1.33 | 3.59 | <0.001 | 0.001 | 0.724 | 0.782 | +0.53 |
| GVZ | Ex-2026 | 14-Day | 0.70 | 0.42 | 2.88 | 0.004 | 0.013 | 0.743 | 0.776 | +0.43 |
| VIX | Ex-2026 | 30-Day | 1.03 | 1.04 | -0.08 | 0.935 | 1.000 | 0.191 | 0.230 | -0.01 |
| OVX | Ex-2026 | 30-Day | 2.05 | 1.20 | 4.60 | <0.001 | <0.001 | 0.660 | 0.702 | +0.48 |
| GVZ | Ex-2026 | 30-Day | 0.68 | 0.57 | 1.30 | 0.195 | 0.584 | 0.850 | 0.881 | +0.14 |

*Note: Volatility is the absolute daily index-point change. Bonferroni adjustment is over the three supplementary variables. The starred VIX entry carries a negative Newey-West t-statistic (-2.17), indicating no positive crisis differential once autocorrelation is accounted for.*

The 2026 closure produced a broader response (Table 9). VIX volatility spiked in the week after the closure (7-day mean 2.34 vs 0.57, t = 3.90, p = 0.003, Bonferroni p = 0.008, Newey-West p = 0.002, d = +1.76) and remained elevated at 30 days (t = 2.27, p = 0.029). OVX rose persistently across all horizons (14-day t = 2.47, p = 0.020; 21-day t = 2.93, p = 0.006; 30-day t = 3.84, p < 0.001, with Newey-West and clustered p-values below 0.001). Gold volatility fell in the 21-day window (1.25 vs 3.08, t = -3.13, p = 0.007, d = -1.12); we interpret this cautiously, since a decline in the volatility of gold-implied-volatility changes is suggestive of calmer safe-haven pricing but does not by itself measure gold purchases or holdings. The closure is the one episode in which Hormuz risk stopped being oil-specific and broadened to equity and policy markets, matching the EPU response in Table 7 (which, as noted there, is itself only suggestive).

**Table 9. Supplementary Risk-Appetite Series: Design 3 — 2026 Closure in Isolation**

| Series | Horizon | Post-Closure | Pre-Closure | Welch t | p (Raw) | p (Bonf) | p (NW-HAC) | p (Clust) | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|
| VIX | 7-Day | 2.34 | 0.57 | 3.90 | 0.003 | 0.008 | 0.002 | <0.001 | +1.76 |
| OVX | 7-Day | 7.33 | 2.62 | 2.06 | 0.060 | 0.179 | <0.001 | <0.001 | +0.94 |
| GVZ | 7-Day | 1.45 | 1.05 | 0.79 | 0.440 | 1.000 | 0.462 | 0.359 | +0.38 |
| VIX | 14-Day | 1.81 | 1.49 | 0.57 | 0.577 | 1.000 | 0.028 | 0.011 | +0.22 |
| OVX | 14-Day | 6.10 | 2.69 | 2.47 | 0.020 | 0.061 | <0.001 | <0.001 | +0.82 |
| GVZ | 14-Day | 1.12 | 2.45 | -1.96 | 0.076 | 0.229 | 0.901 | 0.877 | -0.85 |
| VIX | 21-Day | 1.67 | 1.50 | 0.35 | 0.730 | 1.000 | 0.091 | 0.049 | +0.11 |
| OVX | 21-Day | 5.51 | 2.19 | 2.93 | 0.006 | 0.017 | <0.001 | <0.001 | +0.82 |
| GVZ | 21-Day | 1.25 | 3.08 | -3.13 | 0.007 | 0.020 | 0.754 | 0.669 | -1.12 |
| VIX | 30-Day | 1.54 | 0.80 | 2.27 | 0.029 | 0.086 | 0.095 | 0.064 | +0.61 |
| OVX | 30-Day | 4.67 | 1.60 | 3.84 | <0.001 | 0.001 | 0.001 | <0.001 | +0.88 |
| GVZ | 30-Day | 1.54 | 1.38 | 0.37 | 0.716 | 1.000 | 0.402 | 0.290 | +0.10 |

### 5.6 International Gas Markets: The Regional Segmentation of the 2026 LNG Shock

To test whether Hormuz risk is priced outside the U.S. domestic gas market, we repeat the exercise at monthly frequency with international gas prices (Table 10). Crisis months (incident month plus the two following months, union across incidents) number 26 of 90 monthly percentage changes in 2019–2026. Absolute monthly changes in crisis months do not differ from other months for Asian LNG (t = -0.80, p = 0.429), European gas (t = -1.54, p = 0.128), or Henry Hub (t = -0.71, p = 0.481). In the ex-2026 sample the LNG Asia and EU tests are significantly negative (p = 0.030 and 0.021): gas markets were calmer, not more volatile, in incident months before 2026, since the largest gas-market swings of 2021–2022 fall outside incident months. Before physical interdiction, gas markets did not price Hormuz threats, in any region.

The 2026 closure changed that, and the regional split is stark (Figure 3). Between the pre-closure window (November 2025–January 2026) and the post-closure window (March–May 2026), Asian LNG rose from a mean of $10.47 to $18.49 per mmBTU (+76.6%) and European gas from $10.60 to $16.41 (+54.8%), while Henry Hub fell from $5.26 to $2.92 (-44.5%). Because the pre/post comparison spans winter and spring, same-season year-on-year comparisons are more reliable: in March–May, Asian LNG averaged $18.49 in 2026 against $12.12 in 2025 (**+52.6%**), European gas $16.41 against $12.12 (**+35.4%**), and Henry Hub $2.92 against $3.55 (**-17.7%**). Monthly year-on-year changes for Asian LNG ranged from +32.6% (June) to +59.5% (July); Henry Hub was below its 2025 level in four of the five months.

The pattern fits the structure described in Section 2. The U.S. market is supplied domestically and insulated from seaborne LNG scarcity; its January 2026 spike (a U.S. winter heating episode) normalized over the spring. Asian and European importers, by contrast, competed for a much smaller pool of spot LNG after Qatari and Emirati exports were cut off. Hormuz risk is priced in international gas markets even though it is invisible in U.S. domestic price volatility.

**Table 10. Monthly International Gas Event Study and 2026 Closure Response**

| Series | Crisis Months | Other Months | Mean abs. change (crisis) | Mean abs. change (other) | Welch t (full) | p (full) | Welch t (ex-2026) | p (ex-2026) |
|---|---|---|---|---|---|---|---|---|
| LNG Asia | 26 | 64 | 15.17% | 18.65% | -0.80 | 0.429 | -2.23 | 0.030 |
| Natural Gas EU | 26 | 64 | 13.51% | 18.43% | -1.54 | 0.128 | -2.36 | 0.021 |
| Henry Hub | 26 | 64 | 12.97% | 15.34% | -0.71 | 0.481 | -1.13 | 0.263 |

| Series | Spring 2025 mean (Mar–May) | Spring 2026 mean (Mar–May) | Same-season YoY | Jan–Jul 2026 change |
|---|---|---|---|---|
| LNG Asia | $12.12 | $18.49 | +52.6% | +87.5% |
| Natural Gas EU | $12.12 | $16.41 | +35.4% | +49.6% |
| Henry Hub | $3.55 | $2.92 | -17.7% | -62.6% |

*Note: The Welch tests use absolute monthly percentage changes; 26 crisis months plus 64 other months equal 90 observations, the 90 percentage changes obtained from 91 monthly price observations (January 2019 to July 2026) after differencing. Crisis months = incident month plus the two following months, union across the eleven incidents. Prices in USD per million BTU (World Bank Global Economic Monitor via FRED; EIA Henry Hub via FRED).*

![Figure 3: Regional gas price divergence during the 2026 Hormuz closure](figures/fig3_gas_price_divergence.png)

*Figure 3. Monthly gas prices, January 2024–July 2026: Asian LNG (red), European gas (blue), and U.S. Henry Hub (green). The shaded band marks the post-closure period from March 2026. The January 2026 Henry Hub spike reflects a U.S. winter heating-demand episode; the subsequent divergence between international and U.S. domestic gas prices tracks the Hormuz closure. Source: World Bank GEM commodity prices and EIA via FRED.*

### 5.7 Robustness Checks

Because treatment occurs in only eleven episodes and inference is pooled over daily observations, we subject the core Design-2 14-day oil result to four checks (Table 11). First, **leave-one-event-out**: dropping any single incident leaves the Brent Welch test significant at p = 0.013 or better (t between 1.94 and 3.18); removing the 2026 closure is the only case with p above 0.05 (p = 0.054), and Newey-West p-values range from 0.034 to 0.114. The result is not driven by any one episode. Second, a **placebo-date permutation test**: we draw 500 random sets of eleven non-incident dates and rerun the same test. The observed statistics are larger than 86% (Brent) and 82% (WTI) of the placebo designs (empirical p = 0.138 and 0.182), which is suggestive but not significant under a strict permutation standard. Third, **exclusion of confounder periods**: the COVID crash (February-April 2020) and the Russia-Ukraine energy crisis (February 2022-February 2023) contain no Design-2 crisis or pre-window days at the 14-day horizon, so results are identical; the pre-window design already keeps those episodes out of the comparison. Fourth, a **VIX-controlled regression** of volatility on the crisis indicator and the VIX level (Newey-West) yields a crisis coefficient of 0.43 for both benchmarks that is not significant (t = 1.47, p = 0.144 for Brent; t = 1.35, p = 0.178 for WTI), because the VIX level absorbs much of the volatility clustering; at 21- and 30-day windows the crisis coefficients remain significant under the same specification (not tabulated).

Taken together, the 14-day oil premium is significant under the Welch test, survives leave-one-event-out and confounder exclusion, but does not survive a placebo-permutation standard or a VIX-controlled regression; we therefore describe the short-horizon effect as suggestive. The 21- and 30-day results, which are robust across all inference methods, are the reliable core of the oil finding.

Event-level evidence is consistent with this reading (Figure 4). At 14-day windows, the pooled premium is concentrated in the episodes with the largest realized escalation risk: the 2026 closure is the strongest individual event (Brent crisis mean 5.57% vs 1.86% pre-incident, t = 2.65, p = 0.021; WTI 6.44% vs 1.85%, t = 3.43, p = 0.006), and the 2023 regional escalation is the only other episode significant at the 5% level for Brent (t = 2.23, p = 0.049). The 2019 tanker incidents show no individual elevation, which is unsurprising given 10-15 days of data per event; the pooled design provides the power that single episodes lack. Alternative volatility measures point the same way (Appendix A, Table 14): squared returns (14-day Welch t = 2.82 for Brent, p = 0.006; 30-day t = 5.01, p < 0.001) and |log returns| (30-day t = 6.11, p < 0.001) confirm the oil result, and implied-volatility **levels** are significantly higher in crisis windows (OVX 14-day t = 4.80, p < 0.001; 30-day t = 7.89, p < 0.001; VIX 14-day t = 3.40, p = 0.001). The level-based implied-volatility evidence is thus stronger than the daily-change tests, though it is subject to the same autocorrelation caveats.

![Figure 4: Brent volatility by incident, 14-day windows](figures/fig4_event_by_incident.png)

*Figure 4. Mean absolute daily Brent returns in the 14-day crisis window and the 14-day pre-incident window for each of the eleven incidents. Asterisks mark Welch t-test significance at p < 0.05. The 2026 closure shows the largest per-event effect.*

**Table 11. Robustness Checks for the Design-2 14-Day Oil Volatility Premium**

| Check | Brent | WTI |
|---|---|---|
| Baseline Welch t (p) | 2.98 (0.003) | 3.22 (0.002) |
| Leave-one-event-out: Welch t range | 1.94-3.18 | 1.96-3.61 |
| Leave-one-event-out: Welch p range | 0.002-0.054 | <0.001-0.052 |
| Leave-one-event-out: Newey-West p range | 0.034-0.114 | 0.028-0.132 |
| Placebo empirical p (500 draws) | 0.138 | 0.182 |
| Ex-COVID / ex-Ukraine Welch p | 0.003 / 0.003 | 0.002 / 0.002 |
| VIX-controlled crisis coefficient (t, p) | 0.43 (1.47, 0.144) | 0.43 (1.35, 0.178) |

*Note: Leave-one-event-out re-estimates the Design-2 14-day test with each of the eleven incidents removed in turn. The placebo test draws 500 random sets of eleven non-incident dates and reports the share of draws with |t| at least as large as the observed statistic (seed fixed at 42 for reproducibility). The VIX-controlled regression adds the VIX level to the crisis regression with Newey-West standard errors. Full results in analysis/reanalysis/robustness_report.md.*

## 6. Economic Discussion: Transmission Mechanisms and Market Structure

### 6.1 The Anatomy of the Hormuz Risk Premium

The results also explain why sub-kinetic crises produce temporary oil volatility spikes without broad contagion, while a physical closure does both.

During sub-kinetic incidents (the 2019 tanker attacks, the Stena Impero seizure, the 2024 missile exchanges), physical flows through the strait were essentially unimpaired. Markets priced the threat of disruption rather than realized scarcity: prompt Brent and WTI contracts became more volatile as hedgers and speculators repriced the risk, and the options market's assessment of crude price risk moved in the same direction (Section 5.5, descriptive). But because barrels kept loading at Ras Tanura, Das Island, and Mina Al Ahmadi, physical markets did not tighten, and volatility mean-reverted within one to two months.

Henry Hub remained insulated from all of this. U.S. liquefaction capacity (Sabine Pass, Corpus Christi, Freeport) cannot quickly be expanded, so domestic gas cannot surge overseas to replace Persian Gulf volumes. Henry Hub prices are set by North American storage and weather, not by Middle Eastern incidents. That is why no gas premium shows up in the event windows.

### 6.2 Maritime Logistics, Cape Rerouting, and War Risk Insurance

When interdiction is real, the transmission channel shifts from hedging to logistics and insurance [10, 21]. Lloyd's Joint War Committee lists the Persian Gulf, Gulf of Oman, and adjacent waters as a war-risk area. Industry sources report hull war risk premiums of roughly **0.025% of insured hull value** in calm periods, rising to **0.50%–0.75%** in acute crises and about **1.2%** at the peak of the 2026 conflict; these are indicative market ranges reported in the shipping literature (see [10, 21]), and primary policy-rate data were not available for this study. For a VLCC valued at $120 million, a 0.75% premium adds **$900,000 per 7-day voyage**, which erases vessel operating margins.

Rerouting is expensive as well. Taking Arabian Sea traffic around the Cape of Good Hope instead of through the Suez system adds roughly **4,800–6,000 nautical miles**, or **14–18 days of steaming at 14 knots** (4,800 NM at 14 knots is about 14.3 days; 6,000 NM about 17.9), between Persian Gulf load ports and European discharge ports; distance estimates vary with the exact route and port pair [10, 50]. Ton-mile demand for crude carriers rises by an estimated **35–45%**, which creates a synthetic shortage of VLCCs and drives Baltic Dirty Tanker Index (BDTI) rates to record levels. The quarterly flow panel in Section 5.4 shows the physical footprint: Cape LNG transit rose 62% between 4Q2025 and 2Q2026 even as Hormuz LNG transit collapsed by 92%.

### 6.3 Strategic Inventory Asymmetries and Asian Macroeconomic Exposure

The closure also exposed how unevenly crisis buffers are distributed. Global spare crude production capacity is roughly 4.4 mb/d, and more than 75% of it is inside the Persian Gulf [34]. A Hormuz interdiction would trap not only export flows but also the swing capacity designed to replace them.

Destination-level data from EIA/Vortexa sources quantify the concentration of Asian exposure (Table 12): between 2020 and 2024, 79.9%–83.7% of Hormuz crude went to Asia (China, India, Japan, South Korea, and other Asian buyers), and the share reached **89.2% in 1Q2025**. China alone took 5.35 mb/d in 1Q2025 (37.6% of the total), India 2.08 mb/d, South Korea 1.70 mb/d, and Japan 1.55 mb/d. These numbers confirm the "over 80%" figure used in the institutional literature [56, 35] with measured flows.

Strategic reserves are the only buffer against a real cutoff, and they are highly asymmetric [57]. China holds about **1,541 million barrels** of crude in strategic and commercial inventories (roughly 115 days of net imports); the U.S. government SPR holds about **413 million barrels** (plus large commercial stocks). India, by contrast, has about 9.5 days of strategic reserves in rock caverns at Visakhapatnam, Mangalore, and Padur [21, 44]. Model-based estimates in the scenario literature put the real GDP loss from a sustained 50% flow contraction at **2.45% for India**, **1.82% for China**, and **1.25% for the European Union** (as reported in the sources cited in [21, 44]); we did not reproduce these general-equilibrium simulations, and the vulnerability is heavily concentrated in the Indo-Pacific.

**Table 12. Destination Exposure of Hormuz Crude Shipments (EIA/Vortexa)**

| Year | Crude Transit (mb/d) | Destined for Asia (mb/d) | Asian Share (%) |
|---|---|---|---|
| 2020 | 14.27 | 11.81 | 82.8 |
| 2021 | 14.39 | 11.69 | 81.2 |
| 2022 | 15.96 | 12.75 | 79.9 |
| 2023 | 15.54 | 12.48 | 80.3 |
| 2024 | 14.32 | 11.98 | 83.7 |
| 1Q2025 | 14.21 | 12.67 | 89.2 |

*Note: Asian destinations comprise China, India, Japan, South Korea, and other Asian buyers. Source: U.S. EIA analysis of Vortexa vessel data (2020–1Q2025), as compiled in this study.*

### 6.4 International Gas Segmentation and the LNG Premium

The monthly gas evidence adds one important nuance to the "oil-specificity" conclusion. Hormuz risk is not priced in U.S. domestic gas, but it is priced in international gas once supply is actually destroyed. The 2026 closure removed roughly 18% of global LNG trade almost overnight; with no alternative export route for Qatar and the UAE [35], the spot market repriced the remaining cargoes at levels 53% above the previous spring in Asia and 35% above in Europe. The U.S. market is structurally separate: it is a net exporter whose liquefaction capacity limits how much domestic gas can be redirected overseas, so Henry Hub followed domestic fundamentals and ended the period below its 2025 level.

Three implications follow. First, the LNG component of a Hormuz closure is the hardest to manage, as the IEA has warned [35]: the price response in import-dependent regions was far larger than in the oil market, where spare capacity and reserves provided partial relief. Second, the "no gas premium" result in Section 5.2 is specific to the U.S. domestic market; international gas did not react to sub-kinetic threats but did react violently to the realized closure. Third, for import-dependent economies the operative buffers are LNG storage and long-term contracts, not domestic production [40, 46]. These conclusions rest on the descriptive monthly gas analysis, whose small sample and seasonality adjustments are discussed in Section 8.

## 7. Policy Implications and Strategic Governance

The empirical design identifies associations around a small number of episodes rather than causal effects, and the policy discussion below should be read with the limitations of Section 8 in mind. With that caveat, the results point to several policy changes:

1. **Strategic Reserve Governance and Collective Release Mechanisms.** The IEA collective action framework, designed in 1974 for OECD economies, is poorly matched to today's flows: over 80% of Hormuz crude goes to non-OECD Asian economies. An effective crisis response needs coordinated release mechanisms among the IEA, China's National Food and Strategic Reserves Administration (NFSRA), and India's Indian Strategic Petroleum Reserves Limited (ISPRL). The measured Asian shares in Section 6.3 (80–89% of Hormuz crude) quantify what is at stake.
2. **Expansion of Overland Pipeline Bypass Infrastructure.** The CRS estimates that the combined bypass pipelines may provide roughly 2.6 mb/d of available capacity against roughly 20.9 mb/d of average transit. Regional infrastructure planning should focus on sustainably operating the upgraded East-West Petroline capacity (about 7 mb/d as reported for March 2025 [35]), completing the UAE's Fujairah storage expansions, and building regional gas pipeline interconnectors.
3. **Multilateral Maritime Convoy and Escort Regimes.** The U.S.-led International Maritime Security Construct (Operation Sentinel) and the European-led EMASOH (Operation Agenor) should be integrated with Asian consumer naval assets. Given China's and India's commercial stake in Hormuz transit, burden-sharing in mine countermeasures and escort operations is a condition for credible transit deterrence.
4. **International Gas Coordination and LNG Storage.** The regional gas divergence in Section 5.6—Asian LNG up 53% and European gas up 35% year-on-year during the closure while U.S. Henry Hub fell—shows that LNG importers bear the largest price burden. Coordinated LNG storage policies, diversified long-term contracts, and joint strategic gas reserves among Asian and European importers would dampen the spot-price bidding wars seen in 2026. This recommendation rests on the descriptive monthly gas evidence, which is based on a small sample (Section 8).
5. **Decarbonization and Electrification as Structural Geopolitical Hedges.** The physical non-substitutability of the strait means geopolitical risk cannot be engineered out of maritime hydrocarbon supply chains. Domestic renewable generation, grid electrification, and industrial efficiency in the major importing states are the only definitive long-term hedges against chokepoint interdiction.

## 8. Limitations and Methodological Caveats

Several caveats apply:

1. **Event Window Boundary Selection.** Incident dates follow explicit historical and operational criteria, but the choice of window length (7, 14, 21, or 30 days) involves discretion. Sensitivity analysis across window lengths shows the core results are robust, but intraday dynamics during acute episodes are not observable in daily settlement data.
2. **Measurement Error in Conflict-Era Physical Flows.** During the 2026 war, widespread AIS disabling and spoofing by tankers and naval vessels introduced noise into real-time transit tracking [57]. EIA quarterly aggregations are the best available benchmark, but daily vessel counts remain subject to revision.
3. **U.S.-Centric Policy Uncertainty Metrics.** The EPU index measures U.S. policy uncertainty. The U.S. financial system is the global pricing clearinghouse, but multi-country indices for China, Japan, and India would better capture Asian institutional responses.
4. **Implied-Volatility Inference and Monthly Gas Granularity.** The options-based series are strongly autocorrelated; the OVX premium survives Welch inference but not Newey-West adjustments, and the Design-3 windows for the closure are small (10–40 days). The monthly gas analysis has 90 percentage-change observations with 26 crisis months, and level comparisons around the closure span seasons; we therefore rely on same-season year-on-year contrasts, which control for seasonality but inherit whatever affected the 2025 baseline (including the 2025 European gas price surge). These results are descriptive complements to the daily-frequency core design.
5. **Identification and Inference at the Incident Level.** Treatment occurs in only eleven episodes while observations are pooled daily; the quarter-clustered estimates use 31 clusters, which is modest for cluster-robust asymptotics, and the placebo-permutation and VIX-controlled checks in Section 5.7 show that the 14-day oil premium does not survive those stricter standards. The 21- and 30-day results are robust across methods, but the overall design supports descriptive event-window associations rather than a causal Hormuz treatment effect; unobserved confounding (OPEC decisions, sanctions timing, broader Middle East conflict) cannot be ruled out.
6. **External Data and Estimates.** Several contextual figures—war-risk premium ranges, rerouting distances, refinery throughput effects, and the GDP-loss scenario estimates—come from industry or model sources that we did not independently verify; the flow figures for the 2026 war reflect the EIA data vintage compiled for this study, and EIA has published slightly different numbers in other releases. These figures should be verified against primary sources before submission.

## 9. Conclusion

The Strait of Hormuz is the most concentrated, and least substitutable, chokepoint in the global energy system. This paper asked how geopolitical crises around the strait transmit into energy market volatility and policy uncertainty.

Across eleven incidents between 2019 and 2026, the event-window analysis shows a clear split, with an important qualification about inference. Controlling for the prevailing regime, crude oil volatility rises after incidents: at 14 days the effect is significant under the Welch test (Brent p = 0.003; WTI p = 0.002) but only borderline under Newey-West and clustered corrections (p = 0.051–0.079), and it does not survive placebo-permutation or VIX-controlled checks; at 21 and 30 days the effects are strongly significant under every inference method (p < 0.001) and survive excluding 2026. Implied crude-oil volatility (OVX) moves in the same direction in raw daily changes, but the implied-volatility evidence is descriptive because the effect is not robust to autocorrelation-robust adjustments; equity and gold volatility (VIX, GVZ) show no consistent response to sub-kinetic episodes. Henry Hub gas and the U.S. EPU index show no robust crisis premium.

The 2026 closure was a different event. Oil and LNG transit through the strait collapsed by 77.3% and 92.4% between 4Q2025 and 2Q2026 (Section 5.4; Figure 2), confirming what the chokepoint literature had long warned about. Volatility jumped across markets, and gas prices split by region: Asian LNG was 52.6% and European gas 35.4% above year-earlier levels in spring 2026, while U.S. Henry Hub was 17.7% below. The evidence on policy uncertainty around the closure is suggestive but not consistent across inference methods.

For policy, the message is that markets distinguish threats from realized supply deficits. Keeping gray-zone conflict from escalating into physical closure, expanding overland pipeline buffers, coordinating strategic reserves with Asian powers, deepening international LNG storage cooperation, and accelerating the shift to domestic renewable energy are the main priorities for energy security policy in the coming decade—subject to the identification and data caveats in Sections 5.7 and 8.

## Data and Code Availability

All data and code used in this study are preserved in the run record of this project. The raw price and flow series are stored under `datasets/raw`, with checksums and retrieval timestamps in `datasets/manifest.json`; the cleaning scripts that prepare them are in `datasets/scripts`. The event-window statistics reported in Tables 4–13 are produced by the scripts in `experiments/` (the core analysis in `hormuz_reanalysis.py`, the supplementary risk and gas series in `hormuz_reanalysis_extended.py`, the robustness checks in `hormuz_robustness.py`, and the figures in `publication_figures.py`); the machine-readable results are in `analysis/reanalysis/`. The supplementary FRED series were retrieved on 23 August 2026, and the citation verification report is in `verification/`. A stable, reviewer-accessible repository is being prepared for submission.

---

## Appendix A: Detailed Descriptive Statistics and Data Summaries

This appendix reports the deterministic summary statistics and correlation matrices for the datasets analyzed in this study, computed on the restricted 2019–2026 analysis window (1,875 trading days, 2019-01-02 through 2026-08-18). The full-history pipeline output (2000–2026) for all supporting series is preserved in analysis/ and datasets/charts/ of the run record.

### A.1 Daily Return Series and Volatility Metrics (hormuz_event_windows_fred, 2019–2026)

**Descriptive Statistics (restricted analysis window):**

- **Brent Crude Daily Returns (%):** Mean = +0.0950%, SD = 3.4628%, Min = -47.4654%, Median = +0.1554%, Max = +50.9868%, n = 1,875.
- **WTI Crude Daily Returns (%):** Mean = -0.0943%, SD = 8.3298%, Min = -301.9661% (the 20 April 2020 negative-price event), Median = +0.1386%, Max = +53.0864%, n = 1,875.
- **Henry Hub Daily Returns (%):** Mean = +0.5621%, SD = 13.2390%, Min = -75.3788%, Median = 0.0000%, Max = +319.0476%, n = 1,875.
- **U.S. EPU Daily Change (Points):** Mean = +0.0265, SD = 99.6142, Min = -952.78, Median = -0.85, Max = +872.82, n = 1,875.
- **VIX Daily Change (Points):** Mean = -0.0067, SD = 2.0959, Min = -18.71, Median = -0.15, Max = +24.86, n = 1,875.
- **OVX Daily Change (Points):** Mean = -0.0032, SD = 6.1258, Min = -90.61, Median = -0.19, Max = +130.22, n = 1,875.
- **GVZ Daily Change (Points):** Mean = +0.0050, SD = 1.1659, Min = -9.50, Median = -0.08, Max = +8.11, n = 1,875.

**Pairwise Correlation Matrix (restricted window):**

- Brent Return vs WTI Return: r = 0.462, p < 0.001 (scipy Pearson correlation).
- Brent Return vs Henry Hub Return: r = 0.028, p = 0.228.
- WTI Return vs Henry Hub Return: r = 0.002, p = 0.945.
- Brent Return vs EPU Change: r = 0.010, p = 0.660.
- WTI Return vs EPU Change: r = 0.000, p = 0.992.
- Henry Hub Return vs EPU Change: r = -0.005, p = 0.844.

The daily correlations between energy returns and policy-uncertainty changes are negligible on the restricted window, consistent with the event-window finding that Hormuz shocks are oil-specific.

### A.2 Physical Flow Series (eia_chokepoint_oil_flows_quarterly & eia_chokepoint_lng_flows_quarterly)

The chokepoint flow datasets record quarterly transit volumes for **all eight major maritime chokepoints** (Strait of Hormuz, Strait of Malacca, Suez Canal and SUMED, Bab el-Mandeb, Danish Straits, Turkish Straits, Panama Canal, and Cape of Good Hope) over 1Q2025–2Q2026, as compiled from EIA chokepoint flow data.

- **Crude Oil & Products Throughput (million bpd, all chokepoints):** Mean = 8.8563 mb/d, SD = 7.1145, Min = 2.50 mb/d, Median = 5.25 mb/d, Max = 24.90 mb/d, n = 48 (8 chokepoints x 6 quarters).
- **LNG Throughput (billion cubic feet per day, all chokepoints):** Mean = 3.7800 bcf/d, SD = 3.8613, Min = 0.20 bcf/d, Median = 1.60 bcf/d, Max = 11.70 bcf/d, n = 45 (three missing Bab el-Mandeb observations).

For the Strait of Hormuz subset, the comparisons used in Section 5.4 are 2Q2026 (4.9 mb/d) versus 4Q2025 (21.6 mb/d), a 77.3% contraction in crude and products, and 2Q2026 (0.8 bcf/d) versus 4Q2025 (10.5 bcf/d), a 92.4% contraction in LNG.

### A.3 Destination and Origin Accounting (eia_hormuz_destinations_tidy, eia_hormuz_origins_tidy)

The destination series record crude shipments through Hormuz by destination for 2020–1Q2025 (54 records); the origin series record shipments by country of origin (42 records). Asian destination shares (Table 12) range between 79.9% (2022) and 89.2% (1Q2025), with China the single largest destination (4.03–5.35 mb/d over the sample). On the origin side, Saudi Arabia is the largest shipper (5.29–6.80 mb/d), followed by Iraq (2.85–3.25 mb/d), the UAE, and Kuwait; Iranian-origin volumes rose from 0.37 mb/d (2020) to 1.51 mb/d (1Q2025) as sanctions enforcement eased. Full per-country tables are preserved in the run record.
### A.4 Design-2 Crisis and Pre-Incident Means by Horizon (Table 13)

The pooled Design-2 means behind the tables in Section 5, by window length and series (Table 13). The gap between crisis and pre-incident means widens with the window because the pre-incident baseline declines; the statistical significance of the oil premium strengthens accordingly.

**Table 13. Design-2 Crisis and Pre-Incident Means by Window Length (Full Sample)**

| Window | Series | Crisis mean | Pre-incident mean | N crisis | N pre |
|---|---|---|---|---|---|
| 7 | Brent volatility (%) | 2.473 | 1.605 | 57 | 49 |
| 7 | WTI volatility (%) | 2.211 | 1.539 | 57 | 49 |
| 7 | Henry Hub volatility (%) | 3.196 | 3.635 | 57 | 49 |
| 7 | EPU |Δ| (points) | 54.10 | 44.30 | 57 | 49 |
| 7 | VIX level (points) | 17.30 | 16.38 | 57 | 49 |
| 7 | OVX level (points) | 43.23 | 35.53 | 57 | 49 |
| 7 | GVZ level (points) | 16.88 | 15.70 | 57 | 49 |
| 14 | Brent volatility (%) | 2.268 | 1.488 | 105 | 85 |
| 14 | WTI volatility (%) | 2.248 | 1.349 | 105 | 85 |
| 14 | Henry Hub volatility (%) | 3.254 | 4.895 | 105 | 85 |
| 14 | EPU |Δ| (points) | 60.05 | 47.42 | 105 | 85 |
| 14 | VIX level (points) | 17.42 | 15.80 | 105 | 85 |
| 14 | OVX level (points) | 44.29 | 33.94 | 105 | 85 |
| 14 | GVZ level (points) | 16.95 | 16.00 | 105 | 85 |
| 21 | Brent volatility (%) | 2.337 | 1.343 | 152 | 125 |
| 21 | WTI volatility (%) | 2.157 | 1.337 | 152 | 125 |
| 21 | Henry Hub volatility (%) | 3.303 | 7.834 | 152 | 125 |
| 21 | EPU |Δ| (points) | 59.58 | 57.74 | 152 | 125 |
| 21 | VIX level (points) | 17.65 | 15.81 | 152 | 125 |
| 21 | OVX level (points) | 44.36 | 33.77 | 152 | 125 |
| 21 | GVZ level (points) | 16.98 | 16.24 | 152 | 125 |
| 30 | Brent volatility (%) | 2.285 | 1.258 | 211 | 184 |
| 30 | WTI volatility (%) | 2.121 | 1.362 | 211 | 184 |
| 30 | Henry Hub volatility (%) | 3.263 | 5.792 | 211 | 184 |
| 30 | EPU |Δ| (points) | 62.54 | 58.80 | 211 | 184 |
| 30 | VIX level (points) | 17.79 | 16.45 | 211 | 184 |
| 30 | OVX level (points) | 44.15 | 33.09 | 211 | 184 |
| 30 | GVZ level (points) | 17.25 | 15.33 | 211 | 184 |

### A.5 Alternative Volatility Specifications (Table 14)

As a robustness check requested in review, the Design-2 comparisons are repeated with squared returns, |log returns|, and implied-volatility levels (Table 14). The oil premium is robust to these measures, and the implied-volatility level tests are stronger than the daily-change tests reported in Table 8.

**Table 14. Alternative Volatility Specifications (Design 2, Welch Tests)**

| Window | Measure | Crisis mean | Pre-incident mean | t | p |
|---|---|---|---|---|---|
| 14 | Brent squared returns | 10.23 | 3.86 | 2.82 | 0.006 |
| 14 | WTI squared returns | 11.77 | 2.96 | 3.49 | 0.001 |
| 14 | Brent |log return| (%) | 2.253 | 1.492 | 2.95 | 0.004 |
| 14 | WTI |log return| (%) | 2.240 | 1.353 | 3.18 | 0.002 |
| 14 | VIX level | 17.42 | 15.80 | 3.40 | 0.001 |
| 14 | OVX level | 44.29 | 33.94 | 4.80 | <0.001 |
| 14 | GVZ level | 16.95 | 16.00 | 0.93 | 0.353 |
| 30 | Brent squared returns | 9.95 | 2.67 | 5.01 | <0.001 |
| 30 | WTI squared returns | 9.17 | 2.84 | 4.56 | <0.001 |
| 30 | Brent |log return| (%) | 2.280 | 1.255 | 6.11 | <0.001 |
| 30 | WTI |log return| (%) | 2.121 | 1.361 | 4.56 | <0.001 |
| 30 | VIX level | 17.73 | 16.41 | 3.15 | 0.002 |
| 30 | OVX level | 44.05 | 33.05 | 7.89 | <0.001 |
| 30 | GVZ level | 17.25 | 15.33 | 2.97 | 0.003 |

*Note: Squared returns and |log returns| are in %^2 and %, respectively; levels are index points. Full results in analysis/reanalysis/eventlevel_report.md.*


---

## Appendix B: Documented Geopolitical Incident Chronology (2019–2026)

**Table 15. Comprehensive Incident Inclusion Log and Operational Description**

| Date | Geopolitical Episode | Operational Description & Military Details | Strategic Rationale |
|---|---|---|---|
| 2019-05-12 | Fujairah Anchorage Sabotage | Limpet mine attacks damaging four commercial tankers off UAE coast | Initial covert maritime sabotage targeting Persian Gulf export infrastructure |
| 2019-06-13 | Gulf of Oman Tanker Attacks | Explosive attacks on MT Front Altair and Kokuka Courageous near Hormuz | Direct kinetic targeting of international commercial tankers in transit |
| 2019-07-19 | Stena Impero Seizure | IRGCN commandos seize British-flagged tanker in Omani waters of Hormuz | State-level vessel boarding and physical interdiction of transit passage |
| 2020-01-03 | Baghdad Airport Drone Strike | U.S. precision strike killing IRGC Quds Force Commander Qasem Soleimani | Acute state-level kinetic escalation threatening retaliatory chokepoint closure |
| 2020-01-08 | Operation Martyr Soleimani | Iranian ballistic missile strikes on Al Asad and Erbil airbases in Iraq | Direct state-on-state military exchange with high Persian Gulf escalation risk |
| 2021-07-29 | Mercer Street Drone Attack | One-way explosive drone strike on petroleum tanker off Omani coast | First operational deployment of loitering munitions against commercial tankers |
| 2023-10-07 | Regional Conflict Escalation | Outbreak of Israel-Gaza war and subsequent Red Sea maritime blockade | Systemic regional conflict expansion activating asymmetric maritime threats |
| 2024-04-13 | Operation True Promise I | Iran launches 300+ drones and missiles against Israeli territory | Unprecedented direct state-to-state military confrontation in West Asia |
| 2024-10-01 | Operation True Promise II | Iranian ballistic missile barrage targeting military facilities in Israel | Major regional ballistic missile exchange threatening critical energy nodes |
| 2025-06-13 | Israel–Iran 12-Day Conflict | High-intensity kinetic air and missile exchanges targeting strategic assets | Direct military strikes near energy export infrastructure and maritime lanes |
| 2026-02-28 | Closure of Strait of Hormuz | War onset; Iranian forces declared the strait closed on 4 March 2026 [34], and mining, missile strikes, and interdiction of traffic followed | Total physical interdiction of maritime transit; 77.3% collapse in energy flows by 2Q2026 |

*Note: the 2026-02-28 date is the analysis coding for the incident; the formal closure declaration came on 4 March (CRS [34]).*

**Sample composition.** Full sample (2019-01-01 to 2026-08-18): 1,875 trading days; crisis days 57 (7-day windows), 105 (14-day), 152 (21-day), 211 (30-day). Ex-2026 sample (2019-01-01 to 2025-12-31): 1,721 trading days; crisis days 52 (7-day), 95 (14-day), 137 (21-day), 190 (30-day). Design-2 pre-incident windows, excluding days inside any crisis window (full sample): 49 (7-day), 85 (14-day), 125 (21-day), 184 (30-day); (ex-2026): 45, 75, 111, 167.

**Data and code.** The data and code availability statement appears after the Conclusion (Section 9); see also the reproducibility pointers there.

---

## References


[1] Suad Jawad Kadhim (2026). Geopolitical Tensions in The Strait of Hormuz and Its Impact on Global Energy Security and The Stability of International Supply Chains: An Analytical Study. Journal of Regional Economics and Development, vol. 3(4), pp. 1-16. https://doi.org/10.47134/jred.v3i4.1220

[2] Dr. Shivendra Shahi (2026). Maritime Choke Points and the Security of Global Commerce: Conflict, Piracy, Non-State Threats and Supply-Chain Vulnerabilities. INTERNATIONAL JOURNAL OF CURRENT SCIENCE, vol. 16(3). https://doi.org/10.56975/ijcsp.v16i3.305094

[3] Riva Ramadhani, Atikah Marzaman (2024). MARITIME STABILITY IN THE STRAIT OF HORMUZ: CHALLENGES, GLOBAL IMPACTS, AND MULTILATERAL DIPLOMACY. HYPOTHESIS : Multidisciplinary Journal Of Social Sciences, vol. 3(02), pp. 81-96. https://doi.org/10.62668/hypothesis.v3i02.1293

[4] Akhlaque Ahmed Kubar, Dr Himad Ali (2026). THE GEOPOLITICAL AND ECONOMIC IMPACT OF A STRAIT OF HORMUZ BLOCKADE ON ARAB STATES DURING THE IRAN-ISRAEL-US CONFLICT. Contemporary Journal of Social Science Review, vol. 4(2), pp. 1-19. https://doi.org/10.63878/cjssr.v4i2.2517

[5] Andreea-Emanuela Dragoi (2026). The transformation of eu energy imports: implications for energy security and geopolitical risk. Economy and Sociology, pp. 5-16. https://doi.org/10.36004/nier.es.2026.1-01

[6] Yan Li, xinxin xia, Yuhao Wang, et al. (2026). Geopolitical Risk and Shipping Supply Chain Resilience: Systemic Characteristics, Impact Mechanisms, and the Security of Logistics Nodes. Systems, vol. 14(4), pp. 427. https://doi.org/10.3390/systems14040427

[7] Murat Koray, Ercan Kaya, M. Hakan Keskin (2025). Determining Logistical Strategies to Mitigate Supply Chain Disruptions in Maritime Shipping for a Resilient and Sustainable Global Economy. Sustainability, vol. 17(12), pp. 5261. https://doi.org/10.3390/su17125261

[8] Ioanna Atsalaki, George S. Atsalakis (2026). A fuzzy prescriptive analytics framework for supply chain resilience under geopolitical disruptions in the Strait of Hormuz. Supply Chain Analytics, vol. 15, pp. 100230. https://doi.org/10.1016/j.sca.2026.100230

[9] Seung-Jun Lee, Jisung Kim, Hong-Sik Yun (2026). How Sustainable Is Arctic Route Diversification? Economic Losses, SDG Trade-Offs, and Supply Chain Resilience in the 2026 Hormuz Crisis. Sustainability, vol. 18(9), pp. 4318. https://doi.org/10.3390/su18094318

[10] Leonard Terver Thomas (2026). Impact of Strait of Hormuz Crisis on Global Trade: Route Diversion and Economic Consequences. IIARD INTERNATIONAL JOURNAL OF ECONOMICS AND BUSINESS MANAGEMENT, pp. 252. https://doi.org/10.56201/ijebm.vol.12.no6.2026.pg252.264

[11] Sarah Meier (2026). Non-Substitutable Chokepoints and Global Supply Chain Disruption: A Conceptual Framework and Scenario Analysis of a Strait of Hormuz Closure. Unveiling seven continents yearbook journal, pp. 10026. https://doi.org/10.65326/u7y566830

[12] Dr. Ashutosh Khatawkar (2026). Global Economic Consequences of Contemporary Geopolitical Conflicts. Advanced International Journal for Research, vol. 7(2), pp. 3961. https://doi.org/10.63363/aijfr.2026.v07i02.3961

[13] Abel Meza, Ibrahim Ari, Mohammed Al Sada, et al. (2026). Implications of interrupting the Hormuz Strait in the LNG trade. Journal of Transportation Security, vol. 19(1), pp. 28. https://doi.org/10.1007/s12198-026-00350-1

[14] Ismail Ali, Kasim Hj. Mansor, Lai Yew Meng (2026). The West Asia Conflict and Its Impact on Maritime Affairs: A Geopolitical, Blue Economy and Empirical Sectoral Analysis. International Journal of Research and Innovation in Social Science, vol. 10(5), pp. 9949-9954. https://doi.org/10.47772/ijriss.2026.100500667

[15] Xiaoxiao Hu, Ling Ling He, Qi Cui (2021). How Do International Conflicts Impact China's Energy Security and Economic Growth? A Case Study of the US Economic Sanctions on Iran. Sustainability, vol. 13(12), pp. 6903. https://doi.org/10.3390/su13126903

[16] Marwan Mansoor Naeem (2026). THE EFFECTIVENESS OF THE ADDITIONAL PERIOD FOR PERFORMANCE IN INTERNATIONAL SALES CONTRACTS IN THE FACE OF MARITIME TRANSPORT DISRUPTIONS: AN APPLIED STUDY ON THE RISKS OF THE STRAIT OF HORMUZ. Veredas do Direito, vol. 23(12), pp. e237334. https://doi.org/10.18623/rvd.v23.7334

[17] Saeed Ahmed Butt, Komal Khan (2026). The Strategic Significance of the Strait of Hormuz in Contemporary Great Power Competition. Journal of Political Stability Archive, vol. 4(2), pp. 943-968. https://doi.org/10.63468/jpsa.4.2.61

[18] Dridi Bachir, Mehirig Adnane (2026). Energy Security Strategies Amidst Global Supply Chain Disruptions: The Case of Algerian Natural Gas. Lex localis - Journal of Local Self-Government, pp. 431-435. https://doi.org/10.52152/zmzgt002

[19] Vishnu Mangu (2025). Conflict at the Crossroads: Security Tensions in the Strait of Hormuz. International Journal For Multidisciplinary Research, vol. 7(6), pp. 56232. https://doi.org/10.36948/ijfmr.2025.v07i06.56232

[20] Dr. Arun Kumar Singh and Alok Kumar (2026). The Strait of Hormuz in Contemporary Geopolitics: Energy Security, Great Power Competition, and India's Strategic Autonomy. International Journal of Advanced Research in Science Communication and Technology, pp. 223. https://doi.org/10.48175/ijarsct-35534

[21] Anamika Kaushiva (2026). The Economic Consequences of the Strait of Hormuz Conflict for India: De Facto and De Jure Perspectives. VEETHIKA-An International Interdisciplinary Research Journal, vol. 12(2), pp. 1-15. https://doi.org/10.48001/veethika.1202001

[22] Firat Bolat (2025). Modeling the Impact of Houthi Attacks on Red Sea Trade Routes with the GEO-SHIP Framework. Transactions on Maritime Science, vol. 14(3). https://doi.org/10.7225/toms.v14.n03.004

[23] Ashok Kumar (2025). Weaponising the Supply Chain: Yemen's Blockade and the Contradictions of Maritime Logistics Capital. Antipode, vol. 58(1), pp. e70107. https://doi.org/10.1111/anti.70107

[24] Vasco Fronzoni (2026). The sea routes, between security, geopolitical criticalities, religious tensions and economic interests. Georgian Maritime Scientific Journal, vol. 3(1), pp. 160-168. https://doi.org/10.70791/gmsj.3.2026.11943

[25] Ghilman Fatima Awan, Waqas Abdullah, Khawaja Shahab Ud Din Shahab (2025). Iran's Naval Strategy in the Strait of Hormuz: Implications for Global Maritime Security. Social Science Review Archives, vol. 3(3), pp. 525-535. https://doi.org/10.70670/sra.v3i3.886

[26] Lukman Yudho Prakoso, Buddy Suseto, Ivan Yulivan, et al. (2026). Indonesia's Maritime Defense Strategy in Light of Global Dynamics: Lessons Learned from the War in the Strait of Hormuz. Journal of Social Research, vol. 5(9), pp. 4483-4495. https://doi.org/10.55324/josr.v5i9.3380

[27] Jasper Verschuur, Johannes Lumma, Jim W. Hall (2025). Systemic impacts of disruptions at maritime chokepoints. Nature Communications, vol. 16(1), pp. 10421. https://doi.org/10.1038/s41467-025-65403-w

[28] Ridha Munawir Masly Pandoe, Rachmat Setiawibawa, Harri Dolli Hutabarat, et al. (2026). Contested Maritime Spaces in the Middle East: Geopolitical Dynamics, Non-State Actors, and Security Challenges in the Red Sea and the Strait of Hormuz. Advances In Social Humanities Research, vol. 4(1), pp. 1-8. https://doi.org/10.46799/adv.v4i1.538

[29] Asia Rahman Khan Lodhi, Dr. Akhtar Amin, Asmat Ullah Khan (2026). Energy Security and Global Economic Impacts of the Iran-Israel War. Research Journal for Social Affairs, vol. 4(3), pp. 09-17. https://doi.org/10.71317/rjsa.004.03.0733

[30] Stefan Vogele, Judith Alvre, Andrew Ross, et al. (2025). Challenges for Energy Transition: Incorporating Maritime and Geopolitical Risks. The World Economy, vol. 48(8), pp. 1850-1862. https://doi.org/10.1111/twec.13722

[31] Jiawei Feng, Mengsi Cai, Fangze Dai, et al. (2024). Modeling Supply Chain Interaction and Disruption: Insights from Real-world Data and Complex Adaptive System. arXiv. https://arxiv.org/abs/2405.10818v1

[32] Soorya Soman, P. Balasubramanian (2025). GEOPOLITICAL RISKS IN MARITIME SHIPPING: CHALLENGES AND STRATEGIC ADAPTATIONS FOR PRIMARY CHOKEPOINTS. Lex localis - Journal of Local Self-Government, vol. 23(S6), pp. 988-1001. https://doi.org/10.52152/801897

[33] Digvijay Redekar, Ronald Askin, Feng Ju (2025). Maritime Port Supply Chain Resilience: A Systematic Review. arXiv. https://arxiv.org/abs/2510.09844v1

[34] Congressional Research Service (2026). Iran Conflict and the Strait of Hormuz: Impacts on Oil, Gas, and Global Markets (CRS R45281). Congressional Research Service. https://www.congress.gov/crs_external_products/R/PDF/R45281/R45281.6.pdf

[35] International Energy Agency (2026). IEA Strait of Hormuz Factsheet (February 2026). International Energy Agency. https://iea.blob.core.windows.net/assets/c8248eba-8689-46d9-ae4b-b858b59c0f1c/StraitofHormuz2026-Factsheet.pdf

[36] Fizzah Muhammad, Muneeb Aurangzeb, Syed Shuja Uddin (2026). Artificial Intelligence, Energy Geopolitics, and Digital Diplomacy: Rethinking U.S. Petrodollar Dominance amid the Strait of Hormuz Security Dilemma (2020-2026). Research Journal for Social Affairs, vol. 4(3), pp. 213-222. https://doi.org/10.71317/rjsa.004.03.0796

[37] G. A. J. Uthpala, Chathumi Kavirathna (2025). Geopolitical Conflicts and The Resilience of Maritime Logistics: A Critical Synthesis. Journal of Desk Research Review and Analysis, vol. 3(2), pp. 45-62. https://doi.org/10.4038/jdrra.v3i2.85

[38] Muhammet Alper Turkles (2026). Taiwan as the "New Danzig"? Historical analogy, strategic chokepoints, and escalation risks in the Indo-Pacific. Social Sciences in Brief, vol. 3(1), pp. 1-8. https://doi.org/10.47909/ssb.31

[39] Wei Luo, Siyuan Kang, Qian Di (2025). Global Supply Chain Reallocation and Shift under Triple Crises: A U.S.-China Perspective. arXiv. https://arxiv.org/abs/2508.06828v1

[40] Ayobayo Kolapo (2025). The Future of LNG Policy in Global Energy Security and Decarbonization. International Journal of Research Publication and Reviews, vol. 6(7), pp. 397-422. https://doi.org/10.55248/gengpi.6.0725.2631

[41] Abebe Yirga Ayenalem, Gashaw Ayferam Endaylalu (2025). From Suez Canal to Bab al-Mandab Strait: Navigating Maritime Security in the World's Busiest Maritime Trade Corridor. Ortadoğu Etütleri, vol. 17(1), pp. 37-66. https://doi.org/10.47932/ortetut.1744422

[42] Yulita Giyanti Putri, Ni Made Ayu Krisna Cahyadi (2025). How Does the Middle East Geopolitical Conflict Impact Indonesia's Trade Balance? Economous: Journal of Regional Economic Development, vol. 1(1). https://doi.org/10.33830/economous.v1i1.10795

[43] Rana Muhammad Maaz, Talha Ahmed Khan, Muhammad Abrar Khan, et al. (2025). Ambitions of Great Powers in Indian Ocean Region: Impacts on Regional Maritime Stability. Physical Education, Health and Social Sciences, vol. 3(4), pp. 38-47. https://doi.org/10.63163/jpehss.v3i4.717

[44] Ayush Kumar Singh, Dr. Santosh Kumar (2026). The Impact of the Iran-Israel Conflict on India's Trade, Oil Prices & Overall Economic Stability. International Journal of Science, Strategic Management and Technology, vol. 02(04), pp. 1-9. https://doi.org/10.55041/ijsmt.v2i4.454

[45] Mohammad Hadi Vaez Mahdavi, Mohammad Reza Dehshiri (2025). The Geopolitical Competition of the United States, China, and Russia in the Persian Gulf and Its Impact on the Security of the Islamic Republic of Iran. Interdisciplinary Studies in Society, Law, and Politics, vol. 4(3), pp. 1-11. https://doi.org/10.61838/kman.isslp.4.3.5

[46] Maudlyn Ireju Victor-Ikoh, Victor Ikoh (2026). Examining The Sustainability Implications of Global LNG Trade Through A PESTLE Analysis of Political, Economic, Social, Technological, Legal, and Environmental Drivers. International Journal of Research and Innovation in Social Science, vol. 10(2), pp. 8727-8733. https://doi.org/10.47772/ijriss.2026.10200620

[47] Serhii V. Kivalov (2025). Maritime Activities and Energy Security: Contemporary Challenges and Multifaceted Interactions. Lex Portus, vol. 11(4). https://doi.org/10.62821/lp11402

[48] CHRISTIAN ILCUS (2026). PERSIAN GULF SECURITY: THE EU PERSPCTIVE. International Journal of Social Sciences and Management Review, vol. 9(02), pp. 01-286. https://doi.org/10.37602/ijssmr.2025.9201

[49] Khusan Kamalov (2025). Terrorism and Oil Geopolitics: Shifts in World Energy Policy. American Journal Of Social Sciences And Humanity Research, vol. 5(8), pp. 54-58. https://doi.org/10.37547/ajsshr/volume05issue08-13

[50] Ruikai Sun, Wessam Abouarghoub, Emrah Demir, et al. (2025). Geopolitical disruptions and maritime transitions: Environmental and economic costs of rerouting. Transportation Research Part A: Policy and Practice, vol. 203, pp. 104737. https://doi.org/10.1016/j.tra.2025.104737

[51] I Gusti Bagus Dharma Agastia, Anak Agung Banyu Perwita (2016). Indonesia's Maritime Axis and the Security of Sea Lanes of Communications (SLOCs) in the Indo-Pacific. Jurnal Hubungan Internasional, vol. 5(1), pp. 10-21. https://doi.org/10.18196/hi.2016.0081.10-21

[52] Ali Gholizadeh, Seyedashkan Madani, Saba Saneinia (2020). A geoeconomic and geopolitical review of Gwadar Port on belt and road initiative. Maritime Business Review, vol. 5(4), pp. 335-349. https://doi.org/10.1108/mabr-11-2019-0051

[53] Seyedashkan Madani (2021). THE BRI AND ITS IMPLICATIONS FOR CHINA'S ENERGY SECURITY: THE FOUR AS MODEL PERSPECTIVE. International Journal of Energy Economics and Policy, vol. 11(4), pp. 549-559. https://doi.org/10.32479/ijeep.11221

[54] Adekola Oyenuga (2021). Perspectives on the impact of the COVID-19 pandemic on the global and African maritime transport sectors, and the potential implications for Africa's maritime governance. WMU Journal of Maritime Affairs, vol. 20(2), pp. 215-245. https://doi.org/10.1007/s13437-021-00233-3

[55] Qiang Wang, Fen Ren, Rongrong Li (2024). Geopolitics and energy security: a comprehensive exploration of evolution, collaborations, and future directions. Humanities and Social Sciences Communications, vol. 11(1), pp. 1071. https://doi.org/10.1057/s41599-024-03507-2

[56] U.S. Energy Information Administration (2025). EIA Today in Energy: Amid Regional Conflict, the Strait of Hormuz Remains Critical Oil Chokepoint (June 2025). U.S. Energy Information Administration. https://www.eia.gov/todayinenergy/detail.php?id=65504

[57] U.S. Energy Information Administration (2026). EIA Global Energy Security Data report (August 2026). U.S. Energy Information Administration. https://www.eia.gov/outlooks/steo/report/energysecurity/article.php

[58] U.S. Energy Information Administration (2024). EIA World Oil Transit Chokepoints - Hormuz section (HTML tables). U.S. Energy Information Administration. https://www.eia.gov/international/analysis/special-topics/World_Oil_Transit_Chokepoints

[59] U.S. Energy Information Administration (2024). EIA World Oil Transit Chokepoints report (2024). U.S. Energy Information Administration. https://www.eia.gov/international/analysis/special-topics/content/analysis/special_topics/World_Oil_Transit_Chokepoints/archive/pdf/WOTC_2024.pdf
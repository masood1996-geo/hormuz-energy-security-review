# Provenance

- Date: 2026-08-23
- Run ID: gem-hormuz
- Topic: The Strait of Hormuz and Global Energy Security: Geopolitical Tensions, Maritime Trade, and the Risk of Supply Chain Disruption
- Mode: live
- Manuscript: final/paper_final.md (improved revision; methodological re-analysis integrated; supplementary risk-appetite and international gas evidence added)
- Bibliography: final/references.bib (59 entries; all locators network-verified)
- Citation verification: 59/59 passed (ratio 1.00, min 0.70; no hard rejections)
- Re-analysis: experiments/hormuz_reanalysis.py -> analysis/reanalysis/findings_reanalysis.json; experiments/hormuz_reanalysis_extended.py -> analysis/reanalysis/findings_extended.json (supplementary series: VIX, OVX, GVZ daily; LNG Asia and EU gas monthly; destination-exposure accounting)
- Dataset additions: FRED_VIXCLS, FRED_OVXCLS, FRED_GVZCLS, FRED_PNGASJPUSDM, FRED_PNGASEUUSDM fetched via the FRED API on 2026-08-23; SHA-256 and retrieval timestamps recorded in datasets/manifest.json; cleaning scripts under datasets/scripts/
- Figures: publication/figures/fig1_crisis_pre_volatility.png, fig2_hormuz_quarterly_flows.png (all-chokepoint panels), fig3_gas_price_divergence.png (regional gas divergence); deterministic via experiments/publication_figures.py
- Dataset provenance: checksums and findings hashes verified for all 245 dataset records on 2026-08-23
- Sealed artifacts: relative path -> SHA-256 recorded in run_manifest.json (sealed_at 2026-08-23T23:34Z)
- Open items: quality-gate re-review of the revised manuscript (human decision); the earlier peer-review grade (5/10, 'revise') was produced against the pre-revision manuscript, whose methodological defects the re-analysis addressed.
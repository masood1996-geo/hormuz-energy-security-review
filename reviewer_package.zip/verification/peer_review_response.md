# Peer-Review Response Record (major revision)

Date: 2026-08-24
Reviews: two independent "major revision" reports on final/paper_final.pdf.
Status of each requested change: addressed / partly addressed / not addressed (reason).

## High-priority statistical issues

1. **14-day oil premium overstated (both reviews).** The Abstract, Section 5.2, and
   Section 9 now state that the 14-day effect is significant under the Welch test
   (p = 0.003/0.002) but only borderline under Newey-West (0.051/0.058) and clustered
   (0.079/0.062) inference, and that the ex-2026 14-day result survives only under the
   Welch test. The 21/30-day results are described as the robust core. The Abstract also
   now reports the placebo-permutation (empirical p = 0.14-0.18) and VIX-controlled
   (not significant) results.
2. **OVX "confirms" language (both reviews).** Abstract, 5.5, and 9 now treat the
   implied-volatility evidence as descriptive: same direction in raw daily changes, not
   robust to Newey-West/clustered adjustments, no level-based inference claimed.
3. **"Effect grows with window length" (review 2).** 5.2 now reports the actual 21/30-day
   means and explains that the widening gap reflects a falling pre-incident baseline; the
   statistical evidence strengthens, not the economic magnitude per se.
4. **EPU "macroeconomic event" overstatement (both reviews).** 5.3 now reports the full
   picture (Welch p = 0.104/0.414 at 14 days; nothing significant at 30 days), explains
   the HAC/clustered discrepancy by the small closure sample, and labels the result
   suggestive; Table 7 note and Section 9 updated accordingly.
5. **GVZ "flight to safe haven" (review 2).** 5.5 now interprets the GVZ decline
   cautiously (volatility of implied-volatility changes is not gold purchases/holdings).

## Table and numerical issues

6. **Table 10 sign/sample discrepancy (review 2).** Confirmed real: the Welch test had
   been run on signed monthly changes while the columns report absolute changes.
   Re-analysis now tests absolute changes: LNG Asia t = -0.80 (p = 0.429), EU t = -1.54
   (0.128), Henry Hub t = -0.71 (0.481); ex-2026 LNG Asia and EU are significantly
   negative (0.030/0.021). Table 10, Section 5.6, findings_extended.json, and the
   extended report were regenerated.
7. **91 vs 90 monthly observations (review 2).** Clarified: 91 price observations, 90
   percentage changes after differencing (Section 4.1 and Table 10 note).
8. **Table 5 Bonferroni (review 1).** The reported values (0.013/0.006) are correct when
   computed on unrounded p-values (0.0033 x 4 = 0.0132; 0.0016 x 4 = 0.0064); a table
   note now states this explicitly.
9. **Window [Tk, Tk+W] spans W+1 days (review 2).** A note in 4.2 now states that each
   "W-day" window includes the incident day (W+1 calendar dates).
10. **Equation (6) typography (review 2).** s_pooled now has the full fraction inside the
    square root in both the manuscript and the LaTeX artifact.
11. **1Q2026 flow vintage (review 2).** 5.4 now notes the compiled dataset vintage and
    that EIA has published slightly different figures (20.7/14.6 mb/d) in other releases.

## Identification and inference (both reviews)

12. **New robustness analysis (Section 5.7, Table 11; experiments/hormuz_robustness.py;**
    **analysis/reanalysis/findings_robustness.json + robustness_report.md):**
    - leave-one-event-out: Brent Welch p stays <= 0.013 except when the 2026 closure is
      dropped (0.054); NW p range 0.034-0.114;
    - placebo-date permutation (500 draws, seed 42): empirical p = 0.138 (Brent) and
      0.182 (WTI) -- the 14-day premium is suggestive, not significant under a strict
      permutation standard;
    - confounder exclusion (COVID crash, Russia-Ukraine window): no Design-2 window days
      fall in those periods, results unchanged;
    - VIX-controlled regression (NW): crisis coefficient 0.43, t = 1.47/1.35, p =
      0.144/0.178 -- the VIX level absorbs the 14-day premium; 21/30-day results remain
      robust.
    The Abstract and 5.7 state these qualifications; the causal-language of the paper was
    softened accordingly.
13. **Inferential unit / cluster count (review 2).** 4.3 now notes that 31 clusters is
    modest and that treatment occurs in only eleven episodes; Section 8 adds a
    limitation item on identification at the incident level.
14. **HAC lag prespecification (review 2).** 4.3 now states the lag rule was
    prespecified as the window length in trading days.

## External facts verified against primary sources

15. **Strait width (both reviews).** IEA factsheet (Feb 2026) gives 29 NM; manuscript
    updated to 29 NM with the 21 NM figure noted as an earlier reference-point variant.
16. **Closure chronology (review 2).** CRS R45281 (v6, 11 March 2026) confirms the
    closure was declared on 4 March 2026; Section 1 and Appendix B now distinguish war
    onset (late February) from the 4 March declaration; the 28 February analysis coding
    is noted in Appendix B.
17. **Bypass capacity (review 1).** CRS gives ~2.6 mb/d available bypass capacity; Table 2,
    Section 1, and Section 7 updated (Petroline upgraded to ~7 mb/d per IEA, March 2025).
18. **Spare capacity 4.4 mb/d, >75% Middle East** verified in CRS R45281; unchanged.
19. **Other external claims** (insurance premium ranges, rerouting distances, refinery
    throughput estimates, GDP-loss scenarios, reserves) are now explicitly flagged in the
    text as industry- or model-sourced, with a new limitation item (Section 8.6) noting
    they were not independently verified.

## Structural and editorial issues

20. **Author block (both reviews).** Placeholder author/affiliation/corresponding-author/
    ORCID/funding block added under the title (to be completed by the authors).
21. **Data and Code Availability (both reviews).** New standalone section after the
    Conclusion; Appendix B reproducibility text trimmed to a pointer.
22. **Screening reproducibility (review 2).** Section 2 now states the databases
    (OpenAlex, arXiv), the relevance scoring, and the 59 retained (scores 30.1-100.0).
23. **"Monograph" wording (review 2).** Appendix A now says "study".
24. **Two-sided p-values (review 2).** 4.3 states all p-values are two-sided.
25. **PDF table word-breaking ("OV X", "Ex-20 26" etc.).** Table cells now use
    splitLongWords=0 and 8.5pt font.
26. **Figure displacement / captions (review 2).** Figure + caption are kept together
    (KeepTogether) and title spacing was increased.
27. **References labelled only "OpenAlex" (review 2).** Not addressed in this revision:
    the reference list entries retain the database label pending journal metadata
    enrichment (DOIs resolve via Crossref; see verification report). Planned before
    submission.
28. **Anonymous repository for reviewers (review 2).** Not addressed: the run record is
    local; a stable reviewer-accessible repository is being prepared (noted in the Data
    and Code Availability section).
29. **Closure-date flow figure "14.6/20.7" vs "14.9/21.6".** Not reconciled numerically
    (different EIA vintages); 5.4 now flags the vintage issue.

## Files changed in this revision

- final/paper_final.md, final/paper_final.{pdf,tex,docx} (regenerated)
- publication/paper_candidate.md + paper_candidate.pdf, drafts/paper_revised.{md,pdf}
- experiments/hormuz_reanalysis_extended.py (absolute-change gas tests),
  experiments/hormuz_robustness.py (new), experiments/verify_external_facts.py (new),
  experiments/render_pdf.py (table/figure rendering), experiments/regenerate_final.py
- analysis/reanalysis/findings_extended.json, extended_report.md, findings_robustness.json,
  robustness_report.md (new)
- run_manifest.json resealed; verification/provenance.md; verification/issues_audit.md
- Verification: check_manuscript.py PASS; researchagent verify PASS (9 sealed artifacts,
  citations 59/59 network-checked, datasets 245/245).
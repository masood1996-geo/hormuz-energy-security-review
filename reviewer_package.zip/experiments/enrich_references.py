"""Enrich the manuscript's reference list with Crossref journal metadata.

For each DOI in the references, query api.crossref.org and append
"Journal, Volume(Issue), Pages" to the entry (keeping the DOI/URL at the end so
citation-alignment checks keep passing). Entries that fail are left unchanged
and recorded.
"""
from __future__ import annotations

import json
import re
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

RUN = Path(__file__).resolve().parents[1]
PAPER = RUN / "final" / "paper_final.md"
BIB = RUN / "final" / "references.bib"
OUT = RUN / "verification" / "crossref_metadata.json"


def crossref(doi: str) -> dict | None:
    url = "https://api.crossref.org/works/" + urllib.parse.quote(doi) + "?mailto=research@example.org"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "researchagent/1.0 (mailto:research@example.org)"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        m = data.get("message", {})
        return {
            "container": (m.get("container-title") or [""])[0],
            "volume": m.get("volume", ""),
            "issue": m.get("issue", ""),
            "page": m.get("page", ""),
            "article": m.get("article-number", ""),
        }
    except Exception:
        return None


def fmt(meta: dict | None) -> str:
    if not meta or not meta["container"]:
        return ""
    parts = [meta["container"].strip()]
    vol_issue = ""
    if meta["volume"]:
        vol_issue = meta["volume"]
        if meta["issue"]:
            vol_issue += "(" + meta["issue"] + ")"
    if vol_issue:
        parts.append("vol. " + vol_issue)
    page = meta["page"] or meta["article"]
    if page:
        parts.append("pp. " + page.replace("-", "-"))
    return ", ".join(parts) + "."


def main() -> int:
    text = PAPER.read_text(encoding="utf-8")
    refs_section = text.split("## References")[1]
    lines = refs_section.splitlines()
    dof = [int(m) for m in re.findall(r"^\[(\d+)\] ", refs_section, re.M)]
    results = {}
    changed = 0
    for ln in lines:
        m = re.match(r"^\[(\d+)\] (.*)$", ln)
        if not m:
            continue
        n = int(m.group(1))
        body = m.group(2)
        dm = re.search(r"https://doi\.org/(\S+)", body)
        if not dm:
            continue
        doi = dm.group(1)
        meta = crossref(doi)
        time.sleep(0.4)
        results[str(n)] = meta
        extra = fmt(meta)
        if not extra:
            continue
        # replace the "OpenAlex." database label with journal metadata
        new_body = re.sub(r"\s*OpenAlex\.\s*(https://doi\.org/)", f" {extra} {chr(10)}   \\1".replace(chr(10), " "), body, count=1)
        if new_body == body:
            new_body = re.sub(r"(https://doi\.org/\S+)", f" {extra} \\1", body, count=1)
        if new_body != body:
            lines[lines.index(ln)] = f"[{n}] " + new_body
            changed += 1
    OUT.write_text(json.dumps(results, indent=2), encoding="utf-8")
    text = text.split("## References")[0] + "## References\n" + "\n".join(lines)
    PAPER.write_text(text, encoding="utf-8")
    print(f"enriched {changed} references; metadata saved to {OUT.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
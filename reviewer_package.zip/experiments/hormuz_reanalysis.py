"""Methodological re-analysis of Hormuz crisis-window volatility (reviewer items).

Addresses the peer-review required changes:
1. Restrict the sample to 2019-2026 (contemporaneous baseline; the original
   datasets classify all non-crisis days since 2000-01-04 as "calm").
2. Align the 2026 crisis window with the standard post-incident windows used
   for all other incidents (the 2026 war is coded as a 2026-02-28 incident
   with the same 7/14/21/30-day windows, not the whole Q1-Q2 block).
3. Report exact sample composition (crisis/calm counts per window and sample).
4. Justified incident list (each event documented in the report).
5. Inference: Welch t-test (continuity) plus Newey-West HAC standard errors
   (lag = window length) and quarter-clustered standard errors.

Outputs: analysis/reanalysis/findings_reanalysis.json and
analysis/reanalysis/reanalysis_report.md
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats

RUN = Path(__file__).resolve().parents[1]
OUT_DIR = RUN / "analysis" / "reanalysis"
OUT_DIR.mkdir(parents=True, exist_ok=True)

INCIDENTS: list[tuple[str, str, str]] = [
    ("2019-05-12", "Fujairah anchorage sabotage",
     "Four ships damaged near the UAE port of Fujairah, on the approaches to the Strait of Hormuz; attributed to Iran-aligned actors."),
    ("2019-06-13", "Gulf of Oman tanker attacks",
     "Two tankers (Kokuka Courageous, Front Altair) attacked in the Gulf of Oman on the main approach route to Hormuz."),
    ("2019-07-19", "Stena Impero seizure",
     "Iran seized the tanker Stena Impero in the Strait of Hormuz, a direct disruption of Hormuz transit."),
    ("2020-01-03", "Soleimani strike",
     "U.S. killed Qassem Soleimani; Iran publicly threatened closure of the Strait of Hormuz."),
    ("2020-01-08", "Iranian missile strikes",
     "Iran struck U.S. bases in Iraq in retaliation; Gulf war-risk repriced in oil markets."),
    ("2021-07-29", "Mercer Street attack",
     "Israel-linked tanker Mercer Street attacked with a drone off Oman, on the Hormuz approach route."),
    ("2023-10-07", "Regional escalation",
     "Start of the Israel-Hamas war; broad repricing of Middle East and Gulf supply risk (included as a regional-risk incident with justification)."),
    ("2024-04-13", "Iran-Israel exchange",
     "Iran launched its first direct attack on Israel; Gulf escalation risk."),
    ("2024-10-01", "Iran missile attack on Israel",
     "Iranian ballistic-missile attack on Israel; Gulf escalation risk."),
    ("2025-06-13", "Israel-Iran 12-day war",
     "Direct Israel-Iran war; Gulf and Hormuz supply risk at its highest since 2020."),
    ("2026-02-28", "Effective closure of the Strait of Hormuz",
     "War onset; effective closure of the strait disrupted ~20 mb/d of crude transit (EIA Global Energy Security Data)."),
]

VARIABLES = ["abs_brent_return_pct", "abs_wti_return_pct", "abs_hh_return_pct", "abs_epu_change"]
VAR_LABELS = {
    "abs_brent_return_pct": "Brent",
    "abs_wti_return_pct": "WTI",
    "abs_hh_return_pct": "Henry Hub",
    "abs_epu_change": "EPU",
}
WINDOWS = [7, 14, 21, 30]
SAMPLES = {
    "full_2019_2026": (pd.Timestamp("2019-01-01"), pd.Timestamp("2026-12-31")),
    "ex2026_2019_2025": (pd.Timestamp("2019-01-01"), pd.Timestamp("2025-12-31")),
}


def build_windows(dates: pd.Series, window_days: int) -> pd.Series:
    """True for business days within `window_days` calendar days after an incident."""
    idx = np.zeros(len(dates), dtype=bool)
    for incident, _label, _just in INCIDENTS:
        d0 = pd.Timestamp(incident)
        idx |= ((dates - d0).dt.days >= 0) & ((dates - d0).dt.days <= window_days)
    return pd.Series(idx, index=dates.index)


def build_pre_windows(dates: pd.Series, window_days: int) -> pd.Series:
    """True for business days in the [-2W, -W) calendar-day pre-window before an incident."""
    idx = np.zeros(len(dates), dtype=bool)
    for incident, _label, _just in INCIDENTS:
        d0 = pd.Timestamp(incident)
        idx |= ((dates - d0).dt.days >= -2 * window_days) & ((dates - d0).dt.days < -window_days)
    return pd.Series(idx, index=dates.index)


def welch(crisis: np.ndarray, calm: np.ndarray) -> dict:
    t, p = stats.ttest_ind(crisis, calm, equal_var=False, nan_policy="omit")
    d = (np.nanmean(crisis) - np.nanmean(calm)) / np.sqrt(
        (np.nanstd(crisis, ddof=1) ** 2 + np.nanstd(calm, ddof=1) ** 2) / 2
    )
    return {"t": float(t), "p": float(p), "cohen_d": float(d)}


def newey_west(y: np.ndarray, crisis: np.ndarray, lag: int) -> dict:
    x = sm.add_constant(crisis.astype(float))
    model = sm.OLS(y, x)
    fit = model.fit(cov_type="HAC", cov_kwds={"maxlags": lag, "use_correction": True})
    coef = fit.params[1]
    se = fit.bse[1]
    t = coef / se if se else np.nan
    p = 2 * (1 - stats.t.cdf(abs(t), df=max(1, int(fit.df_resid)))) if se else np.nan
    return {"diff": float(coef), "se_nw": float(se), "t_nw": float(t), "p_nw": float(p)}


def cluster_robust(y: np.ndarray, crisis: np.ndarray, clusters: np.ndarray) -> dict:
    x = sm.add_constant(crisis.astype(float))
    model = sm.OLS(y, x)
    fit = model.fit(cov_type="cluster", cov_kwds={"groups": clusters})
    coef = fit.params[1]
    se = fit.bse[1]
    t = coef / se if se else np.nan
    p = 2 * (1 - stats.t.cdf(abs(t), df=max(1, int(fit.df_resid)))) if se else np.nan
    return {"diff": float(coef), "se_cluster": float(se), "t_cluster": float(t), "p_cluster": float(p)}


def main() -> int:
    df = pd.read_csv(RUN / "datasets" / "raw" / "hormuz_event_windows_fred.csv", parse_dates=["date"])
    df["abs_brent_return_pct"] = df["brent_return_pct"].abs()
    df["abs_wti_return_pct"] = df["wti_return_pct"].abs()
    df["abs_hh_return_pct"] = df["hh_return_pct"].abs()
    df["abs_epu_change"] = df["epu_change"].abs()
    df = df.dropna(subset=VARIABLES).reset_index(drop=True)
    df["quarter"] = df["date"].dt.to_period("Q").astype(str)

    results: dict[str, dict] = {}
    for sample_name, (t0, t1) in SAMPLES.items():
        sub = df[(df["date"] >= t0) & (df["date"] <= t1)].copy()
        for window in WINDOWS:
            sub["crisis"] = build_windows(sub["date"], window)
            n_crisis = int(sub["crisis"].sum())
            n_calm = int((~sub["crisis"]).sum())
            lag = max(1, round(window * 5 / 7))
            key = f"{sample_name}_w{window}"
            results[key] = {
                "sample": sample_name,
                "window_calendar_days": window,
                "n_total": len(sub),
                "n_crisis": n_crisis,
                "n_calm": n_calm,
                "variables": {},
            }
            for var in VARIABLES:
                crisis = sub.loc[sub["crisis"], var].to_numpy()
                calm = sub.loc[~sub["crisis"], var].to_numpy()
                w = welch(crisis, calm)
                nw = newey_west(sub[var].to_numpy(), sub["crisis"].to_numpy(), lag)
                cl = cluster_robust(
                    sub[var].to_numpy(), sub["crisis"].to_numpy(), sub["quarter"].to_numpy()
                )
                results[key]["variables"][var] = {
                    "mean_crisis": float(np.nanmean(crisis)),
                    "mean_calm": float(np.nanmean(calm)),
                    **w,
                    **nw,
                    **cl,
                }

    # Design 2: fixed pre-window control [-2W, -W) around each incident (2019-2026 and ex-2026).
    # Days that fall inside any crisis window are excluded from the pre-window
    # control so that control days are never also crisis days.
    prepost: dict[str, dict] = {}
    for sample_name, (t0, t1) in SAMPLES.items():
        sub = df[(df["date"] >= t0) & (df["date"] <= t1)].copy()
        for window in WINDOWS:
            sub["crisis"] = build_windows(sub["date"], window)
            sub["pre"] = build_pre_windows(sub["date"], window) & ~sub["crisis"]
            use = sub[sub["crisis"] | sub["pre"]].copy()
            n_crisis = int(use["crisis"].sum())
            n_pre = int(use["pre"].sum())
            lag = max(1, round(window * 5 / 7))
            key = f"prepost_{sample_name}_w{window}"
            prepost[key] = {
                "sample": sample_name,
                "window_calendar_days": window,
                "n_crisis": n_crisis,
                "n_pre": n_pre,
                "variables": {},
            }
            for var in VARIABLES:
                crisis = use.loc[use["crisis"], var].to_numpy()
                pre = use.loc[use["pre"], var].to_numpy()
                w = welch(crisis, pre)
                nw = newey_west(use[var].to_numpy(), use["crisis"].to_numpy(), lag)
                cl = cluster_robust(
                    use[var].to_numpy(), use["crisis"].to_numpy(), use["quarter"].to_numpy()
                )
                prepost[key]["variables"][var] = {
                    "mean_crisis": float(np.nanmean(crisis)),
                    "mean_pre": float(np.nanmean(pre)),
                    **w,
                    **nw,
                    **cl,
                }

    # Design 3: 2026 closure isolated (crisis window after 2026-02-28 vs pre-window).
    closure: dict[str, dict] = {}
    sub = df[(df["date"] >= pd.Timestamp("2025-06-01")) & (df["date"] <= pd.Timestamp("2026-12-31"))].copy()
    for window in WINDOWS:
        sub["crisis"] = build_windows(sub["date"], window)
        sub["pre"] = build_pre_windows(sub["date"], window) & ~sub["crisis"]
        use = sub[sub["crisis"] | sub["pre"]].copy()
        n_crisis = int(use["crisis"].sum())
        n_pre = int(use["pre"].sum())
        lag = max(1, round(window * 5 / 7))
        key = f"closure2026_w{window}"
        closure[key] = {
            "sample": "closure_2026",
            "window_calendar_days": window,
            "n_crisis": n_crisis,
            "n_pre": n_pre,
            "variables": {},
        }
        for var in VARIABLES:
            crisis = use.loc[use["crisis"], var].to_numpy()
            pre = use.loc[use["pre"], var].to_numpy()
            w = welch(crisis, pre)
            nw = newey_west(use[var].to_numpy(), use["crisis"].to_numpy(), lag)
            cl = cluster_robust(
                use[var].to_numpy(), use["crisis"].to_numpy(), use["quarter"].to_numpy()
            )
            closure[key]["variables"][var] = {
                "mean_crisis": float(np.nanmean(crisis)),
                "mean_pre": float(np.nanmean(pre)),
                **w,
                **nw,
                **cl,
            }

    payload = {
        "incidents": [{"date": d, "label": l, "justification": j} for d, l, j in INCIDENTS],
        "results": results,
        "prepost": prepost,
        "closure": closure,
    }
    (OUT_DIR / "findings_reanalysis.json").write_text(
        json.dumps(payload, indent=2, default=str), encoding="utf-8"
    )

    lines = ["# Hormuz Crisis-Window Volatility: Methodological Re-Analysis", ""]
    lines.append("## Incident list and justification")
    lines.append("")
    lines.append("| Date | Incident | Justification |")
    lines.append("|---|---|---|")
    for d, l, j in INCIDENTS:
        lines.append(f"| {d} | {l} | {j} |")
    lines.append("")
    lines.append("## Design")
    lines.append("")
    lines.append("- Design 1 (corrected baseline): sample restricted to 2019-2026 (or 2019-2025),")
    lines.append("  crisis days = all business days within W calendar days after an incident")
    lines.append("  (2026 closure coded as a 2026-02-28 incident with the same windows);")
    lines.append("  control = all remaining days in the sample.")
    lines.append("- Design 2 (pre-window control): crisis days compared against the [-2W, -W)")
    lines.append("  calendar-day window immediately preceding each incident.")
    lines.append("- Design 3 (2026 closure isolated): post-closure windows vs pre-closure windows,")
    lines.append("  using only days near the 2026-02-28 closure.")
    lines.append("")
    lines.append("Inference: Welch t-test (as in the original paper), OLS with Newey-West HAC")
    lines.append("standard errors (lag = window length in business days), and OLS with")
    lines.append("quarter-clustered standard errors. Bonferroni-adjusted p-values are over the")
    lines.append("four variables within each specification.")
    lines.append("")

    lines.append("## Design 1: corrected full-sample baseline")
    lines.append("")
    lines.append("| Key | Sample | Window (days) | N total | N crisis | N calm |")
    lines.append("|---|---|---|---|---|---|")
    for key, r in results.items():
        lines.append(f"| {key} | {r['sample']} | {r['window_calendar_days']} | {r['n_total']} | {r['n_crisis']} | {r['n_calm']} |")
    lines.append("")
    for key, r in results.items():
        lines.append(f"### {key} ({r['sample']}, {r['window_calendar_days']}-day windows)")
        lines.append("")
        lines.append("| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |")
        lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
        for var in VARIABLES:
            v = r["variables"][var]
            pb = min(1.0, 4 * v["p"])
            lines.append(
                f"| {VAR_LABELS[var]} | {v['mean_crisis']:.4f} | {v['mean_calm']:.4f} | "
                f"{v['t']:.3f} | {v['p']:.4f} | {pb:.4f} | {v['diff']:.4f} | "
                f"{v['t_nw']:.3f} | {v['p_nw']:.4f} | {v['t_cluster']:.3f} | {v['p_cluster']:.4f} | {v['cohen_d']:.3f} |"
            )
        lines.append("")

    lines.append("## Design 2: pre-window control (crisis vs [-2W, -W) pre-window)")
    lines.append("")
    lines.append("| Key | Sample | Window (days) | N crisis | N pre |")
    lines.append("|---|---|---|---|---|")
    for key, r in prepost.items():
        lines.append(f"| {key} | {r['sample']} | {r['window_calendar_days']} | {r['n_crisis']} | {r['n_pre']} |")
    lines.append("")
    for key, r in prepost.items():
        lines.append(f"### {key} ({r['sample']}, {r['window_calendar_days']}-day windows)")
        lines.append("")
        lines.append("| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |")
        lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
        for var in VARIABLES:
            v = r["variables"][var]
            pb = min(1.0, 4 * v["p"])
            lines.append(
                f"| {VAR_LABELS[var]} | {v['mean_crisis']:.4f} | {v['mean_pre']:.4f} | "
                f"{v['t']:.3f} | {v['p']:.4f} | {pb:.4f} | {v['diff']:.4f} | "
                f"{v['t_nw']:.3f} | {v['p_nw']:.4f} | {v['t_cluster']:.3f} | {v['p_cluster']:.4f} | {v['cohen_d']:.3f} |"
            )
        lines.append("")

    lines.append("## Design 3: 2026 closure isolated (post-closure vs pre-closure windows)")
    lines.append("")
    for key, r in closure.items():
        lines.append(f"### {key} ({r['window_calendar_days']}-day windows; N crisis={r['n_crisis']}, N pre={r['n_pre']})")
        lines.append("")
        lines.append("| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |")
        lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
        for var in VARIABLES:
            v = r["variables"][var]
            pb = min(1.0, 4 * v["p"])
            lines.append(
                f"| {VAR_LABELS[var]} | {v['mean_crisis']:.4f} | {v['mean_pre']:.4f} | "
                f"{v['t']:.3f} | {v['p']:.4f} | {pb:.4f} | {v['diff']:.4f} | "
                f"{v['t_nw']:.3f} | {v['p_nw']:.4f} | {v['t_cluster']:.3f} | {v['p_cluster']:.4f} | {v['cohen_d']:.3f} |"
            )
        lines.append("")

    report = "\n".join(lines)
    (OUT_DIR / "reanalysis_report.md").write_text(report, encoding="utf-8")
    print(report)
    return 0


if __name__ == "__main__":
    sys.exit(main())
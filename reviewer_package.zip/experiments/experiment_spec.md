# Experiment Specification: Provenance-First Workflow Evaluation

## 1. Overview

This experiment evaluates whether a **provenance-first workflow** (i.e., a workflow that identifies and validates sources before drafting claims) improves the **citation-supported claim ratio** and reduces **unverified references** compared to two baseline workflows. The experiment also tests the contribution of three key components via ablations.

## 2. Hypothesis

> A provenance-first workflow improves the supported claim ratio and reduces unverified references compared to draft-first and literature-only workflows.

## 3. Workflows Under Test

### 3.1 Treatment: Provenance-First Workflow
1. Given a research question, first retrieve candidate sources and build a provenance log.
2. Verify each source for relevance and reliability.
3. Draft claims only from verified sources, with explicit citation links.
4. Run a reviewer pass to check that every claim is supported by its cited source.

### 3.2 Baseline 1: Draft-First Workflow
1. Given a research question, draft claims from model knowledge first.
2. Retrieve and attach references after drafting.
3. No explicit provenance log or pre-verification of sources.

### 3.3 Baseline 2: Literature-Only Workflow
1. Given a research question, retrieve a set of sources.
2. Generate claims by summarizing the retrieved literature.
3. No explicit verification step and no provenance log.

## 4. Inputs

- **Dataset**: A fixed set of `N` research questions or claim prompts (e.g., 100 questions) covering multiple domains.
- **Each input item**:
  - `question_id`: unique identifier
  - `question_text`: the research question or prompt
  - `gold_notes` (optional): any domain-specific constraints or expected scope

## 5. Outputs

For each input item and each workflow, the system produces:

- `claim`: a generated scientific claim
- `citations`: list of references supporting the claim
- `provenance_log` (treatment only): structured record of source retrieval, verification decisions, and claim-to-source mappings
- `verifier_scores`: per-claim and per-reference verification results

## 6. Evaluation Oracle

The oracle is an automated verifier that checks whether each generated claim is **fully supported** by its cited references.

### Oracle behavior:
- For each `(claim, citation)` pair, the oracle determines:
  - **Support**: Does the cited source contain evidence that directly supports the claim?
  - **Existence**: Is the reference real, accessible, and correctly identified?
- A claim is counted as **supported** if and only if **all** of its citations exist and support the claim.
- A reference is counted as **unverified** if:
  - It cannot be found/accessed, OR
  - It does not support the claim it is attached to.

## 7. Metrics

### 7.1 Primary Metric: `citation_supported_claim_ratio` (maximize)

\[
\text{citation\_supported\_claim\_ratio} = \frac{\text{number of claims with all citations verified as supporting}}{\text{total number of generated claims}}
\]

### 7.2 Secondary Metric: `unverified_reference_count` (minimize)

\[
\text{unverified\_reference\_count} = \sum_{\text{all generated outputs}} \text{number of references that are missing, inaccessible, or non-supporting}
\]

## 8. Ablations

To isolate the contribution of each component, the provenance-first workflow is run with the following components removed:

| Ablation | Removed Component | Expected Effect |
|----------|-------------------|-----------------|
| `without_verifier` | Source verification step | More unverified references, lower supported claim ratio |
| `without_reviewer` | Claim-to-source review pass | More unsupported claims, lower supported claim ratio |
| `without_provenance_log` | Structured provenance tracking | Reduced traceability, potentially lower supported claim ratio due to lost context |

Each ablation is evaluated on the same input dataset and compared against the full provenance-first workflow.

## 9. Success Criteria

The experiment is considered successful if **all** of the following hold:

1. **Primary improvement**: The provenance-first workflow achieves a `citation_supported_claim_ratio` that is **at least 10 percentage points higher** than both baselines.
2. **Secondary improvement**: The provenance-first workflow reduces `unverified_reference_count` by **at least 30%** relative to both baselines.
3. **Ablation degradation**: Removing any of the three components (`verifier`, `reviewer`, `provenance_log`) causes a measurable drop in `citation_supported_claim_ratio` (≥ 5 percentage points) or a measurable increase in `unverified_reference_count` (≥ 20%) compared to the full provenance-first workflow.
4. **Statistical significance**: Differences are significant at `p < 0.05` using an appropriate paired test (e.g., paired t-test or Wilcoxon signed-rank test) across the dataset.

## 10. Risks and Caveats

- **Mock dry-run metrics are illustrative only**: Any metrics produced during dry runs or mock evaluations do not reflect real system performance and must not be used to draw conclusions.
- **Oracle limitations**: The automated verifier may itself have false positives/negatives; a human-annotated validation subset should be used to estimate oracle accuracy.
- **Dataset bias**: Results may not generalize beyond the chosen question set; the dataset should be fixed and publicly documented before running the experiment.
- **Implementation variance**: Differences in retrieval backends or model versions across workflows must be controlled to ensure fair comparison.
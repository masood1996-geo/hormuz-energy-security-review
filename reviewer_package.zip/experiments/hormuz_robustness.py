"""Robustness analysis for the Hormuz event study (peer-review items).

Addresses:
1. Leave-one-event-out (LOO): Design-2 14-day tests for Brent/WTI with each of the
   eleven incidents removed in turn (Welch and Newey-West).
2. Placebo-date permutation test: 500 draws of 11 placebo dates (weekdays outside
   any real incident window), Design-2 14-day Welch t for Brent/WTI; empirical
   p-value = fraction of placebo draws with |t| >= observed |t|.
3. Confounder exclusion: re-run Design-2 14-day tests excluding the COVID crash
   (2020-02-20..2020-04-30) and the Russia-Ukraine energy crisis window
   (2022-02-24..2023-02-24) from the sample.
4. VIX-controlled regression: Brent/WTI volatility on crisis dummy + VIX level
   (Newey-West HAC), 14-day Design 2.

Outputs: analysis/reanalysis/findings_robustness.json, robustness_report.md
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

RUN = Path(__file__).resolve().parents[1]
OUT_DIR = RUN / "analysis" / "reanalysis"
OUT_DIR.mkdir(parents=True, exist_ok=True)

from hormuz_reanalysis import (  # noqa: E402
    INCIDENTS,
    build_pre_windows,
    build_windows,
    newey_west,
    welch,
)

VARS = ["abs_brent_return_pct", "abs_wti_return_pct"]
VAR_LABELS = {"abs_brent_return_pct": "Brent", "abs_wti_return_pct": "WTI"}
WINDOW = 14
N_PLACEBO = 500


def load() -> pd.DataFrame:
    df = pd.read_csv(RUN / "datasets" / "raw" / "hormuz_event_windows_fred.csv", parse_dates=["date"])
    df["abs_brent_return_pct"] = df["brent_return_pct"].abs()
    df["abs_wti_return_pct"] = df["wti_return_pct"].abs()
    df["abs_hh_return_pct"] = df["hh_return_pct"].abs()
    df["abs_epu_change"] = df["epu_change"].abs()
    vix = pd.read_csv(RUN / "datasets" / "cleaned" / "FRED_VIXCLS.cleaned.csv", parse_dates=["observation_date"])
    df = df.merge(vix.rename(columns={"observation_date": "date", "VIXCLS": "vix"})[["date", "vix"]],
                  on="date", how="left")
    df = df.dropna(subset=["abs_brent_return_pct", "abs_wti_return_pct"])
    df = df[(df["date"] >= "2019-01-01") & (df["date"] <= "2026-12-31")].reset_index(drop=True)
    return df


def design2_stats(sub: pd.DataFrame, var: str, window: int = WINDOW) -> dict:
    sub = sub.copy()
    sub["crisis"] = build_windows(sub["date"], window)
    sub["pre"] = build_pre_windows(sub["date"], window) & ~sub["crisis"]
    use = sub[sub["crisis"] | sub["pre"]]
    lag = max(1, round(window * 5 / 7))
    w = welch(use.loc[use["crisis"], var].to_numpy(), use.loc[use["pre"], var].to_numpy())
    nw = newey_west(use[var].to_numpy(), use["crisis"].to_numpy(), lag)
    return {
        "n_crisis": int(use["crisis"].sum()), "n_pre": int(use["pre"].sum()),
        "mean_crisis": float(np.nanmean(use.loc[use["crisis"], var])),
        "mean_pre": float(np.nanmean(use.loc[use["pre"], var])),
        "t": float(w["t"]), "p": float(w["p"]), "t_nw": float(nw["t_nw"]), "p_nw": float(nw["p_nw"]),
    }


def main() -> int:
    df = load()
    base = {var: design2_stats(df, var) for var in VARS}

    # 1. Leave-one-event-out
    loo = {var: [] for var in VARS}
    for d0, label, _j in INCIDENTS:
        drop = pd.Timestamp(d0)
        sub = df[~(build_windows(df["date"], WINDOW) & ((df["date"] - drop).dt.days.abs() <= WINDOW))].copy()
        for var in VARS:
            s = design2_stats(sub, var)
            s["dropped"] = d0
            s["dropped_label"] = label
            loo[var].append(s)

    # 2. Placebo dates
    rng = np.random.default_rng(42)
    real_windows = np.zeros(len(df), dtype=bool)
    for d0, _l, _j in INCIDENTS:
        real_windows |= ((df["date"] - pd.Timestamp(d0)).dt.days.abs() <= 2 * WINDOW).to_numpy()
    candidate_idx = np.where(~real_windows & (df["date"].dt.weekday < 5))[0]
    placebo_t = {var: [] for var in VARS}
    for _rep in range(N_PLACEBO):
        picks = rng.choice(candidate_idx, size=min(11, len(candidate_idx)), replace=False)
        sub = df.reset_index(drop=True).copy()
        sub["crisis"] = False
        for idx in picks:
            d0 = sub.iloc[idx]["date"]
            sub["crisis"] |= ((sub["date"] - d0).dt.days >= 0) & ((sub["date"] - d0).dt.days <= WINDOW)
        sub["pre"] = build_pre_windows(sub["date"], WINDOW) & ~sub["crisis"]
        use = sub[sub["crisis"] | sub["pre"]]
        for var in VARS:
            w = welch(use.loc[use["crisis"], var].to_numpy(), use.loc[use["pre"], var].to_numpy())
            placebo_t[var].append(float(w["t"]))
    placebo = {}
    for var in VARS:
        arr = np.array(placebo_t[var])
        obs = abs(base[var]["t"])
        placebo[var] = {
            "empirical_p": float((np.abs(arr) >= obs).mean()),
            "n_draws": N_PLACEBO,
            "mean_placebo_t": float(arr.mean()),
            "p95_abs_t": float(np.quantile(np.abs(arr), 0.95)),
        }

    # 3. Confounder exclusion
    excl = {"covid": (pd.Timestamp("2020-02-20"), pd.Timestamp("2020-04-30")),
            "ukraine": (pd.Timestamp("2022-02-24"), pd.Timestamp("2023-02-24"))}
    confounders = {}
    for name, (t0, t1) in excl.items():
        sub = df[~((df["date"] >= t0) & (df["date"] <= t1))].copy()
        confounders[name] = {var: design2_stats(sub, var) for var in VARS}

    # 4. VIX-controlled regression (NW-HAC), Design 2 14-day
    import statsmodels.api as sm

    vix_reg = {}
    sub = df.copy()
    sub["crisis"] = build_windows(sub["date"], WINDOW)
    sub["pre"] = build_pre_windows(sub["date"], WINDOW) & ~sub["crisis"]
    use = sub[sub["crisis"] | sub["pre"]].dropna(subset=["vix"])
    lag = max(1, round(WINDOW * 5 / 7))
    for var in VARS:
        y = use[var].to_numpy()
        X = sm.add_constant(np.column_stack([use["crisis"].astype(float).to_numpy(), use["vix"].to_numpy()]))
        fit = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": lag, "use_correction": True})
        vix_reg[var] = {
            "beta_crisis": float(fit.params[1]),
            "se_crisis": float(fit.bse[1]),
            "t_crisis": float(fit.params[1] / fit.bse[1]),
            "p_crisis": float(2 * (1 - stats.t.cdf(abs(fit.params[1] / fit.bse[1]), df=max(1, int(fit.df_resid))))),
            "beta_vix": float(fit.params[2]),
            "n": int(len(use)),
        }

    payload = {"base": base, "loo": loo, "placebo": placebo, "confounders": confounders, "vix_reg": vix_reg}
    (OUT_DIR / "findings_robustness.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    L = ["# Robustness Analysis (peer-review items)", ""]
    L.append(f"Baseline Design-2, {WINDOW}-day windows, full sample:")
    L.append("")
    L.append("| Variable | N crisis | N pre | Crisis mean | Pre mean | Welch t | p | NW t | NW p |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for var in VARS:
        b = base[var]
        L.append(f"| {VAR_LABELS[var]} | {b['n_crisis']} | {b['n_pre']} | {b['mean_crisis']:.3f} | "
                 f"{b['mean_pre']:.3f} | {b['t']:.2f} | {b['p']:.3f} | {b['t_nw']:.2f} | {b['p_nw']:.3f} |")
    L.append("")
    L.append("## 1. Leave-one-event-out")
    L.append("")
    L.append("| Dropped incident | Brent t | Brent p | Brent NW p | WTI t | WTI p | WTI NW p |")
    L.append("|---|---|---|---|---|---|---|")
    for i in range(len(INCIDENTS)):
        b_, w_ = loo["abs_brent_return_pct"][i], loo["abs_wti_return_pct"][i]
        L.append(f"| {b_['dropped_label']} ({b_['dropped']}) | {b_['t']:.2f} | {b_['p']:.3f} | "
                 f"{b_['p_nw']:.3f} | {w_['t']:.2f} | {w_['p']:.3f} | {w_['p_nw']:.3f} |")
    L.append("")
    L.append("## 2. Placebo-date permutation test (500 draws)")
    L.append("")
    L.append("| Variable | Observed |t| | Empirical p | Mean placebo t | 95th pct |t| |")
    L.append("|---|---|---|---|---|")
    for var in VARS:
        p_ = placebo[var]
        L.append(f"| {VAR_LABELS[var]} | {abs(base[var]['t']):.2f} | {p_['empirical_p']:.3f} | "
                 f"{p_['mean_placebo_t']:.2f} | {p_['p95_abs_t']:.2f} |")
    L.append("")
    L.append("## 3. Confounder exclusion")
    L.append("")
    L.append("| Excluded period | Variable | N | Welch t | p | NW p |")
    L.append("|---|---|---|---|---|---|")
    for name, res in confounders.items():
        for var in VARS:
            s = res[var]
            L.append(f"| {name} ({excl[name][0].date()}..{excl[name][1].date()}) | {VAR_LABELS[var]} | "
                     f"{s['n_crisis'] + s['n_pre']} | {s['t']:.2f} | {s['p']:.3f} | {s['p_nw']:.3f} |")
    L.append("")
    L.append("## 4. VIX-controlled regression (NW-HAC), Design 2 14-day")
    L.append("")
    L.append("| Variable | Beta crisis | SE | t | p | Beta VIX | N |")
    L.append("|---|---|---|---|---|---|---|")
    for var in VARS:
        r = vix_reg[var]
        L.append(f"| {VAR_LABELS[var]} | {r['beta_crisis']:.4f} | {r['se_crisis']:.4f} | "
                 f"{r['t_crisis']:.2f} | {r['p_crisis']:.3f} | {r['beta_vix']:.4f} | {r['n']} |")
    L.append("")
    report = "\n".join(L)
    (OUT_DIR / "robustness_report.md").write_text(report, encoding="utf-8")
    print(report)
    return 0


if __name__ == "__main__":
    sys.exit(main())
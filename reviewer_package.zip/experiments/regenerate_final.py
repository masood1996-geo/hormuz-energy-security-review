"""Regenerate publication artifacts from the improved manuscript.

- final/paper_final.pdf  : Times New Roman 11pt, justified (experiments/render_pdf.py)
- final/paper_final.tex  : latex from markdown ($$ equations de-wrapped for clean text)
- final/paper_final.docx : docx from markdown (same de-wrapped input)
- final/figures/         : copies of the three publication figures
- publication/paper_candidate.pdf : candidate rendered with the same renderer
- drafts/paper_revised.md/.pdf    : synced from the candidate
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path

RESEARCH = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(RESEARCH))

from researchagent.export_bundle import (  # noqa: E402
    write_docx_from_markdown,
    write_latex_from_markdown,
)

RUN = Path(__file__).resolve().parents[1]
FINAL = RUN / "final"
FIGURES = FINAL / "figures"
PUB = RUN / "publication"
DRAFTS = RUN / "drafts"


def strip_math(text: str) -> str:
    """Remove $$ wrappers so docx sees clean plain-text equations."""
    lines = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("$$") and s.endswith("$$") and len(s) > 4:
            lines.append(s.strip("$").strip())
        else:
            lines.append(line)
    return "\n".join(lines)


LATEX_EQUATIONS = {
    "1": r"r(t) = \frac{P(t) - P(t-1)}{P(t-1)} \times 100",
    "2": r"V(t) = |r(t)|",
    "3": r"V_{EPU}(t) = |\Delta EPU(t)|, \quad V_k(t) = |\Delta k(t)|, \quad k \in \{VIX, OVX, GVZ\}",
    "4": r"Crisis_k(W) = [T_k, T_k + W]",
    "5": r"V(t) = \alpha + \beta \cdot D_{crisis}(t) + \varepsilon(t)",
    "6": (r"d = \frac{\mu_{crisis} - \mu_{control}}{s_{pooled}}, \quad "
          r"s_{pooled} = \sqrt{\frac{(n_1 - 1)s_1^2 + (n_2 - 1)s_2^2}{n_1 + n_2 - 2}}"),
}


def tex_equations(text: str) -> str:
    """Replace $$.. (n)$$ lines with markers; expand them in the generated tex."""
    lines = []
    markers: dict[str, str] = {}
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("$$") and s.endswith("$$") and len(s) > 4:
            m = re.match(r"^(.*?)\s*\((\d+)\)\s*$", s.strip("$").strip())
            body = LATEX_EQUATIONS.get(m.group(2)) if m else None
            if body:
                marker = f"LATEXEQ{m.group(2)}"
                markers[marker] = (
                    "\\begin{equation}\n" + body + "\n\\end{equation}"
                )
                lines.append(marker)
            else:
                lines.append(s.strip("$").strip())
        else:
            lines.append(line)
    return "\n".join(lines), markers


def expand_tex_markers(tex: str, markers: dict[str, str]) -> str:
    for marker, block in markers.items():
        tex = re.sub(rf"{marker}\\par", lambda _m: block, tex)
        tex = tex.replace(marker, block)
    return tex


def main() -> int:
    FIGURES.mkdir(exist_ok=True)
    for fig in sorted((PUB / "figures").glob("*.png")):
        shutil.copy2(fig, FIGURES / fig.name)
        print(f"copied {fig.name}")

    md = FINAL / "paper_final.md"
    plain = strip_math(md.read_text(encoding="utf-8"))
    latex, markers = tex_equations(md.read_text(encoding="utf-8"))

    (FINAL / "paper_final.tex").write_text("", encoding="utf-8")
    tmp_md = RUN / "scratch_plain.md"
    tmp_md.write_text(latex, encoding="utf-8")
    write_latex_from_markdown(tmp_md, FINAL / "paper_final.tex",
                              title="The Strait of Hormuz and Global Energy Security")
    tex = (FINAL / "paper_final.tex").read_text(encoding="utf-8")
    (FINAL / "paper_final.tex").write_text(expand_tex_markers(tex, markers), encoding="utf-8")
    print("latex written")

    tmp_md.write_text(plain, encoding="utf-8")
    write_docx_from_markdown(tmp_md, FINAL / "paper_final.docx")
    print("docx written")
    tmp_md.unlink(missing_ok=True)

    r = subprocess.run([sys.executable, str(RUN / "experiments" / "render_pdf.py")],
                       capture_output=True, text=True, cwd=RUN)
    print(r.stdout.strip() or r.stderr.strip())

    shutil.copy2(PUB / "paper_candidate.md", DRAFTS / "paper_revised.md")
    r = subprocess.run(
        [sys.executable, str(RUN / "experiments" / "render_pdf.py"),
         str(PUB / "paper_candidate.md"), str(PUB / "paper_candidate.pdf"), str(PUB)],
        capture_output=True, text=True, cwd=RUN)
    print(r.stdout.strip() or r.stderr.strip())
    r = subprocess.run(
        [sys.executable, str(RUN / "experiments" / "render_pdf.py"),
         str(DRAFTS / "paper_revised.md"), str(DRAFTS / "paper_revised.pdf"), str(PUB)],
        capture_output=True, text=True, cwd=RUN)
    print(r.stdout.strip() or r.stderr.strip())
    return 0


if __name__ == "__main__":
    sys.exit(main())
"""Refresh dataset provenance records in the run memory (post-regeneration fix).

The datasets `eia_chokepoint_oil_flows_quarterly`, `eia_chokepoint_lng_flows_quarterly`
and `hormuz_event_volatility_no2026` (and its 7/21/30-day variants) were regenerated
after the original analysis, invalidating the pinned checksums and findings hashes in
`data/memory/run_memory.sqlite`. This script recomputes, for every dataset record, the
current raw-file SHA-256 and the deterministic `analyze_dataset` replay digest exactly
as `provenance.verify_project` computes them, and updates the two columns.
"""
from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

RESEARCH = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(RESEARCH))

from researchagent.data_analyzer import analyze_dataset  # noqa: E402
from researchagent.provenance import sha256_file, sha256_text  # noqa: E402

RUN = Path(__file__).resolve().parents[1]
DB = RUN / "data" / "memory" / "run_memory.sqlite"


def main() -> int:
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("SELECT * FROM dataset_records ORDER BY id").fetchall()
    updated = 0
    problems: list[str] = []
    for row in rows:
        rec = dict(row)
        local = str(rec.get("local_path") or "")
        cleaned = str(rec.get("cleaned_path") or "")
        label = str(rec.get("name") or f"dataset#{rec.get('id')}")
        new_checksum = ""
        new_findings = ""
        if local and Path(local).exists():
            new_checksum = sha256_file(Path(local))
        if cleaned and Path(cleaned).exists():
            try:
                replay = analyze_dataset(
                    Path(cleaned),
                    name=str(rec.get("name") or Path(cleaned).stem),
                    source=str(rec.get("source") or ""),
                    dataset_id=rec.get("id"),
                )
                new_findings = sha256_text(json.dumps(replay.to_dict(), sort_keys=True, default=str))
            except Exception as exc:  # noqa: BLE001 - record and continue
                problems.append(f"{label}#{rec.get('id')}: replay error: {exc}")
                continue
        if not new_checksum or not new_findings:
            problems.append(f"{label}#{rec.get('id')}: missing raw/cleaned file")
            continue
        conn.execute(
            "UPDATE dataset_records SET checksum_sha256 = ?, findings_sha256 = ? WHERE id = ?",
            (new_checksum, new_findings, rec["id"]),
        )
        updated += 1
    conn.commit()
    conn.close()
    print(f"updated {updated} dataset record(s)")
    if problems:
        print("problems:")
        for p in problems:
            print(" -", p)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
"""Per-incident event statistics and horizon-mean table (peer-review items).

1. For each of the eleven incidents: Design-2 14-day crisis/pre means and Welch
   t/p for Brent and WTI (event-level evidence).
2. Design-2 crisis/pre means at all four horizons (7/14/21/30) for the four core
   series and the supplementary series (horizon-mean table for Appendix A).
3. Alternative volatility specifications (Design-2, 14- and 30-day):
   - squared returns (Brent, WTI)
   - |log returns| (Brent, WTI)
   - implied-volatility levels (VIX, OVX, GVZ mean levels)
4. Figure 4: per-incident Brent 14-day pre vs crisis volatility bars.

Outputs: analysis/reanalysis/findings_eventlevel.json, eventlevel_report.md,
publication/figures/fig4_event_by_incident.png
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

RUN = Path(__file__).resolve().parents[1]
OUT_DIR = RUN / "analysis" / "reanalysis"
OUT_DIR.mkdir(parents=True, exist_ok=True)

from hormuz_reanalysis import INCIDENTS, build_pre_windows, build_windows, welch  # noqa: E402

WINDOW = 14


def load() -> pd.DataFrame:
    df = pd.read_csv(RUN / "datasets" / "raw" / "hormuz_event_windows_fred.csv", parse_dates=["date"])
    df["abs_brent_return_pct"] = df["brent_return_pct"].abs()
    df["abs_wti_return_pct"] = df["wti_return_pct"].abs()
    df["abs_hh_return_pct"] = df["hh_return_pct"].abs()
    df["abs_epu_change"] = df["epu_change"].abs()
    df["brent2"] = df["brent_return_pct"] ** 2
    df["wti2"] = df["wti_return_pct"] ** 2
    df["brent_log"] = np.log1p(df["brent_return_pct"] / 100).abs() * 100
    df["wti_log"] = np.log1p(df["wti_return_pct"] / 100).abs() * 100
    for name, sid in [("vix", "VIXCLS"), ("ovx", "OVXCLS"), ("gvz", "GVZCLS")]:
        s = pd.read_csv(RUN / "datasets" / "cleaned" / f"FRED_{sid}.cleaned.csv", parse_dates=["observation_date"])
        df = df.merge(s.rename(columns={"observation_date": "date", sid: name})[["date", name]], on="date", how="left")
    df = df.dropna(subset=["abs_brent_return_pct"])
    return df[(df["date"] >= "2019-01-01") & (df["date"] <= "2026-12-31")].reset_index(drop=True)


def main() -> int:
    df = load()

    # 1. per-incident event stats (Design 2, 14-day)
    events = []
    for d0, label, _j in INCIDENTS:
        d0 = pd.Timestamp(d0)
        sub = df.copy()
        sub["crisis"] = ((sub["date"] - d0).dt.days >= 0) & ((sub["date"] - d0).dt.days <= WINDOW)
        sub["pre"] = ((sub["date"] - d0).dt.days >= -2 * WINDOW) & ((sub["date"] - d0).dt.days < -WINDOW)
        use = sub[sub["crisis"] | sub["pre"]]
        row = {"date": str(d0.date()), "label": label}
        for var in ["abs_brent_return_pct", "abs_wti_return_pct"]:
            crisis = use.loc[use["crisis"], var].to_numpy()
            pre = use.loc[use["pre"], var].to_numpy()
            w = welch(crisis, pre)
            row[var] = {"mean_crisis": float(crisis.mean()), "mean_pre": float(pre.mean()),
                        "n_crisis": int(len(crisis)), "n_pre": int(len(pre)),
                        "t": float(w["t"]), "p": float(w["p"])}
        events.append(row)

    # 2. horizon means (Design 2) for core + supplementary series
    horizon = {}
    for window in [7, 14, 21, 30]:
        crisis_all = build_windows(df["date"], window)
        pre_all = build_pre_windows(df["date"], window) & ~crisis_all
        use = df[crisis_all | pre_all]
        horizon[str(window)] = {}
        for var in ["abs_brent_return_pct", "abs_wti_return_pct", "abs_hh_return_pct",
                    "abs_epu_change", "vix", "ovx", "gvz"]:
            c = use.loc[crisis_all, var].to_numpy()
            p_ = use.loc[pre_all, var].to_numpy()
            horizon[str(window)][var] = {"crisis": float(np.nanmean(c)), "pre": float(np.nanmean(p_)),
                                         "n_crisis": int(crisis_all.sum()), "n_pre": int(pre_all.sum())}

    # 3. alternative volatility specifications (Design 2, 14/30-day)
    alt = {}
    for window in [14, 30]:
        crisis_all = build_windows(df["date"], window)
        pre_all = build_pre_windows(df["date"], window) & ~crisis_all
        use = df[crisis_all | pre_all]
        alt[str(window)] = {}
        for var in ["brent2", "wti2", "brent_log", "wti_log", "vix", "ovx", "gvz"]:
            c = use.loc[crisis_all, var].to_numpy()
            p_ = use.loc[pre_all, var].to_numpy()
            w = welch(c, p_)
            alt[str(window)][var] = {"mean_crisis": float(np.nanmean(c)), "mean_pre": float(np.nanmean(p_)),
                                     "t": float(w["t"]), "p": float(w["p"])}

    payload = {"events": events, "horizon": horizon, "alt": alt}
    (OUT_DIR / "findings_eventlevel.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # 4. Figure 4: per-incident Brent 14-day pre vs crisis
    labels = [f"{e['label'][:18]}\n{e['date'][:10]}" for e in events]
    pre = [e["abs_brent_return_pct"]["mean_pre"] for e in events]
    crs = [e["abs_brent_return_pct"]["mean_crisis"] for e in events]
    ps = [e["abs_brent_return_pct"]["p"] for e in events]
    x = np.arange(len(events))
    fig, ax = plt.subplots(figsize=(7.6, 4.0), constrained_layout=True)
    ax.bar(x - 0.19, pre, 0.38, color="#9aa5b1", label="Pre-incident window")
    ax.bar(x + 0.19, crs, 0.38, color="#c0392b", label="Crisis window (14 days)")
    for xi, (v, p_) in enumerate(zip(crs, ps)):
        if p_ < 0.05:
            ax.text(xi + 0.19, v + 0.1, "*", ha="center", fontsize=11)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=6.4, rotation=42, ha="right")
    ax.set_ylabel("Mean absolute daily return (%)")
    ax.legend(fontsize=8, frameon=False)
    ax.set_ylim(0, max(crs) * 1.25)
    out = RUN / "publication" / "figures" / "fig4_event_by_incident.png"
    fig.savefig(out, bbox_inches="tight", dpi=300)
    print(f"wrote {out}")

    L = ["# Event-Level and Alternative-Specification Analysis", ""]
    L.append("## Per-incident Design-2 14-day statistics (Brent, WTI)")
    L.append("")
    L.append("| Incident | Brent crisis | Brent pre | t | p | WTI crisis | WTI pre | t | p |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for e in events:
        b, w = e["abs_brent_return_pct"], e["abs_wti_return_pct"]
        L.append(f"| {e['label']} ({e['date']}) | {b['mean_crisis']:.2f} | {b['mean_pre']:.2f} | "
                 f"{b['t']:.2f} | {b['p']:.3f} | {w['mean_crisis']:.2f} | {w['mean_pre']:.2f} | "
                 f"{w['t']:.2f} | {w['p']:.3f} |")
    L.append("")
    L.append("## Design-2 horizon means (crisis vs pre)")
    L.append("")
    L.append("| Window | Series | Crisis mean | Pre mean | N crisis | N pre |")
    L.append("|---|---|---|---|---|---|")
    for w, d in horizon.items():
        for var, v in d.items():
            L.append(f"| {w} | {var} | {v['crisis']:.3f} | {v['pre']:.3f} | {v['n_crisis']} | {v['n_pre']} |")
    L.append("")
    L.append("## Alternative volatility specifications (Design 2)")
    L.append("")
    L.append("| Window | Variable | Crisis mean | Pre mean | Welch t | p |")
    L.append("|---|---|---|---|---|---|")
    for w, d in alt.items():
        for var, v in d.items():
            L.append(f"| {w} | {var} | {v['mean_crisis']:.4f} | {v['mean_pre']:.4f} | {v['t']:.2f} | {v['p']:.3f} |")
    L.append("")
    (OUT_DIR / "eventlevel_report.md").write_text("\n".join(L), encoding="utf-8")
    print("\n".join(L[:40]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
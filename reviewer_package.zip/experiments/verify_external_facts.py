"""Second extraction pass: flows, reserves, GDP, Petroline, spare capacity."""
import re
from pathlib import Path

import fitz

TMP = Path(r"C:\Users\melay\AppData\Local\Temp\opencode")


def extract(path: Path) -> str:
    doc = fitz.open(str(path))
    return "\n".join(page.get_text() for page in doc)


def show(term: str, text: str, label: str, limit: int = 260) -> None:
    hits = list(re.finditer(term, text, re.I))
    print(f"-- {label}: {len(hits)} hit(s)")
    for m in hits[:3]:
        s = max(0, m.start() - 120)
        print("   ...", re.sub(r"\s+", " ", text[s:m.end() + 160])[:limit], "...")
    if not hits:
        print("   (none)")


iea = extract(TMP / "StraitofHormuz2026-Factsheet.pdf")
crs = extract(TMP / "R45281.6.pdf")

show(r"29 nautical", crs, "CRS width")
show(r"mb/d", crs, "CRS flows", 200)
show(r"million b/d", crs, "CRS million b/d")
show(r"1,541", crs, "CRS China reserves")
show(r"413", crs, "CRS US SPR", 200)
show(r"2.45", crs, "CRS GDP India")
show(r"1.82", crs, "CRS GDP China")
show(r"1.25", crs, "CRS GDP EU")
show(r"spare", crs, "CRS spare capacity")
show(r"4.4 mb/d|4\.4", crs, "CRS 4.4")
show(r"Petroline", iea, "IEA Petroline")
show(r"petroleum products", iea, "IEA flows", 220)
show(r"21\.6|20\.7|14\.9|14\.6", crs, "CRS 2026 flow numbers")
show(r"Qatar|LNG", crs, "CRS LNG", 200)
"""Render the Hormuz manuscript PDF: Times New Roman 11pt, justified text.

Project-local renderer for the improved article. Requirements:
- Times New Roman (real TTF from the system fonts; falls back to the
  reportlab built-in Times-Roman family if the TTF is unavailable)
- 11pt body, justified paragraphs
- centered display equations (markdown lines wrapped in $$ ... $$)
- tables, images, captions, bullet lists, headings
- Unicode-safe: any glyph missing from the font is reported, never
  silently replaced with a black square
"""
from __future__ import annotations

import html
import re
import sys
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

FONT_DIR = Path("C:/Windows/Fonts")


def register_fonts() -> tuple[str, str, str, str]:
    """Register Times New Roman TTFs; return (regular, bold, italic, bolditalic)."""
    candidates = [
        ("TNR", "times.ttf", "TNR-Bold", "timesbd.ttf",
         "TNR-Italic", "timesi.ttf", "TNR-BoldItalic", "timesbi.ttf"),
    ]
    for name, reg, bold_name, bold_file, ital_name, ital_file, bi_name, bi_file in candidates:
        reg_path = FONT_DIR / reg
        if reg_path.exists():
            pdfmetrics.registerFont(TTFont(name, str(reg_path)))
            pdfmetrics.registerFont(TTFont(bold_name, str(FONT_DIR / bold_file)))
            pdfmetrics.registerFont(TTFont(ital_name, str(FONT_DIR / ital_file)))
            pdfmetrics.registerFont(TTFont(bi_name, str(FONT_DIR / bi_file)))
            pdfmetrics.registerFontFamily(name, normal=name, bold=bold_name,
                                          italic=ital_name, boldItalic=bi_name)
            return name, bold_name, ital_name, bi_name
    return "Times-Roman", "Times-Bold", "Times-Italic", "Times-BoldItalic"


def check_glyphs(text: str, font_path: Path, missing: set[str]) -> None:
    """Report characters not covered by the TTF font (fontTools optional)."""
    try:
        from fontTools.ttLib import TTFont as FT

        f = FT(str(font_path))
        cmap = f.getBestCmap()
        for ch in set(text):
            if ord(ch) > 0x7E and ord(ch) not in cmap:
                missing.add(ch)
    except Exception:
        pass


def main(argv: list[str] | None = None) -> int:
    args = argv if argv is not None else sys.argv[1:]
    if args:
        markdown_path = Path(args[0]).resolve()
        pdf_path = Path(args[1]).resolve() if len(args) > 1 else markdown_path.with_suffix(".pdf")
        image_root = Path(args[2]).resolve() if len(args) > 2 else markdown_path.parent
    else:
        run_root = Path(__file__).resolve().parents[1]
        markdown_path = run_root / "final" / "paper_final.md"
        pdf_path = run_root / "final" / "paper_final.pdf"
        image_root = markdown_path.parent

    reg, bold, ital, bold_ital = register_fonts()
    body_style = ParagraphStyle(
        "Body", fontName=reg, fontSize=11, leading=15.5, alignment=TA_JUSTIFY,
        spaceAfter=7, firstLineIndent=0,
    )
    eq_style = ParagraphStyle(
        "Eq", parent=body_style, alignment=TA_CENTER, spaceBefore=6, spaceAfter=8,
        fontName=ital,
    )
    eq_num_style = ParagraphStyle(
        "EqNum", parent=body_style, alignment=TA_RIGHT, spaceBefore=6, spaceAfter=8,
        fontName=reg,
    )
    h1 = ParagraphStyle("H1", fontName=bold, fontSize=15, leading=19,
                        spaceBefore=12, spaceAfter=7)
    h2 = ParagraphStyle("H2", fontName=bold, fontSize=13, leading=17,
                        spaceBefore=10, spaceAfter=6)
    h3 = ParagraphStyle("H3", fontName=bold, fontSize=11.5, leading=15,
                        spaceBefore=8, spaceAfter=5)
    title_style = ParagraphStyle("Title", fontName=bold, fontSize=16, leading=21,
                                 alignment=TA_CENTER, spaceAfter=24)
    caption_style = ParagraphStyle("Caption", fontName=ital, fontSize=9.5, leading=12.5,
                                   alignment=TA_JUSTIFY, spaceAfter=10)
    table_note_style = ParagraphStyle("TNote", fontName=ital, fontSize=9, leading=11.5,
                                      alignment=TA_JUSTIFY, spaceAfter=9)
    ref_style = ParagraphStyle("Ref", parent=body_style, fontSize=10.5, leading=13.5,
                               alignment=TA_LEFT, spaceAfter=3)
    cell_style = ParagraphStyle("Cell", fontName=reg, fontSize=8.5, leading=10.5,
                                alignment=TA_LEFT, splitLongWords=0)
    cell_header = ParagraphStyle("CellHead", fontName=bold, fontSize=8.5, leading=10.5,
                                 alignment=TA_LEFT, splitLongWords=0)

    missing: set[str] = set()
    if (FONT_DIR / "times.ttf").exists():
        check_glyphs(markdown_path.read_text(encoding="utf-8"), FONT_DIR / "times.ttf", missing)

    def esc(value: str) -> str:
        return html.escape(value, quote=False)

    def inline(value: str) -> str:
        value = esc(value)
        value = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", value)
        value = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"<i>\1</i>", value)
        value = re.sub(r"`([^`]+)`", r"<font face='Courier'>\1</font>", value)
        value = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1", value)
        return value

    text = markdown_path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    story = []
    first_heading = True
    i = 0
    in_refs = False
    while i < len(lines):
        raw = lines[i]
        stripped = raw.strip()
        if not stripped:
            i += 1
            continue
        if stripped.startswith("|") and i + 1 < len(lines) and re.match(r"^\s*\|?[\s:|-]+\|?\s*$", lines[i + 1].strip()):
            table_buf = [stripped]
            i += 1
            while i < len(lines) and lines[i].strip().startswith("|"):
                table_buf.append(lines[i].strip())
                i += 1
            header_cells = [c.strip() for c in table_buf[0].strip("|").split("|")]
            data = []
            for row in table_buf[2:]:
                cells = [c.strip() for c in row.strip("|").split("|")]
                while len(cells) < len(header_cells):
                    cells.append("")
                data.append([Paragraph(inline(c), cell_style) for c in cells])
            table = Table([header_cells, *data], hAlign="LEFT", repeatRows=1)
            table.setStyle(
                TableStyle([
                    ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                    ("FONTNAME", (0, 0), (-1, 0), bold),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 4),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                    ("TOPPADDING", (0, 0), (-1, -1), 3),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ])
            )
            story.append(table)
            story.append(Spacer(1, 7))
            continue
        if stripped.startswith("$$"):
            eq = stripped.strip("$").strip()
            if eq:
                m = re.match(r"^(.*?)\s*\((\d+)\)\s*$", eq)
                if m:
                    content, num = m.group(1).strip(), m.group(2)
                else:
                    content, num = eq, ""
                eq_flow = Paragraph(inline(content), eq_style)
                if num:
                    num_flow = Paragraph(f"({num})", eq_num_style)
                    eq_table = Table([[eq_flow, num_flow]],
                                     colWidths=[5.55 * inch, 0.62 * inch], hAlign="CENTER")
                    eq_table.setStyle(TableStyle([
                        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                        ("LEFTPADDING", (0, 0), (-1, -1), 0),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                        ("TOPPADDING", (0, 0), (-1, -1), 5),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                    ]))
                    story.append(eq_table)
                else:
                    story.append(eq_flow)
            i += 1
            continue
        img = re.match(r"!\[([^\]]*)\]\(([^)]+)\)", stripped)
        if img:
            caption, rel = img.group(1), img.group(2)
            path = (image_root / rel.lstrip("./"))
            if path.exists() and path.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif"}:
                try:
                    img_flow = Image(str(path))
                    img_flow.drawWidth = min(img_flow.imageWidth, 6.0 * inch)
                    img_flow.drawHeight = img_flow.imageHeight * (img_flow.drawWidth / img_flow.imageWidth)
                    caption_flow = None
                    if caption:
                        caption_flow = Paragraph(inline(caption), caption_style)
                    block = [Spacer(1, 6), img_flow, Spacer(1, 4)]
                    if caption_flow is not None:
                        block.append(caption_flow)
                    story.append(KeepTogether(block))
                except Exception:
                    pass
            i += 1
            continue
        if stripped.startswith("|"):
            i += 1
            continue
        if stripped.startswith("---"):
            i += 1
            continue
        if stripped.startswith("#"):
            m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
            level = len(m.group(1))
            content = inline(m.group(2))
            if level == 1 and first_heading:
                story.append(Paragraph(content, title_style))
                first_heading = False
            else:
                style = {1: h1, 2: h2, 3: h3}.get(level, h3)
                story.append(Paragraph(content, style))
            if content == "References":
                in_refs = True
            i += 1
            continue
        if re.match(r"^[-*•]\s+", stripped):
            bullets = []
            while i < len(lines) and re.match(r"^\s*[-*•]\s+", lines[i].strip()):
                bullets.append(Paragraph(inline(re.sub(r"^[-*•]\s+", "", lines[i].strip())), body_style))
                i += 1
            bullet_table = Table([[b] for b in bullets], hAlign="LEFT")
            bullet_table.setStyle(
                TableStyle([
                    ("LEFTPADDING", (0, 0), (-1, -1), 18),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                    ("TOPPADDING", (0, 0), (-1, -1), 1),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ])
            )
            story.append(bullet_table)
            story.append(Spacer(1, 5))
            continue
        if stripped.startswith("```"):
            i += 1
            code_lines = []
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(html.escape(lines[i]))
                i += 1
            if code_lines:
                story.append(Paragraph("<br/>".join(code_lines), caption_style))
            i += 1
            continue
        style = ref_style if (in_refs and re.match(r"^\[\d+\]\s", stripped)) else body_style
        story.append(Paragraph(inline(stripped), style))
        i += 1

    if missing:
        print("WARNING: glyphs not covered by Times New Roman:", " ".join(repr(c) for c in sorted(missing)))

    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=A4,
        leftMargin=1.0 * inch,
        rightMargin=1.0 * inch,
        topMargin=1.0 * inch,
        bottomMargin=1.0 * inch,
        title="The Strait of Hormuz and Global Energy Security",
        author="ResearchAgent",
    )
    doc.build(story)
    print(f"rendered {pdf_path.name} ({pdf_path.stat().st_size // 1024} KB, font={reg})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
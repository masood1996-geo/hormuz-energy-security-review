"""Fetch additional FRED series to extend the Hormuz study.

Adds five series via the FRED API (api.stlouisfed.org, key from settings):
- VIXCLS     CBOE Volatility Index (daily)
- OVXCLS     CBOE Crude Oil ETF Volatility Index (daily)
- GVZCLS     CBOE Gold ETF Volatility Index (daily)
- PNGASJPUSDM Global price of LNG, Asia (monthly, World Bank)
- PNGASEUUSDM Global price of Natural gas, EU (monthly, World Bank)

Writes raw CSVs in the same format as the existing FRED files
(observation_date,SERIESID), records provenance (SHA-256 + retrieved_at),
and appends manifest entries mirroring the pipeline's dataset manifest.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

RUN = Path(__file__).resolve().parents[1]
RAW = RUN / "datasets" / "raw"
MANIFEST = RUN / "datasets" / "manifest.json"

SERIES = [
    {
        "id": "VIXCLS",
        "title": "CBOE Volatility Index: VIX",
        "frequency": "Daily, Close",
        "role": "Global equity risk appetite control",
    },
    {
        "id": "OVXCLS",
        "title": "CBOE Crude Oil ETF Volatility Index",
        "frequency": "Daily, Close",
        "role": "Oil-implied volatility (market-based crisis gauge)",
    },
    {
        "id": "GVZCLS",
        "title": "CBOE Gold ETF Volatility Index",
        "frequency": "Daily, Close",
        "role": "Safe-haven commodity volatility control",
    },
    {
        "id": "PNGASJPUSDM",
        "title": "Global price of LNG, Asia",
        "frequency": "Monthly",
        "role": "Asian LNG price (international gas contagion test)",
    },
    {
        "id": "PNGASEUUSDM",
        "title": "Global price of Natural gas, EU",
        "frequency": "Monthly",
        "role": "European gas price (international gas contagion test)",
    },
]

API_KEY = os.environ.get("FRED_API_KEY")
if not API_KEY:
    settings = Path(__file__).resolve().parents[3] / "researchagent" / "settings_store.py"
    m = None
    if settings.exists():
        import re

        m = re.search(r'"FRED_API_KEY":\s*"([0-9a-f]+)"', settings.read_text(encoding="utf-8"))
    if not m:
        print("FRED_API_KEY not found; cannot fetch.")
        sys.exit(1)
    API_KEY = m.group(1)


def fetch_series(series_id: str) -> list[list[str]]:
    url = (
        "https://api.stlouisfed.org/fred/series/observations?"
        + urllib.parse.urlencode(
            {"series_id": series_id, "api_key": API_KEY, "file_type": "json",
             "sort_order": "asc"}
        )
    )
    with urllib.request.urlopen(url, timeout=60) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    rows = []
    for obs in payload.get("observations", []):
        if obs.get("value") == ".":
            continue
        rows.append([obs["date"], obs["value"]])
    return rows


def main() -> int:
    records = []
    for series in SERIES:
        sid = series["id"]
        rows = fetch_series(sid)
        if len(rows) < 100:
            print(f"{sid}: only {len(rows)} rows; aborting")
            return 1
        out = RAW / f"FRED_{sid}.csv"
        content = "observation_date," + sid + "\n" + "\n".join(f"{d},{v}" for d, v in rows) + "\n"
        out.write_text(content, encoding="utf-8")
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
        retrieved_at = datetime.now(timezone.utc).isoformat()
        first, last = rows[0][0], rows[-1][0]
        print(f"{sid}: {len(rows)} rows, {first}..{last}, sha256={digest[:16]}...")
        records.append(
            {
                "name": f"FRED {series['title']}",
                "source": "FRED",
                "search_url": f"https://fred.stlouisfed.org/series/{sid}",
                "target_folder": "datasets/raw",
                "license": "Federal Reserve Economic Data terms",
                "auto_downloaded": True,
                "local_path": str(out),
                "checksum_sha256": digest,
                "instructions": "Auto-downloaded from the FRED API (series observations endpoint).",
                "citation": f"FRED series {sid}: {series['title']}",
                "download_url": "",
                "data_format": "",
                "quality_score": 100.0,
                "quality_rationale": "auto-downloaded; direct tabular download; FRED source; license stated; citation guidance recorded; validated as tabular data",
                "license_url": "",
                "record_count_hint": f"{len(rows)} rows, 2 columns",
                "validation_status": "valid_tabular",
                "validation_notes": f"retrieved_at={retrieved_at}; role: {series['role']}",
                "retrieved_at": retrieved_at,
            }
        )

    existing = json.loads(MANIFEST.read_text(encoding="utf-8"))
    existing = [r for r in existing if r.get("name") not in {rec["name"] for rec in records}]
    existing.extend(records)
    MANIFEST.write_text(json.dumps(existing, indent=2), encoding="utf-8")
    print(f"manifest updated: {len(existing)} entries")
    return 0


if __name__ == "__main__":
    sys.exit(main())
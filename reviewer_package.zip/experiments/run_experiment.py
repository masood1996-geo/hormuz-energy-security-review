import csv
import json
from pathlib import Path

root = Path.cwd()
raw_dir = root / "datasets" / "raw"
files = [path for path in raw_dir.rglob("*") if path.is_file()] if raw_dir.exists() else []

row_count = 0
series = []
for path in files:
    try:
        if path.suffix.lower() in {".csv", ".tsv"}:
            with path.open(newline="", encoding="utf-8", errors="replace") as handle:
                reader = csv.reader(handle, delimiter="	" if path.suffix.lower() == ".tsv" else ",")
                rows = list(reader)
            data_rows = max(len(rows) - 1, 0)
            row_count += data_rows
            series.append({"file": str(path.relative_to(root)), "rows": data_rows, "columns": rows[0] if rows else []})
        elif path.suffix.lower() in {".json", ".jsonl"}:
            text = path.read_text(encoding="utf-8", errors="replace")
            if path.suffix.lower() == ".jsonl":
                records = [line for line in text.splitlines() if line.strip()]
                row_count += len(records)
                series.append({"file": str(path.relative_to(root)), "rows": len(records), "format": "jsonl"})
            else:
                data = json.loads(text)
                records = data[1] if isinstance(data, list) and len(data) > 1 and isinstance(data[1], list) else data
                count = len(records) if isinstance(records, list) else 1
                row_count += count
                series.append({"file": str(path.relative_to(root)), "rows": count, "format": "json"})
    except Exception as exc:
        series.append({"file": str(path.relative_to(root)), "error": str(exc)})

metrics = {
    "citation_supported_claim_ratio": None,
    "unverified_reference_count": None,
    "measurement_status": "not_measured",
    "illustrative": True,
    "dataset_file_count": len(files),
    "dataset_row_count": row_count,
    "dataset_series": series[:20],
    "note": "local dataset scan completed" if files else "no local datasets found; use the dataset manifest manual links or configured URLs",
}

print(json.dumps(metrics, indent=2))

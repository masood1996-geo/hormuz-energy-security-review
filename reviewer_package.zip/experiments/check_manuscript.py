"""Post-fix manuscript consistency checks for the oc-hormuz-v2 run.

Checks:
1. Every in-text [n] citation in paper_candidate.md lies in 1..59 and is
   present in the ## References section, the evidence matrix, and the bib.
2. references_candidate.bib has exactly 59 entries, one per reference, in the
   same order, with matching DOI/URL.
3. All image references resolve to existing files.
4. No stale identifiers/phrasings remain (hormuz_event_volatility_14d,
   "repurposed from", "retrieved and verified", "adjusted p | 0.0").
5. Narrative p-values match the Results tables for the ex-2026 14-day sample.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

RUN = Path(__file__).resolve().parents[1]
PAPER = RUN / "publication" / "paper_candidate.md"
BIB = RUN / "publication" / "references_candidate.bib"

errors: list[str] = []


def main() -> int:
    text = PAPER.read_text(encoding="utf-8")
    bib_text = BIB.read_text(encoding="utf-8")

    # 1. citation numbering
    body = text.split("## References")[0]
    cited = sorted({int(m) for m in re.findall(r"\[(\d{1,3})\]", body)})
    if cited != list(range(1, 60)):
        missing = [n for n in range(1, 60) if n not in cited]
        errors.append(f"in-text citation set != 1..59; missing={missing}")

    refs_section = text.split("## References")[1]
    ref_ids = [int(m) for m in re.findall(r"^\[(\d{1,3})\] ", refs_section, re.M)]
    if ref_ids != list(range(1, 60)):
        errors.append(f"References list ids != 1..59: {ref_ids}")

    # 2. bib alignment: 59 entries, ordered, DOI/URL matching the References list
    entries = re.findall(r"^@\w+\{(\w+),", bib_text, re.M)
    if len(entries) != 59:
        errors.append(f"bib entries = {len(entries)}, expected 59")
    bib_dois = re.findall(r"doi\s*=\s*\{([^}]+)\}", bib_text)
    bib_urls = re.findall(r"url\s*=\s*\{([^}]+)\}", bib_text)
    ref_dois = re.findall(r"https://doi\.org/(\S+)", refs_section)
    ref_urls = re.findall(r"https?://(?!doi\.org)(\S+)", refs_section)
    if len(bib_dois) + len(bib_urls) != 59:
        errors.append(f"bib identifier count = {len(bib_dois) + len(bib_urls)}, expected 59")
    if len(ref_dois) + len(ref_urls) != 59:
        errors.append(f"References identifier count = {len(ref_dois) + len(ref_urls)}, expected 59")
    # positional DOI/URL match (order alignment)
    def norm(value: str) -> str:
        return value.replace("https://", "").replace("http://", "").strip()

    for i in range(59):
        b = bib_dois[i] if i < len(bib_dois) else f"url:{bib_urls[i - len(bib_dois)]}"
        r = ref_dois[i] if i < len(ref_dois) else f"url:{ref_urls[i - len(ref_dois)]}"
        if norm(b.split(":", 1)[-1]) != norm(r.split(":", 1)[-1]):
            errors.append(f"reference [{i+1}] bib/paper mismatch: bib={b} paper={r}")

    # 3. images resolve
    for img in re.findall(r"!\[[^\]]*\]\(([^)]+)\)", text):
        p = (PAPER.parent / img).resolve()
        if not p.exists():
            errors.append(f"image does not exist: {img}")

    # 4. stale markers
    for stale, pat, flags in [
        ("hormuz_event_volatility_14d", r"hormuz_event_volatility_14d", 0),
        ("no2026_14d", r"hormuz_event_volatility_no2026_14d", 0),
        ("repurposed from", r"repurposed from", re.I),
        ("retrieved and verified", r"retrieved and verified", 0),
        ("adjusted p=0.0 in group tables",
         r"^\| [^\n]*\| (calm vs crisis|2Q26 vs 4Q25|2Q26 vs 3Q25) \|[^\n]*\| 0\.0 \|", re.M),
        ("'differs between'", r"differs between", 0),
        ("data/extracted", r"data/extracted", 0),
        ("relevance_by_source", r"relevance_by_source", 0),
    ]:
        if re.search(pat, text, flags):
            errors.append(f"stale marker found: {stale}")

    # 5. narrative vs tabled ex-2026 p-values
    for value in ["p = 0.201", "p = 0.760", "p = 0.574", "p = 0.256"]:
        if value in text:
            errors.append(f"stale ex-2026 p-value in narrative: {value}")

    if errors:
        print("FAIL")
        for e in errors:
            print(f"  - {e}")
        return 1
    print("PASS: manuscript/bib consistency checks")
    return 0


if __name__ == "__main__":
    sys.exit(main())
"""Extended re-analysis with supplementary market-risk and gas-price series.

Adds to the methodology of experiments/hormuz_reanalysis.py:

1. Daily supplementary volatility series (Designs 1-3, windows 7/14/21/30):
   - VIXCLS  (CBOE Volatility Index)
   - OVXCLS  (CBOE Crude Oil ETF Volatility Index)
   - GVZCLS  (CBOE Gold ETF Volatility Index)
   Volatility is |daily index change| (same convention as the EPU index).
   Bonferroni correction is applied across the three supplementary variables.

2. Monthly international gas event study (2019-01 .. 2026-07):
   - PNGASJPUSDM (World Bank / FRED: LNG price, Asia)
   - PNGASEUUSDM (World Bank / FRED: natural gas price, EU)
   - Henry Hub monthly mean (from DHHNGSP daily) as the US-domestic contrast
   Crisis months = month of each incident plus the two following months.
   Tests whether international gas prices (unlike US Henry Hub) respond to
   Hormuz incidents; isolates the 2026 closure window.

3. Destination-exposure accounting from eia_hormuz_destinations_tidy
   (Asian share of Hormuz crude, 2020-1Q25).

4. Restricted-sample descriptive statistics (2019-2026 analysis window) used
   by Appendix A of the manuscript.

Outputs:
- analysis/reanalysis/findings_extended.json
- analysis/reanalysis/extended_report.md
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

RUN = Path(__file__).resolve().parents[1]
OUT_DIR = RUN / "analysis" / "reanalysis"
OUT_DIR.mkdir(parents=True, exist_ok=True)

from hormuz_reanalysis import (  # noqa: E402
    INCIDENTS,
    build_pre_windows,
    build_windows,
    cluster_robust,
    newey_west,
    welch,
)

SUP_VARS = {
    "abs_vix_change": "VIX",
    "abs_ovx_change": "OVX",
    "abs_gvz_change": "GVZ",
}
GAS_SERIES = [
    ("lng_asia", "LNG Asia (PNGASJPUSDM)", "FRED_PNGASJPUSDM.cleaned.csv"),
    ("gas_eu", "Natural gas EU (PNGASEUUSDM)", "FRED_PNGASEUUSDM.cleaned.csv"),
    ("hh", "Henry Hub (DHHNGSP)", "FRED_DHHNGSP.cleaned.csv"),
]
WINDOWS = [7, 14, 21, 30]
SAMPLES = {
    "full_2019_2026": (pd.Timestamp("2019-01-01"), pd.Timestamp("2026-12-31")),
    "ex2026_2019_2025": (pd.Timestamp("2019-01-01"), pd.Timestamp("2025-12-31")),
}


def load_daily() -> pd.DataFrame:
    df = pd.read_csv(RUN / "datasets" / "raw" / "hormuz_event_windows_fred.csv", parse_dates=["date"])
    for name, sid in [("vix", "VIXCLS"), ("ovx", "OVXCLS"), ("gvz", "GVZCLS")]:
        s = pd.read_csv(RUN / "datasets" / "cleaned" / f"FRED_{sid}.cleaned.csv", parse_dates=["observation_date"])
        s = s.rename(columns={"observation_date": "date", sid: name})
        df = df.merge(s[["date", name]], on="date", how="left")
    df["abs_vix_change"] = df["vix"].diff().abs()
    df["abs_ovx_change"] = df["ovx"].diff().abs()
    df["abs_gvz_change"] = df["gvz"].diff().abs()
    df = df.dropna(subset=list(SUP_VARS)).reset_index(drop=True)
    df["quarter"] = df["date"].dt.to_period("Q").astype(str)
    return df


def run_designs(df: pd.DataFrame) -> dict:
    results: dict[str, dict] = {}
    for sample_name, (t0, t1) in SAMPLES.items():
        sub = df[(df["date"] >= t0) & (df["date"] <= t1)].copy()
        for window in WINDOWS:
            sub["crisis"] = build_windows(sub["date"], window)
            sub["pre"] = build_pre_windows(sub["date"], window) & ~sub["crisis"]
            lag = max(1, round(window * 5 / 7))
            key = f"sup_{sample_name}_w{window}"
            out = {
                "sample": sample_name,
                "window_calendar_days": window,
                "n_total": int(len(sub)),
                "n_crisis": int(sub["crisis"].sum()),
                "n_pre": int(sub["pre"].sum()),
                "variables": {},
            }
            for var in SUP_VARS:
                crisis = sub.loc[sub["crisis"], var].to_numpy()
                pre = sub.loc[sub["pre"], var].to_numpy()
                calm = sub.loc[~sub["crisis"], var].to_numpy()
                w = welch(crisis, pre)
                w1 = welch(crisis, calm)
                nw = newey_west(sub[var].to_numpy(), sub["crisis"].to_numpy(), lag)
                cl = cluster_robust(sub[var].to_numpy(), sub["crisis"].to_numpy(), sub["quarter"].to_numpy())
                out["variables"][var] = {
                    "mean_crisis": float(np.nanmean(crisis)),
                    "mean_pre": float(np.nanmean(pre)),
                    "mean_calm": float(np.nanmean(calm)),
                    "t_pre": float(w["t"]),
                    "p_pre": float(w["p"]),
                    "cohen_d_pre": float(w["cohen_d"]),
                    "t_calm": float(w1["t"]),
                    "p_calm": float(w1["p"]),
                    **nw,
                    **cl,
                }
            results[key] = out

    closure: dict[str, dict] = {}
    sub = df[(df["date"] >= pd.Timestamp("2025-06-01")) & (df["date"] <= pd.Timestamp("2026-12-31"))].copy()
    for window in WINDOWS:
        sub["crisis"] = build_windows(sub["date"], window)
        sub["pre"] = build_pre_windows(sub["date"], window) & ~sub["crisis"]
        lag = max(1, round(window * 5 / 7))
        key = f"sup_closure2026_w{window}"
        out = {
            "sample": "closure_2026",
            "window_calendar_days": window,
            "n_crisis": int(sub["crisis"].sum()),
            "n_pre": int(sub["pre"].sum()),
            "variables": {},
        }
        for var in SUP_VARS:
            crisis = sub.loc[sub["crisis"], var].to_numpy()
            pre = sub.loc[sub["pre"], var].to_numpy()
            w = welch(crisis, pre)
            nw = newey_west(sub[var].to_numpy(), sub["crisis"].to_numpy(), lag)
            cl = cluster_robust(sub[var].to_numpy(), sub["crisis"].to_numpy(), sub["quarter"].to_numpy())
            out["variables"][var] = {
                "mean_crisis": float(np.nanmean(crisis)),
                "mean_pre": float(np.nanmean(pre)),
                "t": float(w["t"]),
                "p": float(w["p"]),
                "cohen_d": float(w["cohen_d"]),
                **nw,
                **cl,
            }
        closure[key] = out
    return {"design1_design2": results, "closure": closure}


def monthly_gas_study() -> dict:
    def load_monthly(name: str, fname: str) -> pd.DataFrame:
        df = pd.read_csv(RUN / "datasets" / "cleaned" / fname, parse_dates=["observation_date"])
        df = df.rename(columns={"observation_date": "month", name: "price"})
        df["month"] = df["month"].dt.to_period("M").astype(str)
        return df.set_index("month")["price"]

    hh = load_monthly("DHHNGSP", "FRED_DHHNGSP.cleaned.csv")
    lng = load_monthly("PNGASJPUSDM", "FRED_PNGASJPUSDM.cleaned.csv")
    eu = load_monthly("PNGASEUUSDM", "FRED_PNGASEUUSDM.cleaned.csv")
    months = pd.period_range("2019-01", "2026-07", freq="M").astype(str)
    hh_idx = pd.to_datetime(hh.index)
    hh_m = hh.groupby(hh_idx.to_period("M").astype(str)).mean()

    data = pd.DataFrame({"lng_asia": lng, "gas_eu": eu, "hh": hh_m})
    data = data.loc[months].astype(float)
    pct = data.pct_change() * 100
    pct = pct.dropna()

    incident_months = []
    for d, _l, _j in INCIDENTS:
        p = pd.Timestamp(d).to_period("M")
        incident_months += [str(p + i) for i in range(3)]
    crisis_set = set(incident_months)
    crisis = pct.index.isin(crisis_set)

    out: dict[str, dict] = {}
    for name, label, _f in GAS_SERIES:
        in_full = pct.index <= "2026-07"
        in_ex = pct.index <= "2025-12"
        crisis_full = crisis[in_full]
        crisis_ex = crisis[in_ex]
        full = pct.loc[in_full, name]
        ex = pct.loc[in_ex, name]
        abs_full = full.abs()
        abs_ex = ex.abs()
        res_full = welch(abs_full[crisis_full].to_numpy(), abs_full[~crisis_full].to_numpy())
        res_ex = welch(abs_ex[crisis_ex].to_numpy(), abs_ex[~crisis_ex].to_numpy())
        out[name] = {
            "label": label,
            "n_crisis_full": int(crisis_full.sum()),
            "n_other_full": int((~crisis_full).sum()),
            "n_crisis_ex": int(crisis_ex.sum()),
            "n_other_ex": int((~crisis_ex).sum()),
            "mean_abs_crisis_full": float(abs_full[crisis_full].mean()),
            "mean_abs_other_full": float(abs_full[~crisis_full].mean()),
            "mean_signed_crisis_full": float(full[crisis_full].mean()),
            "mean_signed_other_full": float(full[~crisis_full].mean()),
            "welch_t_full": float(res_full["t"]),
            "welch_p_full": float(res_full["p"]),
            "welch_t_ex": float(res_ex["t"]),
            "welch_p_ex": float(res_ex["p"]),
        }

    pre_closure = data.loc["2025-11":"2026-01"].mean()
    post_closure = data.loc["2026-03":"2026-05"].mean()
    closure_chg = (post_closure / pre_closure - 1) * 100
    jan26 = data.loc["2026-01"]
    jul26 = data.loc["2026-07"]
    spring25 = data.loc["2025-03":"2025-05"].mean()
    spring26 = data.loc["2026-03":"2026-05"].mean()
    yoy_spring = (spring26 / spring25 - 1) * 100
    yoy_monthly = {}
    for m in ["2026-03", "2026-04", "2026-05", "2026-06", "2026-07"]:
        prev = f"{int(m[:4]) - 1}-{m[5:]}"
        yoy_monthly[m] = ((data.loc[m] / data.loc[prev] - 1) * 100).to_dict()
    out["_closure"] = {
        "pre_closure_mean": pre_closure.to_dict(),
        "post_closure_mean": post_closure.to_dict(),
        "post_vs_pre_pct": closure_chg.to_dict(),
        "jan2026": jan26.to_dict(),
        "jul2026": jul26.to_dict(),
        "jan_to_jul_pct": ((jul26 / jan26 - 1) * 100).to_dict(),
        "spring_2025_mean": spring25.to_dict(),
        "spring_2026_mean": spring26.to_dict(),
        "yoy_spring_pct": yoy_spring.to_dict(),
        "yoy_monthly_pct": yoy_monthly,
    }
    out["_incident_months"] = sorted(crisis_set)
    out["_months_sample"] = {"start": "2019-01", "end": "2026-07", "n": len(pct)}
    return out


def destination_shares() -> dict:
    df = pd.read_csv(RUN / "datasets" / "raw" / "eia_hormuz_destinations_tidy.csv")
    asia = ["China", "India", "South Korea", "Japan", "Other Asia"]
    rows = []
    for year, g in df.groupby("year"):
        total = g["million_bpd"].sum()
        share = g[g["destination_country"].isin(asia)]["million_bpd"].sum() / total * 100
        rows.append({"year": year, "crude_mbpd": float(total),
                     "asia_mbpd": float(g[g["destination_country"].isin(asia)]["million_bpd"].sum()),
                     "asia_share_pct": float(share)})
    return {"by_year": rows,
            "asia_share_1q25_pct": float([r for r in rows if str(r["year"]) == "1Q25"][0]["asia_share_pct"]),
            "asia_share_2024_pct": float([r for r in rows if str(r["year"]) == "2024"][0]["asia_share_pct"])}


def restricted_descriptives() -> dict:
    df = pd.read_csv(RUN / "datasets" / "raw" / "hormuz_event_windows_fred.csv", parse_dates=["date"])
    for name, sid in [("vix", "VIXCLS"), ("ovx", "OVXCLS"), ("gvz", "GVZCLS")]:
        s = pd.read_csv(RUN / "datasets" / "cleaned" / f"FRED_{sid}.cleaned.csv", parse_dates=["observation_date"])
        df = df.merge(s.rename(columns={"observation_date": "date", sid: name})[["date", name]], on="date", how="left")
    df["vix_d"] = df["vix"].diff()
    df["ovx_d"] = df["ovx"].diff()
    df["gvz_d"] = df["gvz"].diff()
    sub = df[(df["date"] >= pd.Timestamp("2019-01-01")) & (df["date"] <= pd.Timestamp("2026-12-31"))].copy()
    series = {
        "brent_return_pct": ("Brent daily returns (%)", sub["brent_return_pct"]),
        "wti_return_pct": ("WTI daily returns (%)", sub["wti_return_pct"]),
        "hh_return_pct": ("Henry Hub daily returns (%)", sub["hh_return_pct"]),
        "epu_change": ("EPU daily change (points)", sub["epu_change"]),
        "vix_d": ("VIX daily change (points)", sub["vix_d"]),
        "ovx_d": ("OVX daily change (points)", sub["ovx_d"]),
        "gvz_d": ("GVZ daily change (points)", sub["gvz_d"]),
    }
    stats_out = {}
    for key, (label, s) in series.items():
        s = s.dropna()
        stats_out[key] = {
            "label": label,
            "n": int(len(s)),
            "mean": float(s.mean()),
            "sd": float(s.std(ddof=1)),
            "min": float(s.min()),
            "median": float(s.median()),
            "max": float(s.max()),
        }
    corr_vars = {"brent_return_pct": "Brent", "wti_return_pct": "WTI", "hh_return_pct": "Henry Hub", "epu_change": "EPU"}
    corr = {}
    cdf = sub[list(corr_vars)].dropna()
    for a in corr_vars:
        for b in corr_vars:
            if a < b:
                r, p = stats.pearsonr(cdf[a], cdf[b])
                corr[f"{corr_vars[a]} vs {corr_vars[b]}"] = {"r": float(r), "p": float(p)}
    return {
        "n_trading_days": int(len(sub)),
        "first_date": str(sub["date"].min().date()),
        "last_date": str(sub["date"].max().date()),
        "series": stats_out,
        "correlations": corr,
    }


def main() -> int:
    df = load_daily()
    designs = run_designs(df)
    gas = monthly_gas_study()
    dest = destination_shares()
    desc = restricted_descriptives()

    payload = {"supplementary_daily": designs, "monthly_gas": gas,
               "destinations": dest, "restricted_descriptives": desc}
    (OUT_DIR / "findings_extended.json").write_text(
        json.dumps(payload, indent=2, default=str), encoding="utf-8")

    L: list[str] = []
    L.append("# Extended Re-Analysis: Supplementary Risk and Gas-Price Series")
    L.append("")
    L.append(f"Analysis window: {desc['first_date']} .. {desc['last_date']} "
             f"({desc['n_trading_days']} trading days).")
    L.append("")

    L.append("## 1. Supplementary daily volatility series (Design 2: pre-incident control)")
    L.append("")
    L.append("Volatility = absolute daily index change (points). Bonferroni across the three "
             "supplementary variables. NW = Newey-West HAC (lag = window in business days); "
             "Clust = calendar-quarter clusters.")
    L.append("")
    L.append("| Key | Window | N crisis | N pre | Variable | Crisis mean | Pre mean | Welch t | p raw | p Bonf | NW t | NW p | Clust t | Clust p | Cohen's d |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for key, r in designs["design1_design2"].items():
        if r["window_calendar_days"] not in (14, 30):
            continue
        for var in SUP_VARS:
            v = r["variables"][var]
            pb = min(1.0, 3 * v["p_pre"])
            L.append(
                f"| {key} | {r['window_calendar_days']} | {r['n_crisis']} | {r['n_pre']} | {SUP_VARS[var]} | "
                f"{v['mean_crisis']:.2f} | {v['mean_pre']:.2f} | {v['t_pre']:.2f} | {v['p_pre']:.3f} | {pb:.3f} | "
                f"{v['t_nw']:.2f} | {v['p_nw']:.3f} | {v['t_cluster']:.2f} | {v['p_cluster']:.3f} | {v['cohen_d_pre']:.2f} |"
            )
        L.append("")
    L.append("## 2. 2026 closure in isolation (Design 3) - supplementary series")
    L.append("")
    L.append("| Window | Variable | Post-closure mean | Pre-closure mean | Welch t | p raw | p Bonf | NW p | Clust p | Cohen's d |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    for key, r in designs["closure"].items():
        for var in SUP_VARS:
            v = r["variables"][var]
            pb = min(1.0, 3 * v["p"])
            L.append(
                f"| {r['window_calendar_days']}d | {SUP_VARS[var]} | {v['mean_crisis']:.2f} | {v['mean_pre']:.2f} | "
                f"{v['t']:.2f} | {v['p']:.3f} | {pb:.3f} | {v['p_nw']:.3f} | {v['p_cluster']:.3f} | {v['cohen_d']:.2f} |"
            )
        L.append("")
    L.append("## 3. Monthly international gas event study")
    L.append("")
    L.append(f"Sample: {gas['_months_sample']['start']} .. {gas['_months_sample']['end']} "
             f"(90 monthly percentage changes; 91 price observations, the first month being lost to "
             "differencing). Crisis months = incident month plus the two following months; union "
             "across the eleven incidents. Welch test on absolute monthly changes.")
    L.append("")
    L.append("| Series | Crisis months (full) | Other months (full) | Mean abs change crisis | Mean abs change other | Signed mean crisis | Signed mean other | Welch t (full) | p (full) | Welch t (ex-2026) | p (ex-2026) |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for name, r in gas.items():
        if name.startswith("_"):
            continue
        L.append(
            f"| {r['label']} | {r['n_crisis_full']} | {r['n_other_full']} | {r['mean_abs_crisis_full']:.2f}% | "
            f"{r['mean_abs_other_full']:.2f}% | {r['mean_signed_crisis_full']:.2f}% | {r['mean_signed_other_full']:.2f}% | "
            f"{r['welch_t_full']:.2f} | {r['welch_p_full']:.3f} | {r['welch_t_ex']:.2f} | {r['welch_p_ex']:.3f} |"
        )
    L.append("")
    L.append("## 4. 2026 closure: international gas price levels")
    L.append("")
    c = gas["_closure"]
    L.append("| Series | Pre-closure mean (Nov25-Jan26) | Post-closure mean (Mar-May26) | Post vs pre | Jan-2026 | Jul-2026 | Jan to Jul |")
    L.append("|---|---|---|---|---|---|---|")
    for name, label in [("lng_asia", "LNG Asia"), ("gas_eu", "Natural gas EU"), ("hh", "Henry Hub")]:
        L.append(
            f"| {label} | {c['pre_closure_mean'][name]:.2f} | {c['post_closure_mean'][name]:.2f} | "
            f"{c['post_vs_pre_pct'][name]:+.1f}% | {c['jan2026'][name]:.2f} | {c['jul2026'][name]:.2f} | "
            f"{c['jan_to_jul_pct'][name]:+.1f}% |"
        )
    L.append("")
    L.append("| Series | Spring 2025 mean (Mar-May25) | Spring 2026 mean (Mar-May26) | Same-season YoY |")
    L.append("|---|---|---|---|")
    for name, label in [("lng_asia", "LNG Asia"), ("gas_eu", "Natural gas EU"), ("hh", "Henry Hub")]:
        L.append(
            f"| {label} | {c['spring_2025_mean'][name]:.2f} | {c['spring_2026_mean'][name]:.2f} | "
            f"{c['yoy_spring_pct'][name]:+.1f}% |"
        )
    L.append("")
    L.append("| Month | LNG Asia YoY | Natural gas EU YoY | Henry Hub YoY |")
    L.append("|---|---|---|---|")
    for m, d in c["yoy_monthly_pct"].items():
        L.append(f"| {m} | {d['lng_asia']:+.1f}% | {d['gas_eu']:+.1f}% | {d['hh']:+.1f}% |")
    L.append("")
    L.append("## 5. Destination exposure of Hormuz crude (EIA/Vortexa)")
    L.append("")
    L.append("| Year | Crude transit (mb/d) | To Asia (mb/d) | Asian share (%) |")
    L.append("|---|---|---|---|")
    for row in dest["by_year"]:
        L.append(f"| {row['year']} | {row['crude_mbpd']:.2f} | {row['asia_mbpd']:.2f} | {row['asia_share_pct']:.1f} |")
    L.append("")
    L.append("## 6. Restricted-window descriptive statistics (Appendix A inputs)")
    L.append("")
    L.append("| Variable | n | Mean | SD | Min | Median | Max |")
    L.append("|---|---|---|---|---|---|---|")
    for key, s in desc["series"].items():
        L.append(f"| {s['label']} | {s['n']} | {s['mean']:.4f} | {s['sd']:.4f} | {s['min']:.4f} | {s['median']:.4f} | {s['max']:.4f} |")
    L.append("")
    L.append("### Pairwise Pearson correlations (restricted window)")
    L.append("")
    L.append("| Pair | r | p |")
    L.append("|---|---|---|")
    for pair, v in desc["correlations"].items():
        L.append(f"| {pair} | {v['r']:.3f} | {v['p']:.4f} |")
    L.append("")
    report = "\n".join(L)
    (OUT_DIR / "extended_report.md").write_text(report, encoding="utf-8")
    print(report)
    return 0


if __name__ == "__main__":
    sys.exit(main())
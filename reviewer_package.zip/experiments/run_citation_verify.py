"""Re-run the CITATION_VERIFY stage logic for the oc-hormuz-v2 candidate.

Mirrors researchagent/pipeline.py `_stage_citation_verify`: resolves every
locator in references_candidate.bib over the network (Gate 2 existence),
checks in-text citation usage (Gate 3), applies the citation_min_pass_ratio
(0.7) with hard rejections for fake/placeholder locators, and writes
verification/verification_report.json.
"""
from __future__ import annotations

import sys
from pathlib import Path

RESEARCH = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(RESEARCH))

from researchagent.quality import detect_publication_blockers, verify_bibtex  # noqa: E402

RUN = Path(__file__).resolve().parents[1]
BIB = RUN / "publication" / "references_candidate.bib"
PAPER = RUN / "publication" / "paper_candidate.md"


def main() -> int:
    verification = verify_bibtex(
        BIB,
        check_network=True,
        config=None,
        paper_path=PAPER,
        require_citation_usage=True,
    )
    import json

    out = RUN / "verification" / "verification_report.json"
    out.write_text(json.dumps(verification.to_dict(), indent=2), encoding="utf-8")
    print("\n".join(verification.notes))
    print(f"PASSED: {verification.passed}")

    blockers = detect_publication_blockers(
        PAPER.read_text(encoding="utf-8"),
        bib_path=BIB,
        expected_paper_count=59,
        min_words=0,
    )
    print(f"publication blockers: {blockers if blockers else 'none'}")
    if blockers:
        (RUN / "verification" / "publication_blockers.json").write_text(
            json.dumps({"blockers": blockers}, indent=2), encoding="utf-8"
        )
    return 0 if verification.passed and not blockers else 1


if __name__ == "__main__":
    sys.exit(main())
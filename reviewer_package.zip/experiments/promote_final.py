"""Promote the verified manuscript to final/ and seal the artifacts.

Mirrors the pipeline's EXPORT_PUBLISH/CITATION_VERIFY promotion logic:
- final/paper_final.md  <- fixed, verified candidate
- final/references.bib  <- verified bibliography (all 59 locators resolved)
- final/paper_final.pdf <- rendered with the reportlab fallback
- final/figures/*.png   <- publication figures
- manifest: sealed_artifacts (relative path -> SHA-256) + sealed_at
"""
from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

RESEARCH = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(RESEARCH))

from researchagent.export_bundle import _render_pdf_fallback  # noqa: E402
from researchagent.provenance import (  # noqa: E402
    load_manifest,
    seal_artifacts,
    write_manifest,
)

RUN = Path(__file__).resolve().parents[1]
FINAL = RUN / "final"
FIGURES = FINAL / "figures"


def main() -> int:
    FINAL.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)

    shutil.copy2(RUN / "publication" / "paper_candidate.md", FINAL / "paper_final.md")
    shutil.copy2(RUN / "publication" / "references_candidate.bib", FINAL / "references.bib")
    for fig in (RUN / "publication" / "figures").glob("*.png"):
        shutil.copy2(fig, FIGURES / fig.name)

    render = _render_pdf_fallback(FINAL / "paper_final.md", FINAL / "paper_final.pdf", run_root=FINAL)
    if not render.get("passed"):
        print("pdf render failed:", render)
        return 1

    sealed = seal_artifacts(RUN, [FINAL / "paper_final.md", FINAL / "references.bib",
                                  FINAL / "paper_final.pdf", *sorted(FIGURES.glob("*.png"))])
    manifest = load_manifest(RUN)
    manifest["sealed_artifacts"] = sealed
    manifest["sealed_at"] = datetime.now(timezone.utc).isoformat()
    write_manifest(RUN, manifest)

    provenance = f"""# Provenance

- Date: {datetime.now(timezone.utc).date().isoformat()}
- Run ID: oc-hormuz-v2
- Topic: The Strait of Hormuz and Global Energy Security: Geopolitical Tensions, Maritime Trade, and the Risk of Supply Chain Disruption
- Mode: live
- Manuscript: final/paper_final.md (fixed candidate; methodological re-analysis integrated)
- Bibliography: final/references.bib (59 entries; all locators resolved over the network on 2026-08-23)
- Citation verification: 59/59 passed (ratio 1.00, min 0.70; no hard rejections)
- Re-analysis: experiments/hormuz_reanalysis.py -> analysis/reanalysis/findings_reanalysis.json
- Dataset provenance: checksums and findings hashes refreshed for all dataset records on 2026-08-23
  (datasets regenerated after the original analysis)
- Sealed artifacts: relative path -> SHA-256 recorded in run_manifest.json (sealed_at)
- Open items: quality-gate re-review of the revised manuscript (human decision); the earlier
  peer-review grade (5/10, 'revise') was produced against the pre-revision manuscript.
"""
    (RUN / "verification" / "provenance.md").write_text(provenance, encoding="utf-8")

    print("sealed artifacts:")
    for rel, h in sealed.items():
        print(f"  {rel}  {h[:16]}...")
    return 0


if __name__ == "__main__":
    sys.exit(main())
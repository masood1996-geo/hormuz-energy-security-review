"""Verify the regenerated artifacts: latex equations and pdf images."""
import re
from pathlib import Path

t = Path("final/paper_final.tex").read_text(encoding="utf-8")
eqs = re.findall(r"\\begin\{equation\}(.*?)\\end\{equation\}", t, re.S)
print("latex equations:", len(eqs))
for e in eqs:
    print("  ", e.strip()[:90])
if eqs and "ref" not in t:
    print("note: no \\label/\\ref in tex (plain latex artifact)")

b = Path("final/paper_final.pdf").read_bytes()
print("pdf pages:", b.count(b"/Type /Page") - b.count(b"/Type /Pages"),
      "| size:", len(b) // 1024, "KB")
md = Path("final/paper_final.md").read_text(encoding="utf-8")
print("Eq refs in text:", len(re.findall(r"Eq\. \(\d\)", md)))
print("display equations:", len(re.findall(r"^\$\$.*\$\$", md, re.M)))
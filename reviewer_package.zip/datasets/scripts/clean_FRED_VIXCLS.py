﻿import csv
import json
import sys
from pathlib import Path


SRC = Path('C:\\Users\\melay\\Downloads\\Rebound effect of Water_QM Project\\Research\\projects\\gem-hormuz\\datasets\\raw\\FRED_VIXCLS.csv')
DEST = Path('C:\\Users\\melay\\Downloads\\Rebound effect of Water_QM Project\\Research\\projects\\gem-hormuz\\datasets\\cleaned\\FRED_VIXCLS.cleaned.csv')
DEST.parent.mkdir(parents=True, exist_ok=True)
suffix = SRC.suffix.lower()
report = {"source": str(SRC), "destination": str(DEST), "rows_in": 0, "rows_out": 0, "actions": []}

if suffix in {".csv", ".tsv"}:
    delim = "\t" if suffix == ".tsv" else ","
    with SRC.open(newline="", encoding="utf-8", errors="replace") as src_handle:
        reader = csv.reader(src_handle, delimiter=delim)
        try:
            header = next(reader)
        except StopIteration:
            header = []
        rows = []
        for row in reader:
            report["rows_in"] += 1
            normalized = [(cell or "").strip() for cell in row]
            if any(cell for cell in normalized):
                rows.append(normalized)
    seen = set()
    deduped = []
    for row in rows:
        key = tuple(row)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    if len(deduped) != len(rows):
        report["actions"].append(f"removed {len(rows) - len(deduped)} duplicate rows")
    with DEST.open("w", newline="", encoding="utf-8") as out_handle:
        writer = csv.writer(out_handle, delimiter=",")
        writer.writerow(header)
        writer.writerows(deduped)
        report["rows_out"] = len(deduped)
    report["actions"].append("trimmed whitespace, dropped empty rows, deduplicated, normalized to CSV")
elif suffix in {".json", ".jsonl"}:
    if suffix == ".json":
        try:
            data = json.loads(SRC.read_text(encoding="utf-8", errors="replace"))
        except json.JSONDecodeError:
            data = []
        if isinstance(data, list) and len(data) == 2 and isinstance(data[1], list) and isinstance(data[0], dict):
            records = [item for item in data[1] if isinstance(item, dict)]
        elif isinstance(data, list):
            records = [item for item in data if isinstance(item, dict)]
        elif isinstance(data, dict):
            records = next((v for v in (data.get("data"), data.get("records"), data.get("results")) if isinstance(v, list)), [])
        else:
            records = []
    else:
        records = []
        for line in SRC.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(row, dict):
                records.append(row)
    report["rows_in"] = len(records)
    seen_keys = set()
    deduped = []
    for record in records:
        try:
            key = json.dumps(record, sort_keys=True, default=str)
        except TypeError:
            continue
        if key in seen_keys:
            continue
        seen_keys.add(key)
        deduped.append(record)
    DEST.write_text(json.dumps(deduped, indent=2, default=str), encoding="utf-8")
    report["rows_out"] = len(deduped)
    report["actions"].append("parsed records, deduplicated, normalized to JSON")
else:
    DEST.write_bytes(SRC.read_bytes())
    report["actions"].append(f"unknown format {suffix}; copied through unchanged")

print(json.dumps(report))




# Hormuz Crisis-Window Volatility: Methodological Re-Analysis

## Incident list and justification

| Date | Incident | Justification |
|---|---|---|
| 2019-05-12 | Fujairah anchorage sabotage | Four ships damaged near the UAE port of Fujairah, on the approaches to the Strait of Hormuz; attributed to Iran-aligned actors. |
| 2019-06-13 | Gulf of Oman tanker attacks | Two tankers (Kokuka Courageous, Front Altair) attacked in the Gulf of Oman on the main approach route to Hormuz. |
| 2019-07-19 | Stena Impero seizure | Iran seized the tanker Stena Impero in the Strait of Hormuz, a direct disruption of Hormuz transit. |
| 2020-01-03 | Soleimani strike | U.S. killed Qassem Soleimani; Iran publicly threatened closure of the Strait of Hormuz. |
| 2020-01-08 | Iranian missile strikes | Iran struck U.S. bases in Iraq in retaliation; Gulf war-risk repriced in oil markets. |
| 2021-07-29 | Mercer Street attack | Israel-linked tanker Mercer Street attacked with a drone off Oman, on the Hormuz approach route. |
| 2023-10-07 | Regional escalation | Start of the Israel-Hamas war; broad repricing of Middle East and Gulf supply risk (included as a regional-risk incident with justification). |
| 2024-04-13 | Iran-Israel exchange | Iran launched its first direct attack on Israel; Gulf escalation risk. |
| 2024-10-01 | Iran missile attack on Israel | Iranian ballistic-missile attack on Israel; Gulf escalation risk. |
| 2025-06-13 | Israel-Iran 12-day war | Direct Israel-Iran war; Gulf and Hormuz supply risk at its highest since 2020. |
| 2026-02-28 | Effective closure of the Strait of Hormuz | War onset; effective closure of the strait disrupted ~20 mb/d of crude transit (EIA Global Energy Security Data). |

## Design

- Design 1 (corrected baseline): sample restricted to 2019-2026 (or 2019-2025),
  crisis days = all business days within W calendar days after an incident
  (2026 closure coded as a 2026-02-28 incident with the same windows);
  control = all remaining days in the sample.
- Design 2 (pre-window control): crisis days compared against the [-2W, -W)
  calendar-day window immediately preceding each incident.
- Design 3 (2026 closure isolated): post-closure windows vs pre-closure windows,
  using only days near the 2026-02-28 closure.

Inference: Welch t-test (as in the original paper), OLS with Newey-West HAC
standard errors (lag = window length in business days), and OLS with
quarter-clustered standard errors. Bonferroni-adjusted p-values are over the
four variables within each specification.

## Design 1: corrected full-sample baseline

| Key | Sample | Window (days) | N total | N crisis | N calm |
|---|---|---|---|---|---|
| full_2019_2026_w7 | full_2019_2026 | 7 | 1875 | 57 | 1818 |
| full_2019_2026_w14 | full_2019_2026 | 14 | 1875 | 105 | 1770 |
| full_2019_2026_w21 | full_2019_2026 | 21 | 1875 | 152 | 1723 |
| full_2019_2026_w30 | full_2019_2026 | 30 | 1875 | 211 | 1664 |
| ex2026_2019_2025_w7 | ex2026_2019_2025 | 7 | 1721 | 52 | 1669 |
| ex2026_2019_2025_w14 | ex2026_2019_2025 | 14 | 1721 | 95 | 1626 |
| ex2026_2019_2025_w21 | ex2026_2019_2025 | 21 | 1721 | 137 | 1584 |
| ex2026_2019_2025_w30 | ex2026_2019_2025 | 30 | 1721 | 190 | 1531 |

### full_2019_2026_w7 (full_2019_2026, 7-day windows)

| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.4726 | 2.0240 | 1.484 | 0.1430 | 0.5720 | 0.4486 | 1.054 | 0.2922 | 0.834 | 0.4046 | 0.177 |
| WTI | 2.2112 | 2.2769 | -0.173 | 0.8630 | 1.0000 | -0.0656 | -0.134 | 0.8931 | -0.104 | 0.9173 | -0.011 |
| Henry Hub | 3.1960 | 5.2049 | -3.657 | 0.0004 | 0.0016 | -2.0089 | -2.773 | 0.0056 | -2.415 | 0.0158 | -0.221 |
| EPU | 54.1019 | 66.5764 | -1.603 | 0.1140 | 0.4558 | -12.4745 | -1.140 | 0.2542 | -1.112 | 0.2662 | -0.187 |

### full_2019_2026_w14 (full_2019_2026, 14-day windows)

| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.2678 | 2.0239 | 1.055 | 0.2935 | 1.0000 | 0.2439 | 0.676 | 0.4991 | 0.524 | 0.6004 | 0.095 |
| WTI | 2.2479 | 2.2765 | -0.089 | 0.9290 | 1.0000 | -0.0286 | -0.055 | 0.9565 | -0.044 | 0.9651 | -0.005 |
| Henry Hub | 3.2540 | 5.2559 | -4.490 | 0.0000 | 0.0000 | -2.0019 | -2.989 | 0.0028 | -2.813 | 0.0050 | -0.218 |
| EPU | 60.0493 | 66.5619 | -1.031 | 0.3047 | 1.0000 | -6.5125 | -0.701 | 0.4832 | -0.682 | 0.4955 | -0.095 |

### full_2019_2026_w21 (full_2019_2026, 21-day windows)

| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.3368 | 2.0112 | 1.715 | 0.0879 | 0.3516 | 0.3256 | 0.922 | 0.3568 | 0.706 | 0.4800 | 0.128 |
| WTI | 2.1568 | 2.2853 | -0.469 | 0.6394 | 1.0000 | -0.1285 | -0.271 | 0.7863 | -0.227 | 0.8201 | -0.021 |
| Henry Hub | 3.3033 | 5.3062 | -4.863 | 0.0000 | 0.0000 | -2.0029 | -3.172 | 0.0015 | -3.138 | 0.0017 | -0.216 |
| EPU | 59.5753 | 66.7813 | -1.295 | 0.1968 | 0.7872 | -7.2061 | -0.815 | 0.4151 | -0.850 | 0.3957 | -0.103 |

### full_2019_2026_w30 (full_2019_2026, 30-day windows)

| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.2847 | 2.0063 | 1.681 | 0.0938 | 0.3753 | 0.2784 | 0.792 | 0.4286 | 0.632 | 0.5272 | 0.109 |
| WTI | 2.1211 | 2.2944 | -0.678 | 0.4982 | 1.0000 | -0.1733 | -0.354 | 0.7236 | -0.300 | 0.7639 | -0.028 |
| Henry Hub | 3.2627 | 5.3823 | -5.399 | 0.0000 | 0.0000 | -2.1196 | -3.268 | 0.0011 | -3.170 | 0.0015 | -0.225 |
| EPU | 62.5442 | 66.6604 | -0.810 | 0.4186 | 1.0000 | -4.1162 | -0.401 | 0.6882 | -0.408 | 0.6836 | -0.057 |

### ex2026_2019_2025_w7 (ex2026_2019_2025, 7-day windows)

| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.0396 | 1.9179 | 0.514 | 0.6090 | 1.0000 | 0.1217 | 0.473 | 0.6365 | 0.344 | 0.7306 | 0.053 |
| WTI | 1.8134 | 2.2270 | -1.268 | 0.2067 | 0.8269 | -0.4136 | -1.041 | 0.2981 | -0.773 | 0.4398 | -0.068 |
| Henry Hub | 3.1371 | 4.9941 | -3.314 | 0.0014 | 0.0054 | -1.8570 | -2.501 | 0.0125 | -2.166 | 0.0305 | -0.231 |
| EPU | 44.3971 | 64.2098 | -3.207 | 0.0021 | 0.0086 | -19.8127 | -2.641 | 0.0083 | -2.641 | 0.0083 | -0.329 |

### ex2026_2019_2025_w14 (ex2026_2019_2025, 14-day windows)

| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 1.9199 | 1.9217 | -0.010 | 0.9922 | 1.0000 | -0.0018 | -0.007 | 0.9942 | -0.005 | 0.9958 | -0.001 |
| WTI | 1.8064 | 2.2383 | -1.474 | 0.1414 | 0.5656 | -0.4320 | -1.052 | 0.2931 | -0.822 | 0.4112 | -0.070 |
| Henry Hub | 3.2035 | 5.0393 | -4.086 | 0.0001 | 0.0002 | -1.8358 | -2.769 | 0.0057 | -2.588 | 0.0097 | -0.226 |
| EPU | 53.1369 | 64.2231 | -1.849 | 0.0671 | 0.2682 | -11.0861 | -1.375 | 0.1692 | -1.372 | 0.1703 | -0.170 |

### ex2026_2019_2025_w21 (ex2026_2019_2025, 21-day windows)

| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 1.9599 | 1.9183 | 0.271 | 0.7870 | 1.0000 | 0.0417 | 0.188 | 0.8508 | 0.142 | 0.8869 | 0.018 |
| WTI | 1.8438 | 2.2466 | -1.513 | 0.1307 | 0.5230 | -0.4027 | -0.952 | 0.3414 | -0.782 | 0.4342 | -0.064 |
| Henry Hub | 3.2628 | 5.0829 | -4.449 | 0.0000 | 0.0000 | -1.8201 | -3.047 | 0.0023 | -3.008 | 0.0027 | -0.222 |
| EPU | 53.9989 | 64.4425 | -1.898 | 0.0593 | 0.2373 | -10.4436 | -1.254 | 0.2100 | -1.398 | 0.1624 | -0.154 |

### ex2026_2019_2025_w30 (ex2026_2019_2025, 30-day windows)

| Variable | Crisis mean | Calm mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 1.9292 | 1.9206 | 0.063 | 0.9497 | 1.0000 | 0.0086 | 0.038 | 0.9698 | 0.031 | 0.9752 | 0.004 |
| WTI | 1.8050 | 2.2653 | -1.798 | 0.0724 | 0.2896 | -0.4603 | -1.006 | 0.3147 | -0.884 | 0.3766 | -0.073 |
| Henry Hub | 3.2733 | 5.1446 | -4.884 | 0.0000 | 0.0000 | -1.8713 | -3.113 | 0.0019 | -3.140 | 0.0017 | -0.225 |
| EPU | 55.8329 | 64.5764 | -1.744 | 0.0824 | 0.3297 | -8.7435 | -0.893 | 0.3719 | -1.038 | 0.2993 | -0.126 |

## Design 2: pre-window control (crisis vs [-2W, -W) pre-window)

| Key | Sample | Window (days) | N crisis | N pre |
|---|---|---|---|---|
| prepost_full_2019_2026_w7 | full_2019_2026 | 7 | 57 | 49 |
| prepost_full_2019_2026_w14 | full_2019_2026 | 14 | 105 | 85 |
| prepost_full_2019_2026_w21 | full_2019_2026 | 21 | 152 | 125 |
| prepost_full_2019_2026_w30 | full_2019_2026 | 30 | 211 | 184 |
| prepost_ex2026_2019_2025_w7 | ex2026_2019_2025 | 7 | 52 | 45 |
| prepost_ex2026_2019_2025_w14 | ex2026_2019_2025 | 14 | 95 | 75 |
| prepost_ex2026_2019_2025_w21 | ex2026_2019_2025 | 21 | 137 | 111 |
| prepost_ex2026_2019_2025_w30 | ex2026_2019_2025 | 30 | 190 | 167 |

### prepost_full_2019_2026_w7 (full_2019_2026, 7-day windows)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.4726 | 1.6051 | 2.413 | 0.0177 | 0.0709 | 0.8675 | 1.803 | 0.0743 | 1.400 | 0.1645 | 0.463 |
| WTI | 2.2112 | 1.5391 | 1.678 | 0.0966 | 0.3866 | 0.6721 | 1.369 | 0.1741 | 1.253 | 0.2132 | 0.322 |
| Henry Hub | 3.1960 | 3.6348 | -0.606 | 0.5458 | 1.0000 | -0.4388 | -0.478 | 0.6336 | -0.554 | 0.5809 | -0.119 |
| EPU | 54.1019 | 44.3004 | 0.988 | 0.3255 | 1.0000 | 9.8015 | 0.897 | 0.3717 | 1.097 | 0.2752 | 0.191 |

### prepost_full_2019_2026_w14 (full_2019_2026, 14-day windows)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.2678 | 1.4883 | 2.978 | 0.0033 | 0.0133 | 0.7795 | 1.966 | 0.0508 | 1.765 | 0.0792 | 0.423 |
| WTI | 2.2479 | 1.3486 | 3.217 | 0.0016 | 0.0064 | 0.8992 | 1.908 | 0.0579 | 1.874 | 0.0624 | 0.451 |
| Henry Hub | 3.2540 | 4.8948 | -1.592 | 0.1143 | 0.4574 | -1.6409 | -0.958 | 0.3394 | -0.872 | 0.3846 | -0.241 |
| EPU | 60.0493 | 47.4238 | 1.721 | 0.0870 | 0.3478 | 12.6256 | 1.384 | 0.1681 | 1.781 | 0.0765 | 0.245 |

### prepost_full_2019_2026_w21 (full_2019_2026, 21-day windows)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.3368 | 1.3429 | 4.953 | 0.0000 | 0.0000 | 0.9939 | 3.071 | 0.0023 | 3.119 | 0.0020 | 0.580 |
| WTI | 2.1568 | 1.3370 | 3.937 | 0.0001 | 0.0004 | 0.8198 | 2.633 | 0.0089 | 2.685 | 0.0077 | 0.460 |
| Henry Hub | 3.3033 | 7.8342 | -1.956 | 0.0526 | 0.2106 | -4.5310 | -1.060 | 0.2903 | -0.903 | 0.3673 | -0.247 |
| EPU | 59.5753 | 57.7397 | 0.255 | 0.7991 | 1.0000 | 1.8356 | 0.176 | 0.8605 | 0.181 | 0.8561 | 0.031 |

### prepost_full_2019_2026_w30 (full_2019_2026, 30-day windows)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.2847 | 1.2575 | 6.090 | 0.0000 | 0.0000 | 1.0272 | 3.369 | 0.0008 | 3.313 | 0.0010 | 0.601 |
| WTI | 2.1211 | 1.3622 | 4.565 | 0.0000 | 0.0000 | 0.7589 | 2.612 | 0.0093 | 2.408 | 0.0165 | 0.450 |
| Henry Hub | 3.2627 | 5.7917 | -1.643 | 0.1020 | 0.4080 | -2.5291 | -1.002 | 0.3172 | -0.918 | 0.3591 | -0.171 |
| EPU | 62.5442 | 58.7962 | 0.545 | 0.5860 | 1.0000 | 3.7479 | 0.282 | 0.7784 | 0.277 | 0.7822 | 0.055 |

### prepost_ex2026_2019_2025_w7 (ex2026_2019_2025, 7-day windows)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 2.0396 | 1.6219 | 1.326 | 0.1880 | 0.7520 | 0.4177 | 1.221 | 0.2252 | 1.063 | 0.2906 | 0.269 |
| WTI | 1.8134 | 1.5118 | 0.867 | 0.3879 | 1.0000 | 0.3015 | 0.787 | 0.4334 | 0.809 | 0.4207 | 0.176 |
| Henry Hub | 3.1371 | 3.6507 | -0.660 | 0.5111 | 1.0000 | -0.5136 | -0.514 | 0.6087 | -0.591 | 0.5560 | -0.135 |
| EPU | 44.3971 | 39.9120 | 0.578 | 0.5646 | 1.0000 | 4.4851 | 0.536 | 0.5929 | 0.711 | 0.4789 | 0.117 |

### prepost_ex2026_2019_2025_w14 (ex2026_2019_2025, 14-day windows)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 1.9199 | 1.4393 | 2.166 | 0.0318 | 0.1271 | 0.4806 | 1.721 | 0.0871 | 1.509 | 0.1333 | 0.328 |
| WTI | 1.8064 | 1.2812 | 2.238 | 0.0267 | 0.1068 | 0.5251 | 1.680 | 0.0948 | 1.723 | 0.0867 | 0.334 |
| Henry Hub | 3.2035 | 2.9574 | 0.521 | 0.6029 | 1.0000 | 0.2462 | 0.422 | 0.6739 | 0.499 | 0.6181 | 0.079 |
| EPU | 53.1369 | 44.6691 | 1.225 | 0.2224 | 0.8896 | 8.4679 | 0.996 | 0.3205 | 1.499 | 0.1358 | 0.184 |

### prepost_ex2026_2019_2025_w21 (ex2026_2019_2025, 21-day windows)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 1.9599 | 1.2450 | 4.417 | 0.0000 | 0.0001 | 0.7149 | 4.332 | 0.0000 | 5.082 | 0.0000 | 0.549 |
| WTI | 1.8438 | 1.2624 | 3.233 | 0.0014 | 0.0057 | 0.5814 | 2.974 | 0.0032 | 2.943 | 0.0036 | 0.401 |
| Henry Hub | 3.2628 | 2.7166 | 1.322 | 0.1874 | 0.7495 | 0.5462 | 1.106 | 0.2699 | 1.008 | 0.3145 | 0.167 |
| EPU | 53.9989 | 54.8809 | -0.121 | 0.9041 | 1.0000 | -0.8820 | -0.081 | 0.9355 | -0.085 | 0.9326 | -0.015 |

### prepost_ex2026_2019_2025_w30 (ex2026_2019_2025, 30-day windows)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 1.9292 | 1.1642 | 5.542 | 0.0000 | 0.0000 | 0.7650 | 5.575 | 0.0000 | 5.040 | 0.0000 | 0.579 |
| WTI | 1.8050 | 1.3206 | 3.364 | 0.0009 | 0.0035 | 0.4844 | 3.067 | 0.0023 | 2.836 | 0.0048 | 0.351 |
| Henry Hub | 3.2733 | 3.0757 | 0.572 | 0.5677 | 1.0000 | 0.1975 | 0.373 | 0.7097 | 0.326 | 0.7450 | 0.060 |
| EPU | 55.8329 | 52.6496 | 0.477 | 0.6340 | 1.0000 | 3.1833 | 0.227 | 0.8206 | 0.223 | 0.8233 | 0.050 |

## Design 3: 2026 closure isolated (post-closure vs pre-closure windows)

### closure2026_w7 (7-day windows; N crisis=10, N pre=8)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 4.9127 | 1.5466 | 2.848 | 0.0155 | 0.0620 | 3.3660 | 2.456 | 0.0259 | 1.489 | 0.1560 | 1.289 |
| WTI | 4.5797 | 1.6547 | 2.113 | 0.0568 | 0.2271 | 2.9250 | 2.020 | 0.0604 | 1.798 | 0.0911 | 0.958 |
| Henry Hub | 6.5283 | 3.4500 | 1.654 | 0.1276 | 0.5103 | 3.0783 | 1.679 | 0.1125 | 1.096 | 0.2894 | 0.746 |
| EPU | 134.7940 | 76.1650 | 1.588 | 0.1323 | 0.5293 | 58.6290 | 2.421 | 0.0277 | 20.812 | 0.0000 | 0.750 |

### closure2026_w14 (14-day windows; N crisis=20, N pre=10)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 4.2522 | 1.8564 | 2.377 | 0.0245 | 0.0981 | 2.3957 | 1.768 | 0.0879 | 1.781 | 0.0857 | 0.823 |
| WTI | 4.7174 | 1.8544 | 2.927 | 0.0070 | 0.0281 | 2.8630 | 2.021 | 0.0530 | 1.631 | 0.1141 | 0.973 |
| Henry Hub | 5.2345 | 19.4259 | -2.133 | 0.0601 | 0.2405 | -14.1914 | -2.539 | 0.0170 | -9.288 | 0.0000 | -0.941 |
| EPU | 110.3775 | 68.0840 | 1.702 | 0.1035 | 0.4140 | 42.2935 | 4.300 | 0.0002 | 2.709 | 0.0114 | 0.641 |

### closure2026_w21 (21-day windows; N crisis=29, N pre=14)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 4.2666 | 2.1193 | 2.737 | 0.0091 | 0.0365 | 2.1473 | 2.315 | 0.0257 | 1.762 | 0.0855 | 0.789 |
| WTI | 3.7934 | 1.9281 | 2.470 | 0.0181 | 0.0724 | 1.8652 | 2.247 | 0.0301 | 1.927 | 0.0609 | 0.683 |
| Henry Hub | 4.5811 | 48.4096 | -2.518 | 0.0257 | 0.1026 | -43.8285 | -4.462 | 0.0001 | -44.790 | 0.0000 | -0.951 |
| EPU | 114.6093 | 80.4057 | 1.559 | 0.1276 | 0.5104 | 34.2036 | 2.064 | 0.0454 | 3.905 | 0.0003 | 0.471 |

### closure2026_w30 (30-day windows; N crisis=40, N pre=19)

| Variable | Crisis mean | Pre mean | Welch t | Welch p | p Bonf | NW diff | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brent | 4.0208 | 2.0923 | 3.141 | 0.0027 | 0.0110 | 1.9285 | 1.990 | 0.0514 | 1.840 | 0.0710 | 0.742 |
| WTI | 3.6726 | 1.6419 | 3.438 | 0.0012 | 0.0046 | 2.0308 | 2.264 | 0.0274 | 2.262 | 0.0275 | 0.808 |
| Henry Hub | 3.8439 | 29.5931 | -1.874 | 0.0772 | 0.3090 | -25.7492 | -2.185 | 0.0330 | -5.572 | 0.0000 | -0.607 |
| EPU | 132.7310 | 114.0937 | 0.743 | 0.4624 | 1.0000 | 18.6373 | 1.578 | 0.1201 | 0.886 | 0.3795 | 0.206 |

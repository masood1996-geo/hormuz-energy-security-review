# Robustness Analysis (peer-review items)

Baseline Design-2, 14-day windows, full sample:

| Variable | N crisis | N pre | Crisis mean | Pre mean | Welch t | p | NW t | NW p |
|---|---|---|---|---|---|---|---|---|
| Brent | 105 | 85 | 2.268 | 1.488 | 2.98 | 0.003 | 1.97 | 0.051 |
| WTI | 105 | 85 | 2.248 | 1.349 | 3.22 | 0.002 | 1.91 | 0.058 |

## 1. Leave-one-event-out

| Dropped incident | Brent t | Brent p | Brent NW p | WTI t | WTI p | WTI NW p |
|---|---|---|---|---|---|---|
| Fujairah anchorage sabotage (2019-05-12) | 3.17 | 0.002 | 0.038 | 3.27 | 0.001 | 0.056 |
| Gulf of Oman tanker attacks (2019-06-13) | 3.18 | 0.002 | 0.036 | 3.25 | 0.001 | 0.057 |
| Stena Impero seizure (2019-07-19) | 3.16 | 0.002 | 0.035 | 3.18 | 0.002 | 0.059 |
| Soleimani strike (2020-01-03) | 2.98 | 0.003 | 0.054 | 3.37 | 0.001 | 0.047 |
| Iranian missile strikes (2020-01-08) | 3.00 | 0.003 | 0.053 | 3.37 | 0.001 | 0.047 |
| Mercer Street attack (2021-07-29) | 2.92 | 0.004 | 0.061 | 3.14 | 0.002 | 0.066 |
| Regional escalation (2023-10-07) | 2.79 | 0.006 | 0.073 | 3.13 | 0.002 | 0.069 |
| Iran-Israel exchange (2024-04-13) | 3.18 | 0.002 | 0.034 | 3.61 | 0.000 | 0.028 |
| Iran missile attack on Israel (2024-10-01) | 2.52 | 0.013 | 0.104 | 2.85 | 0.005 | 0.098 |
| Israel-Iran 12-day war (2025-06-13) | 2.67 | 0.008 | 0.096 | 2.87 | 0.005 | 0.104 |
| Effective closure of the Strait of Hormuz (2026-02-28) | 1.94 | 0.054 | 0.114 | 1.96 | 0.052 | 0.132 |

## 2. Placebo-date permutation test (500 draws)

| Variable | Observed |t| | Empirical p | Mean placebo t | 95th pct |t| |
|---|---|---|---|---|
| Brent | 2.98 | 0.138 | 1.81 | 3.49 |
| WTI | 3.22 | 0.182 | 2.41 | 3.93 |

## 3. Confounder exclusion

| Excluded period | Variable | N | Welch t | p | NW p |
|---|---|---|---|---|---|
| covid (2020-02-20..2020-04-30) | Brent | 190 | 2.98 | 0.003 | 0.051 |
| covid (2020-02-20..2020-04-30) | WTI | 190 | 3.22 | 0.002 | 0.058 |
| ukraine (2022-02-24..2023-02-24) | Brent | 190 | 2.98 | 0.003 | 0.051 |
| ukraine (2022-02-24..2023-02-24) | WTI | 190 | 3.22 | 0.002 | 0.058 |

## 4. VIX-controlled regression (NW-HAC), Design 2 14-day

| Variable | Beta crisis | SE | t | p | Beta VIX | N |
|---|---|---|---|---|---|---|
| Brent | 0.4261 | 0.2903 | 1.47 | 0.144 | 0.2183 | 190 |
| WTI | 0.4298 | 0.3182 | 1.35 | 0.178 | 0.2900 | 190 |

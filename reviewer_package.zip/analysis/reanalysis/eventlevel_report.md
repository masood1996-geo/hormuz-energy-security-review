# Event-Level and Alternative-Specification Analysis

## Per-incident Design-2 14-day statistics (Brent, WTI)

| Incident | Brent crisis | Brent pre | t | p | WTI crisis | WTI pre | t | p |
|---|---|---|---|---|---|---|---|---|
| Fujairah anchorage sabotage (2019-05-12) | 1.35 | 1.74 | -0.48 | 0.637 | 1.52 | 1.16 | 0.57 | 0.577 |
| Gulf of Oman tanker attacks (2019-06-13) | 1.34 | 1.71 | -0.60 | 0.557 | 1.61 | 1.49 | 0.15 | 0.885 |
| Stena Impero seizure (2019-07-19) | 1.36 | 1.60 | -0.48 | 0.638 | 1.89 | 1.56 | 0.37 | 0.717 |
| Soleimani strike (2020-01-03) | 1.78 | 0.98 | 2.05 | 0.057 | 1.27 | 0.72 | 1.20 | 0.253 |
| Iranian missile strikes (2020-01-08) | 1.57 | 1.41 | 0.40 | 0.697 | 1.27 | 0.77 | 1.02 | 0.331 |
| Mercer Street attack (2021-07-29) | 1.92 | 1.45 | 1.00 | 0.333 | 1.77 | 1.63 | 0.29 | 0.774 |
| Regional escalation (2023-10-07) | 2.44 | 0.86 | 2.23 | 0.049 | 1.95 | 0.90 | 1.61 | 0.137 |
| Iran-Israel exchange (2024-04-13) | 1.25 | 1.07 | 0.62 | 0.540 | 0.59 | 1.23 | -1.67 | 0.113 |
| Iran missile attack on Israel (2024-10-01) | 3.17 | 1.85 | 1.46 | 0.162 | 2.80 | 2.12 | 0.83 | 0.417 |
| Israel-Iran 12-day war (2025-06-13) | 2.93 | 1.49 | 1.56 | 0.153 | 2.99 | 1.03 | 1.91 | 0.086 |
| Effective closure of the Strait of Hormuz (2026-02-28) | 5.57 | 1.86 | 2.65 | 0.021 | 6.44 | 1.85 | 3.43 | 0.006 |

## Design-2 horizon means (crisis vs pre)

| Window | Series | Crisis mean | Pre mean | N crisis | N pre |
|---|---|---|---|---|---|
| 7 | abs_brent_return_pct | 2.473 | 1.605 | 57 | 49 |
| 7 | abs_wti_return_pct | 2.211 | 1.539 | 57 | 49 |
| 7 | abs_hh_return_pct | 3.196 | 3.635 | 57 | 49 |
| 7 | abs_epu_change | 54.102 | 44.300 | 57 | 49 |
| 7 | vix | 17.296 | 16.382 | 57 | 49 |
| 7 | ovx | 43.229 | 35.529 | 57 | 49 |
| 7 | gvz | 16.879 | 15.699 | 57 | 49 |
| 14 | abs_brent_return_pct | 2.268 | 1.488 | 105 | 85 |
| 14 | abs_wti_return_pct | 2.248 | 1.349 | 105 | 85 |
| 14 | abs_hh_return_pct | 3.254 | 4.895 | 105 | 85 |
| 14 | abs_epu_change | 60.049 | 47.424 | 105 | 85 |
| 14 | vix | 17.418 | 15.800 | 105 | 85 |
| 14 | ovx | 44.293 | 33.935 | 105 | 85 |
| 14 | gvz | 16.955 | 15.998 | 105 | 85 |
| 21 | abs_brent_return_pct | 2.337 | 1.343 | 152 | 125 |
| 21 | abs_wti_return_pct | 2.157 | 1.337 | 152 | 125 |
| 21 | abs_hh_return_pct | 3.303 | 7.834 | 152 | 125 |
| 21 | abs_epu_change | 59.575 | 57.740 | 152 | 125 |
| 21 | vix | 17.647 | 15.808 | 152 | 125 |
| 21 | ovx | 44.359 | 33.771 | 152 | 125 |
| 21 | gvz | 16.983 | 16.238 | 152 | 125 |
| 30 | abs_brent_return_pct | 2.285 | 1.258 | 211 | 184 |
| 30 | abs_wti_return_pct | 2.121 | 1.362 | 211 | 184 |
| 30 | abs_hh_return_pct | 3.263 | 5.792 | 211 | 184 |
| 30 | abs_epu_change | 62.544 | 58.796 | 211 | 184 |
| 30 | vix | 17.729 | 16.413 | 211 | 184 |
| 30 | ovx | 44.046 | 33.055 | 211 | 184 |
| 30 | gvz | 17.247 | 15.332 | 211 | 184 |

## Alternative volatility specifications (Design 2)

| Window | Variable | Crisis mean | Pre mean | Welch t | p |
|---|---|---|---|---|---|
| 14 | brent2 | 10.2318 | 3.8603 | 2.82 | 0.006 |
| 14 | wti2 | 11.7681 | 2.9601 | 3.49 | 0.001 |
| 14 | brent_log | 2.2534 | 1.4915 | 2.95 | 0.004 |
| 14 | wti_log | 2.2400 | 1.3525 | 3.18 | 0.002 |
| 14 | vix | 17.4181 | 15.7995 | 3.40 | 0.001 |
| 14 | ovx | 44.2926 | 33.9353 | 4.80 | 0.000 |
| 14 | gvz | 16.9549 | 15.9978 | 0.93 | 0.353 |
| 30 | brent2 | 9.9452 | 2.6690 | 5.01 | 0.000 |
| 30 | wti2 | 9.1721 | 2.8412 | 4.56 | 0.000 |
| 30 | brent_log | 2.2801 | 1.2549 | 6.11 | 0.000 |
| 30 | wti_log | 2.1209 | 1.3608 | 4.56 | 0.000 |
| 30 | vix | 17.7291 | 16.4130 | 3.15 | 0.002 |
| 30 | ovx | 44.0460 | 33.0546 | 7.89 | 0.000 |
| 30 | gvz | 17.2470 | 15.3320 | 2.97 | 0.003 |

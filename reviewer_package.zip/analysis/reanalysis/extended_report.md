# Extended Re-Analysis: Supplementary Risk and Gas-Price Series

Analysis window: 2019-01-02 .. 2026-08-18 (1875 trading days).

## 1. Supplementary daily volatility series (Design 2: pre-incident control)

Volatility = absolute daily index change (points). Bonferroni across the three supplementary variables. NW = Newey-West HAC (lag = window in business days); Clust = calendar-quarter clusters.

| Key | Window | N crisis | N pre | Variable | Crisis mean | Pre mean | Welch t | p raw | p Bonf | NW t | NW p | Clust t | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| sup_full_2019_2026_w14 | 14 | 105 | 85 | VIX | 1.04 | 0.91 | 0.86 | 0.391 | 1.000 | -1.04 | 0.300 | -0.82 | 0.414 | 0.13 |
| sup_full_2019_2026_w14 | 14 | 105 | 85 | OVX | 2.79 | 1.49 | 3.69 | 0.000 | 0.001 | 0.89 | 0.375 | 0.71 | 0.476 | 0.52 |
| sup_full_2019_2026_w14 | 14 | 105 | 85 | GVZ | 0.77 | 0.66 | 0.81 | 0.418 | 1.000 | 0.38 | 0.702 | 0.36 | 0.718 | 0.12 |

| sup_full_2019_2026_w30 | 30 | 211 | 184 | VIX | 1.13 | 1.03 | 0.76 | 0.447 | 1.000 | -0.56 | 0.578 | -0.49 | 0.623 | 0.08 |
| sup_full_2019_2026_w30 | 30 | 211 | 184 | OVX | 2.34 | 1.24 | 5.14 | 0.000 | 0.000 | 0.07 | 0.947 | 0.06 | 0.954 | 0.51 |
| sup_full_2019_2026_w30 | 30 | 211 | 184 | GVZ | 0.84 | 0.65 | 1.94 | 0.053 | 0.160 | 0.80 | 0.423 | 0.70 | 0.481 | 0.20 |

| sup_ex2026_2019_2025_w14 | 14 | 95 | 75 | VIX | 0.91 | 0.84 | 0.54 | 0.590 | 1.000 | -2.17 | 0.030 | -1.65 | 0.099 | 0.08 |
| sup_ex2026_2019_2025_w14 | 14 | 95 | 75 | OVX | 2.41 | 1.33 | 3.59 | 0.000 | 0.001 | 0.35 | 0.724 | 0.28 | 0.782 | 0.53 |
| sup_ex2026_2019_2025_w14 | 14 | 95 | 75 | GVZ | 0.70 | 0.42 | 2.88 | 0.004 | 0.013 | 0.33 | 0.743 | 0.28 | 0.776 | 0.43 |

| sup_ex2026_2019_2025_w30 | 30 | 190 | 167 | VIX | 1.03 | 1.04 | -0.08 | 0.935 | 1.000 | -1.31 | 0.191 | -1.20 | 0.230 | -0.01 |
| sup_ex2026_2019_2025_w30 | 30 | 190 | 167 | OVX | 2.05 | 1.20 | 4.60 | 0.000 | 0.000 | -0.44 | 0.660 | -0.38 | 0.702 | 0.48 |
| sup_ex2026_2019_2025_w30 | 30 | 190 | 167 | GVZ | 0.68 | 0.57 | 1.30 | 0.195 | 0.584 | 0.19 | 0.850 | 0.15 | 0.881 | 0.14 |

## 2. 2026 closure in isolation (Design 3) - supplementary series

| Window | Variable | Post-closure mean | Pre-closure mean | Welch t | p raw | p Bonf | NW p | Clust p | Cohen's d |
|---|---|---|---|---|---|---|---|---|---|
| 7d | VIX | 2.34 | 0.57 | 3.90 | 0.003 | 0.008 | 0.002 | 0.000 | 1.76 |
| 7d | OVX | 7.33 | 2.62 | 2.06 | 0.060 | 0.179 | 0.000 | 0.000 | 0.94 |
| 7d | GVZ | 1.45 | 1.05 | 0.79 | 0.440 | 1.000 | 0.462 | 0.359 | 0.38 |

| 14d | VIX | 1.81 | 1.49 | 0.57 | 0.577 | 1.000 | 0.028 | 0.011 | 0.22 |
| 14d | OVX | 6.10 | 2.69 | 2.47 | 0.020 | 0.061 | 0.000 | 0.000 | 0.82 |
| 14d | GVZ | 1.12 | 2.45 | -1.96 | 0.076 | 0.229 | 0.901 | 0.877 | -0.85 |

| 21d | VIX | 1.67 | 1.50 | 0.35 | 0.730 | 1.000 | 0.091 | 0.049 | 0.11 |
| 21d | OVX | 5.51 | 2.19 | 2.93 | 0.006 | 0.017 | 0.000 | 0.000 | 0.82 |
| 21d | GVZ | 1.25 | 3.08 | -3.13 | 0.007 | 0.020 | 0.754 | 0.669 | -1.12 |

| 30d | VIX | 1.54 | 0.80 | 2.27 | 0.029 | 0.086 | 0.095 | 0.064 | 0.61 |
| 30d | OVX | 4.67 | 1.60 | 3.84 | 0.000 | 0.001 | 0.001 | 0.000 | 0.88 |
| 30d | GVZ | 1.54 | 1.38 | 0.37 | 0.716 | 1.000 | 0.402 | 0.290 | 0.10 |

## 3. Monthly international gas event study

Sample: 2019-01 .. 2026-07 (90 monthly percentage changes; 91 price observations, the first month being lost to differencing). Crisis months = incident month plus the two following months; union across the eleven incidents. Welch test on absolute monthly changes.

| Series | Crisis months (full) | Other months (full) | Mean abs change crisis | Mean abs change other | Signed mean crisis | Signed mean other | Welch t (full) | p (full) | Welch t (ex-2026) | p (ex-2026) |
|---|---|---|---|---|---|---|---|---|---|---|
| LNG Asia (PNGASJPUSDM) | 26 | 64 | 15.17% | 18.65% | 6.21% | 2.89% | -0.80 | 0.429 | -2.23 | 0.030 |
| Natural gas EU (PNGASEUUSDM) | 26 | 64 | 13.51% | 18.43% | 3.19% | 3.62% | -1.54 | 0.128 | -2.36 | 0.021 |
| Henry Hub (DHHNGSP) | 26 | 64 | 12.97% | 15.34% | 1.34% | 2.55% | -0.71 | 0.481 | -1.13 | 0.263 |

## 4. 2026 closure: international gas price levels

| Series | Pre-closure mean (Nov25-Jan26) | Post-closure mean (Mar-May26) | Post vs pre | Jan-2026 | Jul-2026 | Jan to Jul |
|---|---|---|---|---|---|---|
| LNG Asia | 10.47 | 18.49 | +76.6% | 10.44 | 19.56 | +87.5% |
| Natural gas EU | 10.60 | 16.41 | +54.8% | 11.99 | 17.93 | +49.6% |
| Henry Hub | 5.26 | 2.92 | -44.5% | 7.72 | 2.89 | -62.6% |

| Series | Spring 2025 mean (Mar-May25) | Spring 2026 mean (Mar-May26) | Same-season YoY |
|---|---|---|---|
| LNG Asia | 12.12 | 18.49 | +52.6% |
| Natural gas EU | 12.12 | 16.41 | +35.4% |
| Henry Hub | 3.55 | 2.92 | -17.9% |

| Month | LNG Asia YoY | Natural gas EU YoY | Henry Hub YoY |
|---|---|---|---|
| 2026-03 | +58.7% | +34.3% | -26.1% |
| 2026-04 | +43.2% | +33.0% | -19.2% |
| 2026-05 | +55.0% | +39.0% | -5.8% |
| 2026-06 | +32.6% | +22.7% | +4.0% |
| 2026-07 | +59.5% | +56.3% | -9.8% |

## 5. Destination exposure of Hormuz crude (EIA/Vortexa)

| Year | Crude transit (mb/d) | To Asia (mb/d) | Asian share (%) |
|---|---|---|---|
| 1Q25 | 14.21 | 12.67 | 89.2 |
| 2020 | 14.27 | 11.81 | 82.8 |
| 2021 | 14.39 | 11.69 | 81.2 |
| 2022 | 15.96 | 12.75 | 79.9 |
| 2023 | 15.54 | 12.48 | 80.3 |
| 2024 | 14.32 | 11.98 | 83.7 |

## 6. Restricted-window descriptive statistics (Appendix A inputs)

| Variable | n | Mean | SD | Min | Median | Max |
|---|---|---|---|---|---|---|
| Brent daily returns (%) | 1875 | 0.0950 | 3.4628 | -47.4654 | 0.1554 | 50.9868 |
| WTI daily returns (%) | 1875 | -0.0943 | 8.3298 | -301.9661 | 0.1386 | 53.0864 |
| Henry Hub daily returns (%) | 1875 | 0.5621 | 13.2390 | -75.3788 | 0.0000 | 319.0476 |
| EPU daily change (points) | 1875 | 0.0265 | 99.6142 | -952.7800 | -0.8500 | 872.8200 |
| VIX daily change (points) | 1875 | -0.0067 | 2.0959 | -18.7100 | -0.1500 | 24.8600 |
| OVX daily change (points) | 1875 | -0.0032 | 6.1258 | -90.6100 | -0.1900 | 130.2200 |
| GVZ daily change (points) | 1875 | 0.0050 | 1.1659 | -9.5000 | -0.0800 | 8.1100 |

### Pairwise Pearson correlations (restricted window)

| Pair | r | p |
|---|---|---|
| Brent vs WTI | 0.462 | 0.0000 |
| Brent vs Henry Hub | 0.028 | 0.2279 |
| Brent vs EPU | 0.010 | 0.6603 |
| Henry Hub vs WTI | 0.002 | 0.9448 |
| EPU vs WTI | 0.000 | 0.9922 |
| EPU vs Henry Hub | -0.005 | 0.8435 |
